from __future__ import annotations

import asyncio
import hashlib
import json
import re
import unicodedata
from collections.abc import Callable
from threading import BoundedSemaphore, Thread
from time import time
from uuid import uuid4

from totalclaw_cerebellum.domain import (
    AuditEvent,
    CapabilityCandidate,
    CapabilityReference,
    CerebellumRequest,
    ComputeBudget,
    ComputeBudgetLevel,
    DataClassification,
    DomainKeywordRule,
    IdentityContext,
    LtmContextEntry,
    LtmDecisionLog,
    PlanningLevel,
    PortTimeouts,
    ProductDecision,
    ProductSafetyDecision,
    RedactionAction,
    RedactionResult,
    RequestContext,
    RiskLevel,
    Router0Result,
    Router0Status,
    SafeLtmContextEntry,
    SafeRoutingRequest,
    SafetyAction,
    SkillIdentityVisibility,
    ToolBudgetPlan,
    ToolPlanningConfig,
    UserTurnHistory,
)
from totalclaw_cerebellum.ports import (
    AffinityLearningPort,
    AuditPort,
    RedactorPort,
    Router0Port,
    SkillIdentityFilterPort,
)

from .plan_cache import ToolPlanCache, ToolPlanCacheKey

_RISK_RANK = {
    RiskLevel.LOW: 0,
    RiskLevel.MEDIUM: 1,
    RiskLevel.HIGH: 2,
    RiskLevel.CRITICAL: 3,
}
_DATA_RISK = {
    DataClassification.L0: RiskLevel.LOW,
    DataClassification.L1: RiskLevel.LOW,
    DataClassification.L2: RiskLevel.MEDIUM,
    DataClassification.L3: RiskLevel.HIGH,
    DataClassification.L4: RiskLevel.CRITICAL,
}
_REASON_CODE_PATTERN = re.compile(r"^[a-z0-9_]{1,128}$")
_CAPABILITY_ID_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")
_LTM_CONTEXT_LIMIT = 5
_USER_HISTORY_REDACTION_CONCURRENCY = 8
_LTM_MIN_SCORE = 0.5
_LTM_LOG_MAX_IN_FLIGHT = 32
_LTM_LOG_SLOTS = BoundedSemaphore(_LTM_LOG_MAX_IN_FLIGHT)
LtmLogFn = Callable[[dict[str, object]], None]


class DeterministicToolPlanner:
    """Narrow only a request-scoped, already authorized capability set."""

    def __init__(self, config: ToolPlanningConfig | None = None) -> None:
        self.config = config or ToolPlanningConfig()

    def plan(
        self,
        request: SafeRoutingRequest,
        candidates: tuple[CapabilityCandidate, ...],
        identity: IdentityContext,
        *,
        risk_level: RiskLevel,
        ltm_context: tuple[SafeLtmContextEntry, ...] = (),
        safe_user_turns: tuple[str, ...] = (),
        user_history_degraded: bool = False,
        dynamic_fallback_tool_ids: tuple[str, ...] | None = None,
        affinity_reason_codes: tuple[str, ...] = (),
    ) -> ToolBudgetPlan:
        authorized = filter_authorized_candidates(candidates, identity)
        all_references = _references(authorized)
        input_authorized_count = len(all_references)
        input_authorized_tool_count = _tool_count(authorized)

        if not authorized:
            return ToolBudgetPlan(
                tools=(),
                display_tools=(),
                authorized_capability_count=0,
                authorized_tool_count=0,
                level=PlanningLevel.BYPASS,
                narrowed=False,
                degraded=True,
                reason_codes=("no_authorized_tools",),
            )
        if not self.config.enabled:
            return ToolBudgetPlan(
                tools=all_references,
                display_tools=all_references,
                authorized_capability_count=input_authorized_count,
                authorized_tool_count=input_authorized_tool_count,
                level=PlanningLevel.BYPASS,
                narrowed=False,
                degraded=False,
                reason_codes=("tool_planning_disabled",),
            )

        gate_reason_codes: list[str] = []
        current_wechat_match = self._is_wechat_task(request.redacted_text)
        history_wechat_match = any(
            self._is_wechat_task(text) for text in safe_user_turns
        )
        if current_wechat_match:
            gate_reason_codes.append("wechat_gate_current_match")
        if history_wechat_match:
            gate_reason_codes.append("wechat_gate_history_match")
        if self.config.wechat_gate_enabled and user_history_degraded:
            gate_reason_codes.append("wechat_gate_history_fail_restrictive")
        wechat_semantic_match = (
            current_wechat_match
            or history_wechat_match
            or (self.config.wechat_gate_enabled and user_history_degraded)
        )
        wechat_task = wechat_semantic_match and self._has_authorized_wechat_tool(
            authorized
        )
        if wechat_semantic_match and not wechat_task:
            gate_reason_codes.append("wechat_gate_no_required_tool_skipped")
        if wechat_task:
            blocked_tool_ids = set(self.config.wechat_gui_blocked_tool_ids)
            authorized = tuple(
                candidate
                for candidate in authorized
                if candidate.tool.tool_id not in blocked_tool_ids
            )
            all_references = _references(authorized)
            gate_reason_codes.append("wechat_gate_applied")

        gated_tool_count = _tool_count(authorized)
        if gated_tool_count < self.config.minimum_tool_count:
            return ToolBudgetPlan(
                tools=all_references,
                display_tools=all_references,
                authorized_capability_count=input_authorized_count,
                authorized_tool_count=input_authorized_tool_count,
                level=PlanningLevel.BYPASS,
                narrowed=len(all_references) < input_authorized_count,
                degraded=False,
                reason_codes=(*gate_reason_codes, "below_minimum_tool_count"),
            )

        domains = self._match_domains(request.redacted_text)
        if domains:
            level = PlanningLevel.L1
            selected = tuple(
                candidate
                for candidate in authorized
                if _candidate_matches_domains(
                    candidate,
                    domains,
                    self.config.domain_rules,
                )
            )
            selected = _include_configured_tools(
                selected,
                authorized,
                (
                    *self.config.always_include_tool_ids,
                    *self.config.discovery_tool_ids,
                ),
            )
            reason_codes = [*gate_reason_codes, "l1_domain_match"]
            if not selected:
                selected = authorized
                reason_codes.append("domain_catalog_mismatch_fallback_all")
        else:
            level = PlanningLevel.L4
            if dynamic_fallback_tool_ids is None:
                fallback_ids = (
                    *self.config.fallback_core_tool_ids,
                    *self.config.discovery_tool_ids,
                    *self.config.fallback_ranked_tool_ids[
                        : self.config.fallback_top_k
                    ],
                    *self.config.always_include_tool_ids,
                )
                selected = _select_configured_tools(authorized, fallback_ids)
                reason_codes = [
                    *gate_reason_codes,
                    *affinity_reason_codes,
                    "l4_static_fallback",
                ]
            else:
                fallback_ids = (
                    *self.config.fallback_core_tool_ids,
                    *dynamic_fallback_tool_ids[:5],
                )
                selected = _select_configured_tools_ordered(
                    authorized,
                    fallback_ids,
                )
                selected = _append_configured_tools(
                    selected,
                    authorized,
                    (
                        *self.config.discovery_tool_ids,
                        *self.config.always_include_tool_ids,
                    ),
                )
                reason_codes = [
                    *gate_reason_codes,
                    *affinity_reason_codes,
                    "l4_dynamic_fallback",
                ]
            if not selected:
                selected = authorized
                reason_codes.append("fallback_set_unconfigured")

        selected_with_ltm = _include_ltm_tools(
            selected,
            authorized,
            ltm_context,
        )
        if selected_with_ltm != selected:
            selected = selected_with_ltm
            reason_codes.append("ltm_tools_included")

        if wechat_task:
            selected = _include_configured_tools(
                selected,
                authorized,
                self.config.wechat_required_tool_ids,
            )
            authorized_tool_ids = {
                candidate.tool.tool_id for candidate in authorized
            }
            if set(self.config.wechat_required_tool_ids).issubset(
                authorized_tool_ids
            ):
                reason_codes.append("wechat_required_tools_restored")
            else:
                reason_codes.append("wechat_required_tools_unauthorized")

        degraded = len(selected) == len(authorized) and selected is authorized
        if _tool_count(selected) / gated_tool_count < self.config.minimum_retention_ratio:
            selected = authorized
            degraded = True
            reason_codes.append("minimum_retention_fallback_all")

        selected_references = _references(selected)
        if not selected_references:
            selected = authorized
            selected_references = all_references
            degraded = True
            reason_codes.append("empty_selection_fallback_all")

        budget = _compute_budget(
            request,
            domains=domains,
            risk_level=risk_level,
        )
        return ToolBudgetPlan(
            tools=selected_references,
            display_tools=selected_references,
            authorized_capability_count=input_authorized_count,
            authorized_tool_count=input_authorized_tool_count,
            domains=domains,
            level=level,
            narrowed=len(selected_references) < input_authorized_count,
            degraded=degraded,
            budget=budget,
            reason_codes=tuple(reason_codes),
        )

    def fallback_all(
        self,
        candidates: tuple[CapabilityCandidate, ...],
        identity: IdentityContext,
        reason_code: str,
        *,
        request: SafeRoutingRequest | None = None,
        safe_user_turns: tuple[str, ...] = (),
        user_history_degraded: bool = False,
    ) -> ToolBudgetPlan:
        authorized = filter_authorized_candidates(candidates, identity)
        input_authorized_count = len(_references(authorized))
        input_authorized_tool_count = _tool_count(authorized)
        reason_codes = [reason_code]
        current_wechat_match = (
            request is not None and self._is_wechat_task(request.redacted_text)
        )
        history_wechat_match = any(
            self._is_wechat_task(text) for text in safe_user_turns
        )
        if current_wechat_match:
            reason_codes.append("wechat_gate_current_match")
        if history_wechat_match:
            reason_codes.append("wechat_gate_history_match")
        if self.config.wechat_gate_enabled and user_history_degraded:
            reason_codes.append("wechat_gate_history_fail_restrictive")
        wechat_semantic_match = (
            current_wechat_match
            or history_wechat_match
            or (self.config.wechat_gate_enabled and user_history_degraded)
        )
        wechat_task = wechat_semantic_match and self._has_authorized_wechat_tool(
            authorized
        )
        if wechat_semantic_match and not wechat_task:
            reason_codes.append("wechat_gate_no_required_tool_skipped")
        if wechat_task:
            blocked_tool_ids = set(self.config.wechat_gui_blocked_tool_ids)
            authorized = tuple(
                candidate
                for candidate in authorized
                if candidate.tool.tool_id not in blocked_tool_ids
            )
            reason_codes.append("wechat_gate_applied")
        references = _references(authorized)
        authorized_tool_count = _tool_count(authorized)
        if not self.config.enabled:
            level = PlanningLevel.BYPASS
            reason_codes.append("tool_planning_disabled")
        elif authorized_tool_count < self.config.minimum_tool_count:
            level = PlanningLevel.BYPASS
            reason_codes.append("below_minimum_tool_count")
        else:
            level = PlanningLevel.L4
        return ToolBudgetPlan(
            tools=references,
            display_tools=references,
            authorized_capability_count=input_authorized_count,
            authorized_tool_count=input_authorized_tool_count,
            level=level,
            narrowed=len(references) < input_authorized_count,
            degraded=True,
            budget=None,
            reason_codes=_safe_reason_codes(
                tuple(reason_codes),
                "tool_planner_unavailable",
            ),
        )

    def _match_domains(self, text: str) -> tuple[str, ...]:
        normalized = unicodedata.normalize("NFKC", text).casefold()
        matched: list[str] = []
        for rule in self.config.domain_rules:
            hits = sum(
                1
                for keyword in rule.keywords
                if unicodedata.normalize("NFKC", keyword).casefold() in normalized
            )
            confidence = 1.0 - (0.5**hits) if hits else 0.0
            if confidence >= self.config.l1_confidence_threshold:
                matched.append(rule.domain)
        return tuple(matched)

    def _is_wechat_task(self, text: str) -> bool:
        if not self.config.wechat_gate_enabled:
            return False
        normalized = unicodedata.normalize("NFKC", text).casefold()
        has_trigger = any(
            _normalize_keyword(keyword) in normalized
            for keyword in self.config.wechat_trigger_keywords
        )
        has_intent = any(
            _normalize_keyword(keyword) in normalized
            for keyword in self.config.wechat_intent_keywords
        )
        is_excluded = any(
            _normalize_keyword(keyword) in normalized
            for keyword in self.config.wechat_exclusion_keywords
        )
        return has_trigger and has_intent and not is_excluded

    def _has_authorized_wechat_tool(
        self,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> bool:
        required_tool_ids = set(self.config.wechat_required_tool_ids)
        return any(
            candidate.tool.tool_id in required_tool_ids for candidate in candidates
        )


def _normalize_keyword(keyword: str) -> str:
    return unicodedata.normalize("NFKC", keyword).strip().casefold()


class ProductDecisionService:
    """Taotu 2.0 dual-channel interface without changing the v1 route contract."""

    def __init__(
        self,
        *,
        redactor: RedactorPort,
        router0: Router0Port,
        audit: AuditPort,
        timeouts: PortTimeouts,
        planning_config: ToolPlanningConfig | None = None,
        affinity_learning: AffinityLearningPort | None = None,
        skill_identity_filter: SkillIdentityFilterPort | None = None,
        plan_cache: ToolPlanCache | None = None,
        catalog_version: str = "catalog-unconfigured",
        profile_version: str = "profile-unconfigured",
    ) -> None:
        self.redactor = redactor
        self.router0 = router0
        self.audit = audit
        self.timeouts = timeouts
        self.planner = DeterministicToolPlanner(planning_config)
        self.affinity_learning = affinity_learning
        self.skill_identity_filter = skill_identity_filter
        self.plan_cache = plan_cache
        self.catalog_version = catalog_version
        self.profile_version = profile_version

    async def decide(
        self,
        request: CerebellumRequest,
        context: RequestContext,
        available_candidates: tuple[CapabilityCandidate, ...],
        *,
        ltm_context: list[dict[str, object]] | None = None,
        ltm_log_fn: LtmLogFn | None = None,
        user_turn_history: UserTurnHistory | None = None,
    ) -> ProductDecision:
        try:
            redaction = RedactionResult.model_validate(
                await asyncio.wait_for(
                    self.redactor.redact(request, context),
                    timeout=self.timeouts.redactor_seconds,
                )
            )
        except TimeoutError:
            plan = self.planner.fallback_all(
                available_candidates,
                context.identity,
                "redactor_timeout_plan_fallback",
            )
            plan = await self._apply_skill_identity_visibility(
                plan,
                available_candidates,
                context.identity,
            )
            return await self._complete_product_decision(
                request_id=request.request_id,
                safety=_blocked_safety("redactor_timeout"),
                plan=plan,
                redacted_text=None,
                ltm_log_fn=ltm_log_fn,
            )
        except Exception:  # noqa: BLE001 - port details must not cross the boundary
            plan = self.planner.fallback_all(
                available_candidates,
                context.identity,
                "redactor_unavailable_plan_fallback",
            )
            plan = await self._apply_skill_identity_visibility(
                plan,
                available_candidates,
                context.identity,
            )
            return await self._complete_product_decision(
                request_id=request.request_id,
                safety=_blocked_safety("redactor_unavailable"),
                plan=plan,
                redacted_text=None,
                ltm_log_fn=ltm_log_fn,
            )

        if redaction.policy_action is RedactionAction.BLOCK:
            reason_code = (
                redaction.reason_codes[0]
                if redaction.reason_codes
                else "redaction_blocked"
            )
            plan = self.planner.fallback_all(
                available_candidates,
                context.identity,
                "redaction_blocked_plan_fallback",
            )
            plan = await self._apply_skill_identity_visibility(
                plan,
                available_candidates,
                context.identity,
            )
            return await self._complete_product_decision(
                request_id=request.request_id,
                safety=_blocked_safety(
                    reason_code,
                    classification=redaction.data_classification,
                ),
                plan=plan,
                redacted_text=None,
                ltm_log_fn=ltm_log_fn,
            )

        safe_request = SafeRoutingRequest(
            request_id=request.request_id,
            session_id=request.session_id,
            locale=request.locale,
            redacted_text=redaction.redacted_text,
            data_classification=redaction.data_classification,
            redaction_action=redaction.policy_action,
            is_write_intent=request.is_write_intent,
        )
        safe_user_turns, user_history_degraded = (
            await self._prepare_user_turn_history(
                request,
                context,
                user_turn_history,
            )
        )

        router0_result: Router0Result | None
        router0_failure: str | None = None
        try:
            router0_result = Router0Result.model_validate(
                await asyncio.wait_for(
                    self.router0.route(safe_request, context),
                    timeout=self.timeouts.router0_seconds,
                )
            )
        except TimeoutError:
            router0_result = None
            router0_failure = "router0_timeout"
        except Exception:  # noqa: BLE001 - port details must not cross the boundary
            router0_result = None
            router0_failure = "router0_unavailable"

        if router0_result is not None:
            safe_request = safe_request.model_copy(
                update={
                    "is_write_intent": (
                        safe_request.is_write_intent or router0_result.is_write_op
                    )
                }
            )
            safety = _safety_from_router0(safe_request, router0_result)
            planning_risk = safety.risk_level
        else:
            safety = _blocked_safety(
                router0_failure or "router0_unavailable",
                classification=safe_request.data_classification,
                is_write_intent=safe_request.is_write_intent,
            )
            planning_risk = _DATA_RISK[safe_request.data_classification]

        cache_key = self._cache_key(
            safe_request,
            context.identity,
            available_candidates,
            planning_risk,
            ltm_context=ltm_context,
            user_turn_history=user_turn_history,
        )
        plan = self.plan_cache.get(cache_key) if cache_key is not None else None
        if plan is not None:
            plan = _replace_plan(
                plan,
                reason_codes=plan.reason_codes + ("tool_plan_cache_hit",),
            )
        else:
            safe_ltm_context = await self._prepare_ltm_context(
                request,
                context,
                ltm_context,
            )
            try:
                dynamic_fallback_ids, affinity_reason_codes = (
                    await self._dynamic_fallback_tool_ids(
                        safe_request,
                        available_candidates,
                        context.identity,
                    )
                )
                plan = self.planner.plan(
                    safe_request,
                    available_candidates,
                    context.identity,
                    risk_level=planning_risk,
                    ltm_context=safe_ltm_context,
                    safe_user_turns=safe_user_turns,
                    user_history_degraded=user_history_degraded,
                    dynamic_fallback_tool_ids=dynamic_fallback_ids,
                    affinity_reason_codes=affinity_reason_codes,
                )
            except Exception:  # noqa: BLE001 - planning must independently fail open
                plan = self.planner.fallback_all(
                    available_candidates,
                    context.identity,
                    "tool_planner_unavailable",
                    request=safe_request,
                    safe_user_turns=safe_user_turns,
                    user_history_degraded=user_history_degraded,
                )
            else:
                if cache_key is not None and self.plan_cache is not None:
                    self.plan_cache.put(cache_key, plan)
        plan = await self._apply_affinity_order(plan)
        plan = await self._apply_skill_identity_visibility(
            plan,
            available_candidates,
            context.identity,
        )
        return await self._complete_product_decision(
            request_id=request.request_id,
            safety=safety,
            plan=plan,
            redacted_text=safe_request.redacted_text,
            ltm_log_fn=ltm_log_fn,
        )

    async def _complete_product_decision(
        self,
        *,
        request_id: str,
        safety: ProductSafetyDecision,
        plan: ToolBudgetPlan,
        redacted_text: str | None,
        ltm_log_fn: LtmLogFn | None,
    ) -> ProductDecision:
        audit_failure = await self._audit_safety(request_id, safety)
        if audit_failure is not None:
            safety = _blocked_safety(
                audit_failure,
                classification=safety.data_classification,
                is_write_intent=safety.is_write_intent,
            )
            redacted_text = None
        return _complete_product_decision(
            request_id=request_id,
            safety=safety,
            plan=plan,
            redacted_text=redacted_text,
            ltm_log_fn=ltm_log_fn,
        )

    async def _audit_safety(
        self,
        request_id: str,
        safety: ProductSafetyDecision,
    ) -> str | None:
        event = AuditEvent(
            trace_id=uuid4().hex,
            request_id=request_id,
            event_type="product_decision",
            data_classification=safety.data_classification,
            risk_level=safety.risk_level,
            reason_codes=safety.reason_codes,
        )
        try:
            await asyncio.wait_for(
                self.audit.record(event),
                timeout=self.timeouts.audit_seconds,
            )
        except TimeoutError:
            return "audit_timeout"
        except Exception:  # noqa: BLE001 - audit failures must fail closed
            return "audit_unavailable"
        return None

    def _cache_key(
        self,
        request: SafeRoutingRequest,
        identity: IdentityContext,
        candidates: tuple[CapabilityCandidate, ...],
        risk_level: RiskLevel,
        *,
        ltm_context: list[dict[str, object]] | None,
        user_turn_history: UserTurnHistory | None,
    ) -> ToolPlanCacheKey | None:
        if self.plan_cache is None or not self.plan_cache.config.enabled:
            return None
        if self._affinity_may_change():
            return None
        if ltm_context:
            return None
        if user_turn_history is not None and user_turn_history.turns:
            return None
        authorized = filter_authorized_candidates(candidates, identity)
        identity_payload = {
            "tenant_id": identity.tenant_id,
            "user_id": identity.user_id,
            "granted_scopes": sorted(identity.granted_scopes),
            "roles": sorted(identity.roles),
            "identity_labels": sorted(identity.identity_labels),
            "authenticated": identity.authenticated,
            "source": identity.source,
        }
        candidate_payload = [
            {
                "tool_id": candidate.tool.tool_id,
                "action_id": candidate.action.action_id,
                "tags": sorted(candidate.action.tags),
            }
            for candidate in authorized
        ]
        return ToolPlanCacheKey(
            redacted_text_sha256=hashlib.sha256(
                request.redacted_text.encode("utf-8")
            ).hexdigest(),
            identity_sha256=_json_sha256(identity_payload),
            catalog_version=self.catalog_version,
            profile_version=self.profile_version,
            candidate_set_sha256=_json_sha256(candidate_payload),
            data_classification=request.data_classification.value,
            risk_level=risk_level.value,
            is_write_intent=request.is_write_intent,
        )

    def _affinity_may_change(self) -> bool:
        if self.affinity_learning is None:
            return False
        try:
            return self.affinity_learning.enabled
        except Exception:  # noqa: BLE001 - an unhealthy optional port must not cache
            return True

    async def _dynamic_fallback_tool_ids(
        self,
        request: SafeRoutingRequest,
        candidates: tuple[CapabilityCandidate, ...],
        identity: IdentityContext,
    ) -> tuple[tuple[str, ...] | None, tuple[str, ...]]:
        """Resolve P4 Top-5 only after hard authorization and only for L4 fallback."""

        if not self.planner.config.enabled:
            return None, ()
        authorized = filter_authorized_candidates(candidates, identity)
        if _tool_count(authorized) < self.planner.config.minimum_tool_count:
            return None, ()
        if self.planner._match_domains(request.redacted_text):
            return None, ()
        if self.affinity_learning is None:
            return None, ()
        try:
            enabled = self.affinity_learning.enabled
        except Exception:  # noqa: BLE001 - optional learning falls back to static
            return None, ("affinity_learning_error_static_fallback",)
        if not enabled:
            return None, ()

        authorized_tool_ids = {
            candidate.tool.tool_id for candidate in authorized
        }
        try:
            proposed = await asyncio.wait_for(
                self.affinity_learning.global_top_tools(5),
                timeout=self.timeouts.affinity_learning_seconds,
            )
            if not isinstance(proposed, tuple):
                raise TypeError("affinity result must be a tuple")
            normalized = _normalize_dynamic_tool_ids(
                proposed,
                authorized_tool_ids=authorized_tool_ids,
                excluded_tool_ids=set(self.planner.config.fallback_core_tool_ids),
                limit=5,
            )
        except TimeoutError:
            return None, ("affinity_learning_timeout_static_fallback",)
        except Exception:  # noqa: BLE001 - optional learning falls back to static
            return None, ("affinity_learning_error_static_fallback",)

        reason_codes = ["affinity_learning_top5_applied"]
        if len(normalized) != len(proposed[:5]):
            reason_codes.append("affinity_candidates_filtered")
        return normalized, tuple(reason_codes)

    async def _apply_affinity_order(
        self,
        plan: ToolBudgetPlan,
    ) -> ToolBudgetPlan:
        """Apply P4 ordering only to an already-authorized, narrowed L1 plan."""

        if self.affinity_learning is None or not plan.domains:
            return plan
        tool_ids = tuple(dict.fromkeys(item.tool_id for item in plan.tools))
        if len(tool_ids) < 2:
            return plan
        try:
            if not self.affinity_learning.enabled:
                return plan
            ordered = await asyncio.wait_for(
                self.affinity_learning.sort_by_affinity(
                    tool_ids,
                    plan.domains[0],
                ),
                timeout=self.timeouts.affinity_learning_seconds,
            )
            if (
                not isinstance(ordered, tuple)
                or len(ordered) != len(tool_ids)
                or len(set(ordered)) != len(ordered)
                or set(ordered) != set(tool_ids)
            ):
                raise ValueError("affinity ordering must be an exact permutation")
        except TimeoutError:
            return _replace_plan(
                plan,
                reason_codes=plan.reason_codes
                + ("affinity_sort_timeout_original_order",),
            )
        except Exception:  # noqa: BLE001 - P4 sorting is optional
            return _replace_plan(
                plan,
                reason_codes=plan.reason_codes
                + ("affinity_sort_error_original_order",),
            )

        order = {tool_id: index for index, tool_id in enumerate(ordered)}
        tools = tuple(sorted(plan.tools, key=lambda item: order[item.tool_id]))
        return _replace_plan(
            plan,
            tools=tools,
            display_tools=tools,
            reason_codes=plan.reason_codes + ("affinity_sort_applied",),
        )

    async def _prepare_user_turn_history(
        self,
        request: CerebellumRequest,
        context: RequestContext,
        history: UserTurnHistory | None,
    ) -> tuple[tuple[str, ...], bool]:
        if (
            history is None
            or not history.turns
            or not self.planner.config.wechat_gate_enabled
        ):
            return (), False

        semaphore = asyncio.Semaphore(_USER_HISTORY_REDACTION_CONCURRENCY)

        async def redact_turn(index: int, text: str):
            async with semaphore:
                return await self.redactor.redact(
                    CerebellumRequest(
                        text=text,
                        request_id=f"{request.request_id}.user-history.{index}",
                        session_id=request.session_id,
                        locale=request.locale,
                    ),
                    context,
                )

        try:
            redactions = await asyncio.wait_for(
                asyncio.gather(
                    *(
                        redact_turn(index, text)
                        for index, text in enumerate(history.turns)
                    ),
                    return_exceptions=True,
                ),
                timeout=self.timeouts.user_history_seconds,
            )
        except TimeoutError:
            return (), True

        safe_turns: list[str] = []
        degraded = False
        for redaction in redactions:
            if isinstance(redaction, BaseException):
                degraded = True
                continue
            try:
                redaction = RedactionResult.model_validate(redaction)
            except Exception:  # noqa: BLE001 - malformed history fails restrictive
                degraded = True
                continue
            if (
                redaction.policy_action is RedactionAction.BLOCK
                or redaction.data_classification is DataClassification.L4
            ):
                degraded = True
                continue
            safe_turns.append(redaction.redacted_text)
        return tuple(safe_turns), degraded

    async def _prepare_ltm_context(
        self,
        request: CerebellumRequest,
        context: RequestContext,
        ltm_context: list[dict[str, object]] | None,
    ) -> tuple[SafeLtmContextEntry, ...]:
        if not ltm_context:
            return ()
        try:
            raw_entries = ltm_context[:_LTM_CONTEXT_LIMIT]
        except (KeyError, TypeError):
            return ()

        entries: list[LtmContextEntry] = []
        for raw_entry in raw_entries:
            try:
                entries.append(LtmContextEntry.model_validate(raw_entry))
            except Exception:  # noqa: BLE001, S112 - optional input is ignored
                continue
        if not entries:
            return ()

        try:
            redactions = await asyncio.wait_for(
                asyncio.gather(
                    *(
                        self.redactor.redact(
                            CerebellumRequest(
                                text=entry.text,
                                request_id=f"{request.request_id}.ltm.{index}",
                                session_id=request.session_id,
                                locale=request.locale,
                            ),
                            context,
                        )
                        for index, entry in enumerate(entries)
                    ),
                    return_exceptions=True,
                ),
                timeout=self.timeouts.ltm_context_seconds,
            )
        except TimeoutError:
            return ()

        safe_entries: list[SafeLtmContextEntry] = []
        for entry, redaction in zip(entries, redactions, strict=True):
            if isinstance(redaction, BaseException):
                continue
            try:
                redaction = RedactionResult.model_validate(redaction)
            except Exception:  # noqa: BLE001, S112 - malformed history is ignored
                continue
            if (
                redaction.policy_action is RedactionAction.BLOCK
                or redaction.data_classification is DataClassification.L4
            ):
                continue
            try:
                safe_entries.append(
                    SafeLtmContextEntry(
                        redacted_text=redaction.redacted_text,
                        domains=entry.domains,
                        tools=entry.tools,
                        success=entry.success,
                        score=entry.score,
                        ts=entry.ts,
                        data_classification=redaction.data_classification,
                    )
                )
            except Exception:  # noqa: BLE001, S112 - optional input is ignored
                continue
        return tuple(safe_entries)

    async def _apply_skill_identity_visibility(
        self,
        plan: ToolBudgetPlan,
        candidates: tuple[CapabilityCandidate, ...],
        identity: IdentityContext,
    ) -> ToolBudgetPlan:
        """Apply F6 as a display-only layer after hard authorization."""

        if (
            self.skill_identity_filter is None
            or not identity.authenticated
            or (not identity.identity_labels and not identity.roles)
        ):
            return plan
        try:
            identity_filter_configured = self.skill_identity_filter.configured
        except Exception:  # noqa: BLE001 - soft identity failure must show all
            return _replace_plan(
                plan,
                reason_codes=plan.reason_codes
                + ("identity_filter_error_show_all",),
            )
        if not identity_filter_configured:
            return plan

        authorized = filter_authorized_candidates(candidates, identity)
        authorized_references = {
            (candidate.tool.tool_id, candidate.action.action_id)
            for candidate in authorized
        }
        try:
            visibility = SkillIdentityVisibility.model_validate(
                await asyncio.wait_for(
                    self.skill_identity_filter.evaluate(identity, authorized),
                    timeout=self.timeouts.skill_identity_filter_seconds,
                )
            )
        except TimeoutError:
            return _replace_plan(
                plan,
                reason_codes=plan.reason_codes
                + ("identity_filter_timeout_show_all",),
            )
        except Exception:  # noqa: BLE001 - soft identity failure must show all
            return _replace_plan(
                plan,
                reason_codes=plan.reason_codes
                + ("identity_filter_error_show_all",),
            )

        hidden = {
            (item.tool_id, item.action_id)
            for item in visibility.hidden_capabilities
        }
        if not hidden.issubset(authorized_references):
            return _replace_plan(
                plan,
                reason_codes=plan.reason_codes
                + ("identity_filter_invalid_show_all",),
            )
        if not hidden and not visibility.reason_codes:
            return plan

        display_tools = tuple(
            item
            for item in plan.tools
            if (item.tool_id, item.action_id) not in hidden
        )
        return _replace_plan(
            plan,
            display_tools=display_tools,
            reason_codes=plan.reason_codes + visibility.reason_codes,
        )


def filter_authorized_candidates(
    candidates: tuple[CapabilityCandidate, ...],
    identity: IdentityContext,
) -> tuple[CapabilityCandidate, ...]:
    visible: list[CapabilityCandidate] = []
    seen: set[tuple[str, str]] = set()
    for candidate in candidates:
        key = (candidate.tool.tool_id, candidate.action.action_id)
        if key in seen or not _candidate_is_authorized(candidate, identity):
            continue
        seen.add(key)
        visible.append(candidate)
    return tuple(visible)


def _candidate_is_authorized(
    candidate: CapabilityCandidate,
    identity: IdentityContext,
) -> bool:
    tool = candidate.tool
    if tool.allowed_tenants and (
        not identity.authenticated or identity.tenant_id not in tool.allowed_tenants
    ):
        return False
    if tool.allowed_roles and (
        not identity.authenticated or not tool.allowed_roles.intersection(identity.roles)
    ):
        return False
    return not tool.required_permissions or (
        identity.authenticated
        and tool.required_permissions.issubset(identity.granted_scopes)
    )


def _references(
    candidates: tuple[CapabilityCandidate, ...],
) -> tuple[CapabilityReference, ...]:
    return tuple(
        CapabilityReference(
            tool_id=candidate.tool.tool_id,
            action_id=candidate.action.action_id,
        )
        for candidate in candidates
    )


def _tool_count(candidates: tuple[CapabilityCandidate, ...]) -> int:
    return len({candidate.tool.tool_id for candidate in candidates})


def _candidate_matches_domains(
    candidate: CapabilityCandidate,
    domains: tuple[str, ...],
    rules: tuple[DomainKeywordRule, ...],
) -> bool:
    normalized_tags = {
        unicodedata.normalize("NFKC", tag).casefold()
        for tag in candidate.action.tags
    }
    normalized_domains = {domain.casefold() for domain in domains}
    if normalized_domains.intersection(normalized_tags):
        return True
    normalized_tool_id = unicodedata.normalize(
        "NFKC",
        candidate.tool.tool_id,
    ).casefold()
    return any(
        normalized_tool_id.startswith(_normalize_keyword(prefix))
        for rule in rules
        if rule.domain.casefold() in normalized_domains
        for prefix in rule.tool_prefixes
    )


def _select_configured_tools(
    authorized: tuple[CapabilityCandidate, ...],
    tool_ids: tuple[str, ...],
) -> tuple[CapabilityCandidate, ...]:
    selected_ids = set(tool_ids)
    return tuple(
        candidate
        for candidate in authorized
        if candidate.tool.tool_id in selected_ids
    )


def _select_configured_tools_ordered(
    authorized: tuple[CapabilityCandidate, ...],
    tool_ids: tuple[str, ...],
) -> tuple[CapabilityCandidate, ...]:
    """Preserve trusted fallback ranking while retaining action order per tool."""

    ordered_ids = tuple(dict.fromkeys(tool_ids))
    return tuple(
        candidate
        for tool_id in ordered_ids
        for candidate in authorized
        if candidate.tool.tool_id == tool_id
    )


def _append_configured_tools(
    selected: tuple[CapabilityCandidate, ...],
    authorized: tuple[CapabilityCandidate, ...],
    tool_ids: tuple[str, ...],
) -> tuple[CapabilityCandidate, ...]:
    selected_keys = {
        (candidate.tool.tool_id, candidate.action.action_id)
        for candidate in selected
    }
    include_ids = set(tool_ids)
    return (
        *selected,
        *(
            candidate
            for candidate in authorized
            if candidate.tool.tool_id in include_ids
            and (candidate.tool.tool_id, candidate.action.action_id)
            not in selected_keys
        ),
    )


def _normalize_dynamic_tool_ids(
    proposed: tuple[str, ...],
    *,
    authorized_tool_ids: set[str],
    excluded_tool_ids: set[str],
    limit: int,
) -> tuple[str, ...]:
    if len(proposed) > limit:
        raise ValueError("affinity result exceeds requested limit")
    normalized: list[str] = []
    seen: set[str] = set()
    for tool_id in proposed:
        if not isinstance(tool_id, str) or not _CAPABILITY_ID_PATTERN.fullmatch(tool_id):
            raise TypeError("affinity result contains an invalid tool ID")
        if (
            tool_id in seen
            or tool_id in excluded_tool_ids
            or tool_id not in authorized_tool_ids
        ):
            continue
        seen.add(tool_id)
        normalized.append(tool_id)
    return tuple(normalized)


def _include_configured_tools(
    selected: tuple[CapabilityCandidate, ...],
    authorized: tuple[CapabilityCandidate, ...],
    tool_ids: tuple[str, ...],
) -> tuple[CapabilityCandidate, ...]:
    selected_keys = {
        (candidate.tool.tool_id, candidate.action.action_id)
        for candidate in selected
    }
    include_ids = set(tool_ids)
    return tuple(
        candidate
        for candidate in authorized
        if (
            (candidate.tool.tool_id, candidate.action.action_id) in selected_keys
            or candidate.tool.tool_id in include_ids
        )
    )


def _include_ltm_tools(
    selected: tuple[CapabilityCandidate, ...],
    authorized: tuple[CapabilityCandidate, ...],
    ltm_context: tuple[SafeLtmContextEntry, ...],
) -> tuple[CapabilityCandidate, ...]:
    remembered_tools = {
        unicodedata.normalize("NFKC", tool).strip().casefold()
        for entry in ltm_context
        if entry.success and entry.score >= _LTM_MIN_SCORE
        for tool in entry.tools
    }
    if not remembered_tools:
        return selected

    selected_keys = {
        (candidate.tool.tool_id, candidate.action.action_id)
        for candidate in selected
    }
    return tuple(
        candidate
        for candidate in authorized
        if (
            (candidate.tool.tool_id, candidate.action.action_id) in selected_keys
            or unicodedata.normalize(
                "NFKC",
                candidate.tool.tool_id,
            ).strip().casefold()
            in remembered_tools
            or unicodedata.normalize(
                "NFKC",
                candidate.tool.name,
            ).strip().casefold()
            in remembered_tools
        )
    )


def _compute_budget(
    request: SafeRoutingRequest,
    *,
    domains: tuple[str, ...],
    risk_level: RiskLevel,
) -> ComputeBudget:
    text_length = len(request.redacted_text)
    if text_length <= 80 and len(domains) <= 1:
        level = ComputeBudgetLevel.LOW
        max_rounds = 2
        thinking_effort = "low"
        suggest_parallel = False
        suggest_retrieval = False
    elif text_length <= 512 and len(domains) <= 1:
        level = ComputeBudgetLevel.MEDIUM
        max_rounds = 4
        thinking_effort = "medium"
        suggest_parallel = False
        suggest_retrieval = True
    elif text_length <= 2_000 and len(domains) <= 2:
        level = ComputeBudgetLevel.HIGH
        max_rounds = 8
        thinking_effort = "high"
        suggest_parallel = False
        suggest_retrieval = True
    else:
        level = ComputeBudgetLevel.EXTREME
        max_rounds = 12
        thinking_effort = "high"
        suggest_parallel = True
        suggest_retrieval = True

    reason_codes: tuple[str, ...] = ("deterministic_budget",)
    if request.is_write_intent or _RISK_RANK[risk_level] >= _RISK_RANK[RiskLevel.HIGH]:
        max_rounds = min(max_rounds, 2)
        suggest_parallel = False
        reason_codes += ("high_risk_round_cap",)
    return ComputeBudget(
        level=level,
        max_rounds=max_rounds,
        thinking_effort=thinking_effort,
        suggest_parallel=suggest_parallel,
        suggest_retrieval=suggest_retrieval,
        reason_codes=reason_codes,
    )


def _safety_from_router0(
    request: SafeRoutingRequest,
    result: Router0Result,
) -> ProductSafetyDecision:
    if result.status is Router0Status.BLOCK:
        return _blocked_safety(
            result.reason_codes[0] if result.reason_codes else "router0_blocked",
            classification=request.data_classification,
            is_write_intent=request.is_write_intent,
        )
    write_intent = request.is_write_intent or result.is_write_op
    action = (
        SafetyAction.CONFIRM
        if result.status is Router0Status.CONFIRM or write_intent
        else SafetyAction.ALLOW
    )
    default_reason = (
        "write_operation_requires_confirmation"
        if action is SafetyAction.CONFIRM
        else "safety_precheck_passed"
    )
    reasons = _safe_reason_codes(result.reason_codes, default_reason)
    effective_risk = _max_risk(
        _DATA_RISK[request.data_classification],
        result.risk_level,
    )
    if write_intent:
        effective_risk = _max_risk(effective_risk, RiskLevel.HIGH)
    return ProductSafetyDecision(
        action=action,
        redacted_text=request.redacted_text,
        data_classification=request.data_classification,
        risk_level=effective_risk,
        is_write_intent=write_intent,
        reason_codes=reasons,
    )


def _blocked_safety(
    reason_code: str,
    *,
    classification: DataClassification = DataClassification.L4,
    is_write_intent: bool = False,
) -> ProductSafetyDecision:
    return ProductSafetyDecision(
        action=SafetyAction.BLOCK,
        data_classification=classification,
        risk_level=RiskLevel.CRITICAL,
        is_write_intent=is_write_intent,
        reason_codes=_safe_reason_codes((reason_code,), "safety_component_unavailable"),
    )


def _complete_product_decision(
    *,
    request_id: str,
    safety: ProductSafetyDecision,
    plan: ToolBudgetPlan,
    redacted_text: str | None,
    ltm_log_fn: LtmLogFn | None,
) -> ProductDecision:
    decision = ProductDecision(
        request_id=request_id,
        safety=safety,
        plan=plan,
    )
    if redacted_text is not None:
        dispatch_ltm_log(decision, ltm_log_fn)
    return decision


def dispatch_ltm_log(decision: ProductDecision, ltm_log_fn: LtmLogFn | None) -> None:
    """Best-effort log dispatch after the caller has accepted the final decision."""
    safety, plan = decision.safety, decision.plan
    redacted_text = safety.redacted_text
    if (
        safety.action is SafetyAction.ALLOW
        and redacted_text is not None
        and ltm_log_fn is not None
    ):
        try:
            record = LtmDecisionLog(
                user_message=redacted_text,
                domains=plan.domains,
                tools=_unique_tool_ids(plan.tools),
                level=plan.level,
                narrowed=plan.narrowed,
                degraded=plan.degraded,
                budget=plan.budget.level.value if plan.budget is not None else "none",
                ts=time(),
            ).model_dump(mode="json")
        except Exception:  # noqa: BLE001 - optional logging cannot change the decision
            return
        if not _LTM_LOG_SLOTS.acquire(blocking=False):
            return
        try:
            Thread(
                target=_run_ltm_log_callback_and_release,
                args=(ltm_log_fn, record),
                name="cerebellum-ltm-log",
                daemon=True,
            ).start()
        except Exception:  # noqa: BLE001 - logging cannot change the decision
            _LTM_LOG_SLOTS.release()


def _run_ltm_log_callback_and_release(
    callback: LtmLogFn,
    record: dict[str, object],
) -> None:
    try:
        callback(record)
    except Exception:  # noqa: BLE001, S110 - callback failures are intentionally ignored
        pass
    finally:
        _LTM_LOG_SLOTS.release()


def _unique_tool_ids(
    references: tuple[CapabilityReference, ...],
) -> tuple[str, ...]:
    return tuple(dict.fromkeys(reference.tool_id for reference in references))


def _json_sha256(payload: object) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _replace_plan(
    plan: ToolBudgetPlan,
    **updates: object,
) -> ToolBudgetPlan:
    payload = plan.model_dump(mode="python")
    payload.update(updates)
    return ToolBudgetPlan.model_validate(payload)


def _max_risk(left: RiskLevel, right: RiskLevel) -> RiskLevel:
    return left if _RISK_RANK[left] >= _RISK_RANK[right] else right


def _safe_reason_codes(
    reason_codes: tuple[str, ...],
    fallback: str,
) -> tuple[str, ...]:
    safe = tuple(
        reason_code
        for reason_code in reason_codes
        if _REASON_CODE_PATTERN.fullmatch(reason_code)
    )
    return safe or (fallback,)
