from __future__ import annotations

import asyncio
import hashlib
import re
from collections.abc import Awaitable, Callable, Iterator
from typing import TypeVar

from totalclaw_cerebellum.domain import (
    AffinitySnapshotHandle,
    ApprovalRequirement,
    AuditEvent,
    CalibratedSelectionAction,
    CapabilityCandidate,
    CatalogEvidenceStatus,
    CerebellumRequest,
    CerebellumResponse,
    ClarificationPrompt,
    ClassifierEvidenceStatus,
    ClassifierRoutingConfig,
    ConfirmationPrompt,
    DataClassification,
    HandoffEnvelope,
    HandoffReceipt,
    IntentType,
    MemoryEvent,
    MemoryWriteReceipt,
    PortTimeouts,
    ProductDecision,
    RedactionAction,
    RequestContext,
    RiskLevel,
    RoleToolsetProfile,
    RouteDecision,
    Router0Result,
    Router0Status,
    RouterProfile,
    RouterProfileEvidenceStatus,
    RouteType,
    SafeRoutingRequest,
    ServiceStatus,
    ToolPlanCacheConfig,
    ToolPlanningConfig,
    ToolPlanningProfile,
    UserTurnHistory,
)
from totalclaw_cerebellum.ports import (
    AffinityLearningPort,
    ApprovalIntrospectionPort,
    AuditPort,
    BrainPort,
    ClassifierPort,
    MemoryPort,
    OutputGuardPort,
    PolicyPort,
    RedactorPort,
    RegistryPort,
    RetrieverPort,
    Router0Port,
    Router1Port,
    SkillIdentityFilterPort,
    ToolExecutorPort,
    VaultReferencePort,
)

T = TypeVar("T")
MAX_REGISTRY_QUERY_CHARS = 4096
_CAPABILITY_ID_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")
_SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
_RISK_RANK = {
    RiskLevel.LOW: 0,
    RiskLevel.MEDIUM: 1,
    RiskLevel.HIGH: 2,
    RiskLevel.CRITICAL: 3,
}
_CLASSIFICATION_RANK = {
    DataClassification.L0: 0,
    DataClassification.L1: 1,
    DataClassification.L2: 2,
    DataClassification.L3: 3,
    DataClassification.L4: 4,
}
_DATA_RISK = {
    DataClassification.L0: RiskLevel.LOW,
    DataClassification.L1: RiskLevel.LOW,
    DataClassification.L2: RiskLevel.MEDIUM,
    DataClassification.L3: RiskLevel.HIGH,
    DataClassification.L4: RiskLevel.CRITICAL,
}


def _generated_strings(value: object) -> Iterator[str]:
    if isinstance(value, (str, int, float)):
        yield str(value)
    elif isinstance(value, dict):
        for key, item in value.items():
            yield str(key)
            for text in _generated_strings(item):
                # Preserve context such as password=value and OTP=123456, including nesting.
                yield f"{key}={text}"
    elif isinstance(value, (list, tuple)):
        for item in value:
            yield from _generated_strings(item)


class RegistrySearchRejected(RuntimeError):
    """Fixed-code failure for the safe Registry search boundary."""


class CerebellumService:
    def __init__(
        self,
        *,
        redactor: RedactorPort,
        router0: Router0Port,
        registry: RegistryPort,
        retriever: RetrieverPort,
        router1: Router1Port,
        policy: PolicyPort,
        brain: BrainPort,
        memory: MemoryPort,
        audit: AuditPort,
        executor: ToolExecutorPort,
        output_guard: OutputGuardPort,
        router_profile: RouterProfile | None = None,
        tool_planning_profile: ToolPlanningProfile | None = None,
        role_toolset_profile: RoleToolsetProfile | None = None,
        affinity_learning: AffinityLearningPort | None = None,
        approval_introspection: ApprovalIntrospectionPort | None = None,
        vault_reference: VaultReferencePort | None = None,
        skill_identity_filter: SkillIdentityFilterPort | None = None,
        classifier: ClassifierPort | None = None,
        classifier_routing_config: ClassifierRoutingConfig | None = None,
        tool_plan_cache_config: ToolPlanCacheConfig | None = None,
        timeouts: PortTimeouts | None = None,
        version: str = "0.26.2",
    ) -> None:
        if (
            tool_planning_profile is not None
            and tool_planning_profile.catalog_id != registry.catalog_id
        ):
            raise ValueError("tool_planning_profile_catalog_mismatch")
        if (
            role_toolset_profile is not None
            and role_toolset_profile.catalog_id != registry.catalog_id
        ):
            raise ValueError("role_toolset_profile_catalog_mismatch")
        self.redactor = redactor
        self.router0 = router0
        self.registry = registry
        self.retriever = retriever
        self.router1 = router1
        self.policy = policy
        self.brain = brain
        self.memory = memory
        self.audit = audit
        self.executor = executor
        self.output_guard = output_guard
        self.router_profile = router_profile
        self.tool_planning_profile = tool_planning_profile
        self.role_toolset_profile = role_toolset_profile
        self.affinity_learning = affinity_learning
        self.approval_introspection = approval_introspection
        self.vault_reference = vault_reference
        self.skill_identity_filter = skill_identity_filter
        self.classifier = classifier
        self.classifier_routing_config = (
            classifier_routing_config or ClassifierRoutingConfig()
        )
        self.tool_planning_config = (
            tool_planning_profile.config
            if tool_planning_profile is not None
            else ToolPlanningConfig(enabled=False)
        )
        self.tool_plan_cache_config = tool_plan_cache_config or ToolPlanCacheConfig()
        self.timeouts = timeouts or PortTimeouts()
        self.version = version
        from .calibrated_router import CalibratedClassificationRouter
        from .plan_cache import ToolPlanCache
        from .product_decision import ProductDecisionService

        self._tool_plan_cache = ToolPlanCache(self.tool_plan_cache_config)
        self._calibrated_router = CalibratedClassificationRouter(
            classifier=classifier,
            config=self.classifier_routing_config,
            timeout_seconds=self.timeouts.classifier_seconds,
        )
        self._product_decision_service = ProductDecisionService(
            redactor=self.redactor,
            router0=self.router0,
            audit=self.audit,
            timeouts=self.timeouts,
            planning_config=self.tool_planning_config,
            affinity_learning=self.affinity_learning,
            skill_identity_filter=self.skill_identity_filter,
            plan_cache=self._tool_plan_cache,
            catalog_version=_registry_catalog_version(self.registry),
            profile_version=_tool_planning_version(
                self.tool_planning_config,
                profile_id=(
                    self.tool_planning_profile.profile_id
                    if self.tool_planning_profile is not None
                    else None
                ),
            ),
        )

    def status(self) -> ServiceStatus:
        return ServiceStatus(
            status="ok",
            version=self.version,
            registry_configured=self.registry.configured,
            catalog_id=self.registry.catalog_id,
            catalog_evidence_status=self.registry.evidence_status,
            capability_count=self.registry.capability_count,
            retriever_kind=self.retriever.kind,
            router1_configured=self.router1.configured,
            router_profile_configured=self.router_profile is not None,
            router_profile_id=(
                self.router_profile.profile_id
                if self.router_profile is not None
                else None
            ),
            router_profile_evidence_status=(
                self.router_profile.evidence_status
                if self.router_profile is not None
                else None
            ),
            router_tool_direct_enabled=(
                self.router_profile is not None
                and self.router_profile.evidence_status
                is RouterProfileEvidenceStatus.VALIDATED
                and self.router_profile.tool_direct_enabled
            ),
            router_slm_answer_enabled=(
                self.router_profile is not None
                and self.router_profile.evidence_status
                is RouterProfileEvidenceStatus.VALIDATED
                and self.router_profile.slm_answer_enabled
            ),
            tool_planning_configured=self.tool_planning_profile is not None,
            tool_planning_profile_id=(
                self.tool_planning_profile.profile_id
                if self.tool_planning_profile is not None
                else None
            ),
            tool_planning_evidence_status=(
                self.tool_planning_profile.evidence_status
                if self.tool_planning_profile is not None
                else None
            ),
            f4_fallback_ready=(
                self.tool_planning_profile is not None
                and self.tool_planning_profile.evidence_status
                is CatalogEvidenceStatus.VALIDATED
                and self.registry.evidence_status is CatalogEvidenceStatus.VALIDATED
            ),
            affinity_learning_enabled=_port_is_enabled(self.affinity_learning),
            approval_introspection_configured=_port_is_configured(
                self.approval_introspection
            ),
            wechat_gate_configured=self.tool_planning_config.wechat_gate_enabled,
            f7_wechat_gate_ready=(
                self.tool_planning_profile is not None
                and self.tool_planning_profile.evidence_status
                is CatalogEvidenceStatus.VALIDATED
                and self.registry.evidence_status is CatalogEvidenceStatus.VALIDATED
                and self.tool_planning_config.wechat_gate_enabled
            ),
            skill_identity_filter_configured=_port_is_configured(
                self.skill_identity_filter
            ),
            role_toolset_profile_configured=self.role_toolset_profile is not None,
            role_toolset_profile_id=(
                self.role_toolset_profile.profile_id
                if self.role_toolset_profile is not None
                else None
            ),
            role_toolset_evidence_status=(
                self.role_toolset_profile.evidence_status
                if self.role_toolset_profile is not None
                else None
            ),
            f6_role_toolset_ready=(
                self.role_toolset_profile is not None
                and self.role_toolset_profile.evidence_status
                is CatalogEvidenceStatus.VALIDATED
                and self.registry.evidence_status is CatalogEvidenceStatus.VALIDATED
            ),
            vault_reference_validation_configured=_port_is_configured(
                self.vault_reference
            ),
            f13_vault_reference_ready=_port_is_configured(self.vault_reference),
            tool_plan_cache_enabled=self.tool_plan_cache_config.enabled,
            tool_plan_cache_ttl_seconds=self.tool_plan_cache_config.ttl_seconds,
            tool_plan_cache_max_entries=self.tool_plan_cache_config.max_entries,
            classifier_configured=self._calibrated_router.active,
            classifier_id=_classifier_attribute(self.classifier, "classifier_id"),
            classifier_evidence_status=_classifier_evidence(self.classifier),
            classifier_routing_enabled=self.classifier_routing_config.enabled,
            brain_configured=self.brain.configured,
            memory_enabled=self.memory.enabled,
            executor_enabled=self.executor.enabled,
        )

    async def search_registry(
        self,
        query: str,
        context: RequestContext,
        limit: int = 5,
    ) -> tuple[CapabilityCandidate, ...]:
        if not 1 <= len(query) <= MAX_REGISTRY_QUERY_CHARS:
            raise RegistrySearchRejected("registry_search_query_invalid")
        if not 1 <= limit <= 50:
            raise RegistrySearchRejected("registry_search_limit_invalid")

        request = CerebellumRequest(text=query)
        try:
            redaction = await _within(
                self.redactor.redact(request, context),
                self.timeouts.redactor_seconds,
            )
        except TimeoutError:
            raise RegistrySearchRejected("registry_search_redactor_timeout") from None
        except Exception:  # noqa: BLE001 - port details must not cross the boundary
            raise RegistrySearchRejected("registry_search_redactor_unavailable") from None
        if redaction.policy_action is RedactionAction.BLOCK:
            raise RegistrySearchRejected("registry_search_blocked")

        try:
            candidates = await _within(
                self.registry.list_authorized(context.identity),
                self.timeouts.registry_seconds,
            )
        except TimeoutError:
            raise RegistrySearchRejected("registry_search_registry_timeout") from None
        except Exception:  # noqa: BLE001 - port details must not cross the boundary
            raise RegistrySearchRejected("registry_search_registry_unavailable") from None
        try:
            return await _within(
                self.retriever.retrieve(redaction.redacted_text, candidates, limit),
                self.timeouts.retriever_seconds,
            )
        except TimeoutError:
            raise RegistrySearchRejected("registry_search_retriever_timeout") from None
        except Exception:  # noqa: BLE001 - port details must not cross the boundary
            raise RegistrySearchRejected("registry_search_retriever_unavailable") from None

    async def identity_failure_response(
        self,
        request: CerebellumRequest,
        reason_code: str,
    ) -> CerebellumResponse:
        return await self._terminal_block(
            request.request_id,
            DataClassification.L4,
            reason_code,
        )

    async def route(
        self,
        request: CerebellumRequest,
        context: RequestContext,
    ) -> CerebellumResponse:
        try:
            redaction = await _within(
                self.redactor.redact(request, context),
                self.timeouts.redactor_seconds,
            )
        except TimeoutError:
            return await self._terminal_block(
                request.request_id,
                DataClassification.L4,
                "redactor_timeout",
            )
        except Exception:  # noqa: BLE001 - port failures must not escape the boundary
            return await self._terminal_block(
                request.request_id,
                DataClassification.L4,
                "redactor_unavailable",
            )

        if redaction.policy_action is RedactionAction.BLOCK:
            reason_code = (
                redaction.reason_codes[0]
                if redaction.reason_codes
                else "redaction_blocked"
            )
            return await self._terminal_block(
                request.request_id,
                redaction.data_classification,
                reason_code,
            )

        safe_request = SafeRoutingRequest(
            request_id=request.request_id,
            session_id=request.session_id,
            locale=request.locale,
            redacted_text=redaction.redacted_text,
            data_classification=redaction.data_classification,
            redaction_action=redaction.policy_action,
            is_write_intent=request.is_write_intent,
        )

        try:
            router0_result = await _within(
                self.router0.route(safe_request, context),
                self.timeouts.router0_seconds,
            )
        except TimeoutError:
            return await self._terminal_block(
                request.request_id,
                safe_request.data_classification,
                "router0_timeout",
            )
        except Exception:  # noqa: BLE001 - port failures must not escape the boundary
            return await self._terminal_block(
                request.request_id,
                safe_request.data_classification,
                "router0_unavailable",
            )

        safe_request = safe_request.model_copy(
            update={
                "is_write_intent": (
                    safe_request.is_write_intent or router0_result.is_write_op
                )
            }
        )
        preliminary, answer, candidates = await self._route_preliminary(
            safe_request,
            context,
            router0_result,
        )
        if preliminary.route_decision is RouteType.BLOCK:
            return await self._terminal_block(
                request.request_id,
                preliminary.data_classification,
                preliminary.policy_reasons[0]
                if preliminary.policy_reasons
                else "router0_blocked",
                is_write_intent=safe_request.is_write_intent,
            )

        try:
            decision = await _within(
                self.policy.evaluate(
                    safe_request,
                    context,
                    preliminary,
                    candidates,
                ),
                self.timeouts.policy_seconds,
            )
        except TimeoutError:
            return await self._terminal_block(
                request.request_id,
                safe_request.data_classification,
                "policy_timeout",
                is_write_intent=safe_request.is_write_intent,
            )
        except Exception:  # noqa: BLE001 - port failures must not escape the boundary
            return await self._terminal_block(
                request.request_id,
                safe_request.data_classification,
                "policy_unavailable",
                is_write_intent=safe_request.is_write_intent,
            )

        if decision.route_decision is not RouteType.SLM_ANSWER:
            answer = None
        elif answer is None:
            decision = _handoff_decision(
                safe_request.data_classification,
                "slm_answer_missing",
            )
        else:
            try:
                guarded_answer = await _within(
                    self.output_guard.inspect(
                        answer,
                        context,
                        source_redacted_text=safe_request.redacted_text,
                    ),
                    self.timeouts.output_guard_seconds,
                )
            except TimeoutError:
                return await self._terminal_block(
                    request.request_id,
                    DataClassification.L4,
                    "output_guard_timeout",
                    is_write_intent=safe_request.is_write_intent,
                )
            except Exception:  # noqa: BLE001 - generated output must fail closed
                return await self._terminal_block(
                    request.request_id,
                    DataClassification.L4,
                    "output_guard_unavailable",
                    is_write_intent=safe_request.is_write_intent,
                )

            if guarded_answer.policy_action is RedactionAction.BLOCK:
                return await self._terminal_block(
                    request.request_id,
                    _max_classification(
                        decision.data_classification,
                        guarded_answer.data_classification,
                    ),
                    "slm_answer_output_blocked",
                    is_write_intent=safe_request.is_write_intent,
                )

            answer = guarded_answer.redacted_text
            if guarded_answer.policy_action is RedactionAction.REDACT:
                output_classification = _max_classification(
                    decision.data_classification,
                    guarded_answer.data_classification,
                )
                decision = _replace_decision(
                    decision,
                    data_classification=output_classification,
                    risk_level=_max_risk(
                        decision.risk_level,
                        _data_risk(output_classification),
                    ),
                    policy_reasons=decision.policy_reasons
                    + ("slm_answer_output_redacted",),
                )

        return await self._finalize(
            safe_request=safe_request,
            context=context,
            decision=decision,
            answer=answer,
            candidates=candidates,
        )

    async def decide_v2(
        self,
        request: CerebellumRequest,
        context: RequestContext,
        available_candidates: tuple[CapabilityCandidate, ...],
        *,
        planning_config: ToolPlanningConfig | None = None,
        ltm_context: list[dict[str, object]] | None = None,
        ltm_log_fn: Callable[[dict[str, object]], None] | None = None,
        user_turn_history: UserTurnHistory | None = None,
    ) -> ProductDecision:
        """Return independent safety and tool/budget channels for a host integration."""

        if planning_config is not None and self.tool_planning_profile is not None:
            raise ValueError("tool_planning_profile_override_forbidden")
        if planning_config is None:
            product_service = self._product_decision_service
        else:
            from .product_decision import ProductDecisionService

            product_service = ProductDecisionService(
                redactor=self.redactor,
                router0=self.router0,
                audit=self.audit,
                timeouts=self.timeouts,
                planning_config=planning_config,
                affinity_learning=self.affinity_learning,
                skill_identity_filter=self.skill_identity_filter,
                plan_cache=self._tool_plan_cache,
                catalog_version=_registry_catalog_version(self.registry),
                profile_version=_tool_planning_version(planning_config),
            )
        decision = await product_service.decide(
            request,
            context,
            available_candidates,
            ltm_context=ltm_context,
            ltm_log_fn=ltm_log_fn,
            user_turn_history=user_turn_history,
        )
        return decision

    async def snapshot_affinity_learning(self) -> AffinitySnapshotHandle | None:
        """Capture an opaque P4 replay handle without exposing host learning state."""

        if self.affinity_learning is None or not _port_is_enabled(
            self.affinity_learning
        ):
            return None
        try:
            snapshot = await _within(
                self.affinity_learning.snapshot(),
                self.timeouts.affinity_learning_seconds,
            )
            if snapshot is None:
                return None
            return AffinitySnapshotHandle.model_validate(snapshot)
        except Exception:  # noqa: BLE001 - snapshot failure cannot affect routing
            return None

    async def restore_affinity_learning(
        self,
        snapshot: AffinitySnapshotHandle,
    ) -> bool:
        """Restore only an already validated opaque P4 replay handle."""

        if self.affinity_learning is None or not _port_is_enabled(
            self.affinity_learning
        ):
            return False
        try:
            validated = AffinitySnapshotHandle.model_validate(snapshot)
            await _within(
                self.affinity_learning.restore(validated),
                self.timeouts.affinity_learning_seconds,
            )
            return True
        except Exception:  # noqa: BLE001 - restore failure cannot affect routing
            return False

    async def inspect_host_approval(
        self,
        tool_id: str,
        args_digest: str,
    ) -> ApprovalRequirement:
        """Read a P11 hint without changing confirmation or execution policy."""

        if (
            self.approval_introspection is None
            or not _CAPABILITY_ID_PATTERN.fullmatch(tool_id)
            or not _SHA256_PATTERN.fullmatch(args_digest)
        ):
            return ApprovalRequirement.UNKNOWN
        try:
            if not self.approval_introspection.configured:
                return ApprovalRequirement.UNKNOWN
            result = await _within(
                self.approval_introspection.would_require_approval(
                    tool_id,
                    args_digest,
                ),
                self.timeouts.approval_introspection_seconds,
            )
            return ApprovalRequirement(result)
        except Exception:  # noqa: BLE001 - P11 is explanatory and read-only
            return ApprovalRequirement.UNKNOWN

    async def _route_preliminary(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
        router0_result: Router0Result,
    ) -> tuple[
        RouteDecision,
        str | None,
        tuple[CapabilityCandidate, ...],
    ]:
        if router0_result.status is Router0Status.BLOCK:
            return _router0_decision(request, router0_result, RouteType.BLOCK), None, ()
        if router0_result.status is Router0Status.CONFIRM:
            return _router0_decision(request, router0_result, RouteType.CONFIRM), None, ()

        try:
            registered = await _within(
                self.registry.list_authorized(context.identity),
                self.timeouts.registry_seconds,
            )
        except TimeoutError:
            return _handoff_decision(
                request.data_classification,
                "registry_timeout",
            ), None, ()
        except Exception:  # noqa: BLE001 - port failures must not escape the boundary
            return _handoff_decision(
                request.data_classification,
                "registry_unavailable",
            ), None, ()

        try:
            candidates = await _within(
                self.retriever.retrieve(request.redacted_text, registered, 5),
                self.timeouts.retriever_seconds,
            )
        except TimeoutError:
            return _handoff_decision(
                request.data_classification,
                "retriever_timeout",
            ), None, ()
        except Exception:  # noqa: BLE001 - port failures must not escape the boundary
            return _handoff_decision(
                request.data_classification,
                "retriever_unavailable",
            ), None, ()

        calibration = await self._calibrated_router.evaluate(request, candidates)
        if calibration.action is CalibratedSelectionAction.ESCALATE:
            # A suspected injection or a heavy risk tail must not be adjudicated
            # by the cheap tier; hand the turn straight to the Brain fallback.
            return _handoff_decision(
                request.data_classification,
                calibration.reason_codes[0]
                if calibration.reason_codes
                else "classifier_escalated",
            ), None, candidates
        if (
            calibration.action is CalibratedSelectionAction.ACCEPT
            and calibration.selected is not None
        ):
            narrowed = tuple(
                candidate
                for candidate in candidates
                if candidate.tool.tool_id == calibration.selected.tool_id
                and candidate.action.action_id == calibration.selected.action_id
            )
            if narrowed:
                candidates = narrowed

        try:
            router1_output = await _within(
                self.router1.route(request, context, candidates),
                self.timeouts.router1_seconds,
            )
        except TimeoutError:
            return _handoff_decision(
                request.data_classification,
                "router1_timeout",
            ), None, candidates
        except Exception:  # noqa: BLE001 - port failures must not escape the boundary
            return _handoff_decision(
                request.data_classification,
                "router1_unavailable",
            ), None, candidates

        decision = router1_output.decision
        try:
            structured_text = "\n".join(_generated_strings({
                "slots": decision.slots,
                "selected_tool": decision.selected_tool,
                "selected_action": decision.selected_action,
                "missing_required": decision.missing_required,
                "handoff_reason": decision.handoff_reason,
                "policy_reasons": decision.policy_reasons,
            }))
            guarded = await _within(
                self.output_guard.inspect(
                    structured_text, context,
                    source_redacted_text=request.redacted_text,
                ),
                self.timeouts.output_guard_seconds,
            )
        except TimeoutError:
            return _block_decision(
                DataClassification.L4, "output_guard_timeout",
                is_write_intent=request.is_write_intent,
            ), None, ()
        except Exception:  # noqa: BLE001 - structured output must also fail closed
            return _block_decision(
                DataClassification.L4, "output_guard_unavailable",
                is_write_intent=request.is_write_intent,
            ), None, ()
        if guarded.policy_action is not RedactionAction.ALLOW:
            # Never silently rewrite arguments or emit new placeholders as tool input.
            return _block_decision(
                _max_classification(request.data_classification, guarded.data_classification),
                "router1_structured_output_blocked",
                is_write_intent=request.is_write_intent,
            ), None, ()
        return decision, router1_output.answer, candidates

    async def _finalize(
        self,
        *,
        safe_request: SafeRoutingRequest,
        context: RequestContext,
        decision: RouteDecision,
        answer: str | None,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> CerebellumResponse:
        audit_failure = await self._audit(safe_request.request_id, decision)
        if audit_failure is not None:
            blocked_decision = _block_decision(
                safe_request.data_classification,
                audit_failure,
                is_write_intent=safe_request.is_write_intent,
            )
            return CerebellumResponse(
                decision=blocked_decision,
            )

        handoff: HandoffReceipt | None = None
        if decision.route_decision is RouteType.BRAIN_HANDOFF:
            envelope = HandoffEnvelope(
                request_id=safe_request.request_id,
                tenant_id=context.identity.tenant_id,
                user_id=context.identity.user_id,
                session_id=safe_request.session_id,
                channel=context.channel,
                locale=safe_request.locale,
                redacted_text=safe_request.redacted_text,
                data_classification=decision.data_classification,
                policy_reasons=decision.policy_reasons,
                candidate_tool_ids=tuple(
                    candidate.tool.tool_id for candidate in candidates
                ),
                candidate_action_ids=tuple(
                    candidate.action.action_id for candidate in candidates
                ),
            )
            try:
                handoff = await _within(
                    self.brain.handoff(envelope),
                    self.timeouts.brain_seconds,
                )
            except TimeoutError:
                handoff = HandoffReceipt(accepted=False, reason="brain_timeout")
            except Exception:  # noqa: BLE001 - preserve a rejected handoff receipt
                handoff = HandoffReceipt(accepted=False, reason="brain_unavailable")

        clarification = None
        if decision.route_decision is RouteType.CLARIFY:
            clarification = ClarificationPrompt(
                question="请补充完成请求所需的信息。",
                missing_required=decision.missing_required,
            )

        confirmation = None
        if decision.route_decision is RouteType.CONFIRM:
            confirmation = ConfirmationPrompt(
                prompt="该操作需要用户确认，当前阶段不会执行。",
                reason_codes=decision.policy_reasons,
            )

        memory = await self._write_memory(safe_request, context, decision)
        return CerebellumResponse(
            decision=decision,
            answer=answer,
            clarification=clarification,
            confirmation=confirmation,
            handoff=handoff,
            memory=memory,
        )

    async def _terminal_block(
        self,
        request_id: str,
        classification: DataClassification,
        reason_code: str,
        *,
        is_write_intent: bool = False,
    ) -> CerebellumResponse:
        decision = _block_decision(
            classification,
            reason_code,
            is_write_intent=is_write_intent,
        )
        audit_failure = await self._audit(request_id, decision)
        if audit_failure is not None:
            decision = _block_decision(
                classification,
                audit_failure,
                is_write_intent=is_write_intent,
            )
        return CerebellumResponse(
            decision=decision,
        )

    async def _audit(
        self,
        request_id: str,
        decision: RouteDecision,
    ) -> str | None:
        event = AuditEvent(
            trace_id=decision.trace_id,
            request_id=request_id,
            event_type="route_decision",
            data_classification=decision.data_classification,
            risk_level=decision.risk_level,
            reason_codes=decision.policy_reasons,
        )
        try:
            await _within(
                self.audit.record(event),
                self.timeouts.audit_seconds,
            )
        except TimeoutError:
            return "audit_timeout"
        except Exception:  # noqa: BLE001 - audit failure is converted to block
            return "audit_unavailable"
        return None

    async def _write_memory(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
        decision: RouteDecision,
    ) -> MemoryWriteReceipt | None:
        if (
            not context.memory_write_allowed
            or decision.route_decision
            in {RouteType.CLARIFY, RouteType.CONFIRM, RouteType.BLOCK}
        ):
            return None
        event = MemoryEvent(
            tenant_id=context.identity.tenant_id,
            session_id=request.session_id,
            event_type="route_decision",
            redacted_payload={
                "request_id": request.request_id,
                "route": decision.route_decision,
                "risk_level": decision.risk_level,
                "selected_tool": decision.selected_tool,
                "selected_action": decision.selected_action,
            },
            data_classification=decision.data_classification,
        )
        try:
            return await _within(
                self.memory.append(event),
                self.timeouts.memory_seconds,
            )
        except TimeoutError:
            return MemoryWriteReceipt(
                persisted=False,
                reason="memory_timeout",
            )
        except Exception:  # noqa: BLE001 - memory failure cannot change the decision
            return MemoryWriteReceipt(
                persisted=False,
                reason="memory_unavailable",
            )


async def _within(awaitable: Awaitable[T], timeout_seconds: float) -> T:
    return await asyncio.wait_for(awaitable, timeout=timeout_seconds)


def _port_is_configured(port: object | None) -> bool:
    if port is None:
        return False
    try:
        return bool(port.configured)
    except Exception:  # noqa: BLE001 - status must not expose adapter failures
        return False


def _port_is_enabled(port: object | None) -> bool:
    if port is None:
        return False
    try:
        return bool(port.enabled)
    except Exception:  # noqa: BLE001 - status must not expose adapter failures
        return False


def _tool_planning_version(
    config: ToolPlanningConfig,
    *,
    profile_id: str | None = None,
) -> str:
    digest = hashlib.sha256(
        config.model_dump_json().encode("utf-8")
    ).hexdigest()
    return f"{profile_id or 'inline'}:{digest}"


def _registry_catalog_version(registry: RegistryPort) -> str:
    try:
        return registry.catalog_id or "catalog-unconfigured"
    except Exception:  # noqa: BLE001 - optional cache metadata cannot break service
        return "catalog-unconfigured"


def _replace_decision(decision: RouteDecision, **updates: object) -> RouteDecision:
    values = decision.model_dump(mode="python")
    values.update(updates)
    return RouteDecision.model_validate(values)


def _max_risk(*values: RiskLevel) -> RiskLevel:
    return max(values, key=_RISK_RANK.__getitem__)


def _max_classification(
    *values: DataClassification,
) -> DataClassification:
    return max(values, key=_CLASSIFICATION_RANK.__getitem__)


def _data_risk(value: DataClassification) -> RiskLevel:
    return _DATA_RISK[value]


def _router0_decision(
    request: SafeRoutingRequest,
    result: Router0Result,
    route: RouteType,
) -> RouteDecision:
    return RouteDecision(
        intent_type=IntentType.TOOL,
        route_decision=route,
        confidence=1.0,
        is_write_op=request.is_write_intent or result.is_write_op,
        risk_level=result.risk_level,
        data_classification=request.data_classification,
        handoff_reason=result.reason_codes[0] if result.reason_codes else None,
        policy_reasons=result.reason_codes,
    )


def _block_decision(
    classification: DataClassification,
    reason_code: str,
    *,
    is_write_intent: bool = False,
) -> RouteDecision:
    return RouteDecision(
        intent_type=IntentType.SENSITIVE,
        route_decision=RouteType.BLOCK,
        confidence=1.0,
        is_write_op=is_write_intent,
        risk_level=RiskLevel.CRITICAL,
        data_classification=classification,
        handoff_reason=reason_code,
        policy_reasons=(reason_code,),
    )


def _handoff_decision(
    classification: DataClassification,
    reason_code: str,
) -> RouteDecision:
    return RouteDecision(
        route_decision=RouteType.BRAIN_HANDOFF,
        confidence=0.0,
        risk_level=RiskLevel.HIGH,
        data_classification=classification,
        handoff_reason=reason_code,
        policy_reasons=(reason_code,),
    )


def _classifier_attribute(classifier: object | None, name: str) -> str | None:
    if classifier is None:
        return None
    try:
        profile = classifier.profile
    except Exception:  # noqa: BLE001 - status must not expose adapter failures
        return None
    value = getattr(profile, name, None)
    return str(value) if value is not None else None


def _classifier_evidence(classifier: object | None) -> ClassifierEvidenceStatus | None:
    if classifier is None:
        return None
    try:
        profile = classifier.profile
    except Exception:  # noqa: BLE001 - status must not expose adapter failures
        return None
    return getattr(profile, "evidence_status", None)
