from __future__ import annotations

from threading import BoundedSemaphore, Thread

from totalclaw_cerebellum.domain.models import (
    ExecutionFeedback,
    FalseBlockRecord,
    FeedbackDispatchReceipt,
    ProductDecision,
    RoutingFeedbackRecord,
    SafetyAction,
)
from totalclaw_cerebellum.ports.contracts import RewardFeedbackPort

_FEEDBACK_SLOTS = BoundedSemaphore(8)
_UNKNOWN_DOMAIN = "unknown"


def record_feedback_from_host(
    decision: ProductDecision,
    feedback: ExecutionFeedback,
    feedback_port: RewardFeedbackPort | None,
) -> FeedbackDispatchReceipt:
    """Dispatch sanitized execution feedback to the host-owned learning sink.

    This is intentionally an in-process trusted-host API. It does not store
    records, wait for persistence, retry failures, or accept original text.
    """

    if feedback.request_id != decision.request_id:
        return _rejected("feedback_request_mismatch")

    planned_tools = {reference.tool_id for reference in decision.plan.tools}
    if not set(feedback.called_tools).issubset(planned_tools):
        return _rejected("feedback_tool_not_authorized")

    if (
        feedback.user_confirmed_then_completed
        and decision.safety.action is not SafetyAction.CONFIRM
    ):
        return _rejected("feedback_confirmation_mismatch")

    redacted_text = decision.safety.redacted_text
    if redacted_text is None:
        return _rejected("feedback_safe_text_unavailable")

    try:
        enabled = feedback_port is not None and feedback_port.enabled
    except Exception:  # noqa: BLE001 - optional host sink must never affect decisions
        enabled = False
    if not enabled or feedback_port is None:
        return _rejected("feedback_sink_not_configured")

    routing_record = RoutingFeedbackRecord(
        user_message=redacted_text,
        predicted_domains=decision.plan.domains,
        called_tools=feedback.called_tools,
        reward=1.0 if feedback.task_completed else 0.0,
        task_completed=feedback.task_completed,
    )
    false_block_record = (
        FalseBlockRecord(
            request_id=decision.request_id,
            original_action=SafetyAction.CONFIRM,
            reason_codes=decision.safety.reason_codes,
        )
        if feedback.user_confirmed_then_completed
        else None
    )

    if not _FEEDBACK_SLOTS.acquire(blocking=False):
        return _rejected("feedback_dispatch_saturated")
    try:
        Thread(
            target=_dispatch_and_release,
            args=(feedback_port, decision, feedback, routing_record, false_block_record),
            name="cerebellum-reward-feedback",
            daemon=True,
        ).start()
    except Exception:  # noqa: BLE001 - dispatch failure is deliberately isolated
        _FEEDBACK_SLOTS.release()
        return _rejected("feedback_dispatch_failed")

    return FeedbackDispatchReceipt(
        accepted=True,
        reason_codes=("feedback_dispatched",),
    )


def _dispatch_and_release(
    port: RewardFeedbackPort,
    decision: ProductDecision,
    feedback: ExecutionFeedback,
    routing_record: RoutingFeedbackRecord,
    false_block_record: FalseBlockRecord | None,
) -> None:
    try:
        domain = decision.plan.domains[0] if decision.plan.domains else _UNKNOWN_DOMAIN
        for tool_name in feedback.called_tools:
            try:
                port.record_tool_result(
                    domain,
                    tool_name,
                    feedback.succeeded[tool_name],
                )
            except Exception:  # noqa: BLE001, S110 - no retry by contract
                pass
        try:
            port.record_routing(routing_record)
        except Exception:  # noqa: BLE001, S110 - no retry by contract
            pass
        if false_block_record is not None:
            try:
                port.record_false_block(false_block_record)
            except Exception:  # noqa: BLE001, S110 - no retry by contract
                pass
    finally:
        _FEEDBACK_SLOTS.release()


def _rejected(reason_code: str) -> FeedbackDispatchReceipt:
    return FeedbackDispatchReceipt(accepted=False, reason_codes=(reason_code,))
