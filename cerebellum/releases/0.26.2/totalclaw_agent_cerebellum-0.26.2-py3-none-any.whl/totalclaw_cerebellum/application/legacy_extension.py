"""Compose a 2.0 decision on top of the host's 1.0 pre-router.

The embedding agent already ships a 1.0 cerebellum: a zero-cost heuristic that
narrows the tool catalog per turn and picks a compute budget. This module makes
the 2.0 service an *extension* of that engine rather than a replacement.

Two rules define the boundary:

* **Safety is additive.** The 1.0 engine has no safety channel at all, so any
  non-allow safety action becomes a hard stop the host must honour before it
  reaches its Brain, its memory, or a tool.
* **Planning is narrowing-only.** The tool set handed back is always a subset
  of what the 1.0 engine already kept. When the 2.0 planning channel has no
  usable opinion -- it planned nothing, or it disagrees entirely -- the 1.0
  result passes through untouched. Installing the plugin can therefore never
  widen a host's catalog, and never silently empties it either.
"""

from __future__ import annotations

from totalclaw_cerebellum.domain import (
    CalibratedRoutingOutcome,
    CalibratedSelectionAction,
    CerebellumExtensionResult,
    ExtensionMode,
    LegacyEngineSnapshot,
    ProductDecision,
    SafetyAction,
)


def _plan_tool_ids(decision: ProductDecision) -> tuple[str, ...]:
    seen: dict[str, None] = {}
    for reference in decision.plan.tools:
        seen.setdefault(reference.tool_id, None)
    return tuple(seen)


def compose_extension(
    *,
    cerebellum_version: str,
    decision: ProductDecision,
    legacy: LegacyEngineSnapshot | None = None,
    calibration: CalibratedRoutingOutcome | None = None,
) -> CerebellumExtensionResult:
    """Fold a 2.0 product decision into the host's 1.0 engine result."""

    baseline = tuple(legacy.narrowed_tool_ids) if legacy is not None else ()

    if decision.safety.action is not SafetyAction.ALLOW:
        return CerebellumExtensionResult(
            cerebellum_version=cerebellum_version,
            mode=ExtensionMode.SAFETY_HOLD,
            decision=decision,
            tool_ids=(),
            dropped_tool_ids=baseline,
            calibration=calibration,
            reason_codes=_with_calibration_reasons(
                ("extension_safety_hold", *decision.safety.reason_codes),
                calibration,
            ),
        )

    planned = _plan_tool_ids(decision)

    if legacy is None:
        return CerebellumExtensionResult(
            cerebellum_version=cerebellum_version,
            mode=ExtensionMode.EXTEND,
            decision=decision,
            tool_ids=planned,
            dropped_tool_ids=(),
            calibration=calibration,
            reason_codes=_with_calibration_reasons(
                ("extension_without_legacy_snapshot",),
                calibration,
            ),
        )

    if not planned:
        return _passthrough(
            cerebellum_version,
            decision,
            baseline,
            calibration,
            "extension_plan_empty_passthrough",
        )

    allowed = set(planned)
    kept = tuple(tool_id for tool_id in baseline if tool_id in allowed)
    if not kept:
        return _passthrough(
            cerebellum_version,
            decision,
            baseline,
            calibration,
            "extension_plan_disjoint_passthrough",
        )

    reasons = ["extension_plan_intersected"]
    if calibration is not None and calibration.action is CalibratedSelectionAction.ACCEPT:
        selected = calibration.selected
        if selected is not None and selected.tool_id in kept:
            kept = (selected.tool_id,)
            reasons.append("extension_classifier_narrowed")

    dropped = tuple(tool_id for tool_id in baseline if tool_id not in set(kept))
    return CerebellumExtensionResult(
        cerebellum_version=cerebellum_version,
        mode=ExtensionMode.EXTEND if dropped else ExtensionMode.PASSTHROUGH,
        decision=decision,
        tool_ids=kept,
        dropped_tool_ids=dropped,
        calibration=calibration,
        reason_codes=_with_calibration_reasons(tuple(reasons), calibration),
    )


def _passthrough(
    cerebellum_version: str,
    decision: ProductDecision,
    baseline: tuple[str, ...],
    calibration: CalibratedRoutingOutcome | None,
    reason: str,
) -> CerebellumExtensionResult:
    return CerebellumExtensionResult(
        cerebellum_version=cerebellum_version,
        mode=ExtensionMode.PASSTHROUGH,
        decision=decision,
        tool_ids=baseline,
        dropped_tool_ids=(),
        calibration=calibration,
        reason_codes=_with_calibration_reasons((reason,), calibration),
    )


def _with_calibration_reasons(
    reasons: tuple[str, ...],
    calibration: CalibratedRoutingOutcome | None,
) -> tuple[str, ...]:
    if calibration is None:
        return reasons
    merged = [*reasons, *calibration.reason_codes]
    if calibration.action is CalibratedSelectionAction.ESCALATE:
        merged.append("extension_classifier_escalated")
    seen: dict[str, None] = {}
    for reason in merged:
        seen.setdefault(reason, None)
    return tuple(seen)
