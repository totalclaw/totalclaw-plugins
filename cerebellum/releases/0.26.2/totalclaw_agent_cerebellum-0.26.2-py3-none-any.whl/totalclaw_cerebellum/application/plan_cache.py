from __future__ import annotations

from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass
from time import monotonic

from totalclaw_cerebellum.domain import ToolBudgetPlan, ToolPlanCacheConfig


@dataclass(frozen=True, slots=True)
class ToolPlanCacheKey:
    """Only digests and trusted version identifiers may enter the cache key."""

    redacted_text_sha256: str
    identity_sha256: str
    catalog_version: str
    profile_version: str
    candidate_set_sha256: str
    data_classification: str
    risk_level: str
    is_write_intent: bool


@dataclass(frozen=True, slots=True)
class _CacheEntry:
    expires_at: float
    plan: ToolBudgetPlan


class ToolPlanCache:
    """Per-service bounded TTL cache for tool plans; never stores safety results."""

    def __init__(
        self,
        config: ToolPlanCacheConfig | None = None,
        *,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        self.config = config or ToolPlanCacheConfig()
        self._clock = clock
        self._entries: OrderedDict[ToolPlanCacheKey, _CacheEntry] = OrderedDict()

    def get(self, key: ToolPlanCacheKey) -> ToolBudgetPlan | None:
        if not self.config.enabled:
            return None
        entry = self._entries.get(key)
        if entry is None:
            return None
        if entry.expires_at <= self._clock():
            self._entries.pop(key, None)
            return None
        self._entries.move_to_end(key)
        return entry.plan.model_copy(deep=True)

    def put(self, key: ToolPlanCacheKey, plan: ToolBudgetPlan) -> None:
        if not self.config.enabled:
            return
        self._entries[key] = _CacheEntry(
            expires_at=self._clock() + self.config.ttl_seconds,
            plan=plan.model_copy(deep=True),
        )
        self._entries.move_to_end(key)
        while len(self._entries) > self.config.max_entries:
            self._entries.popitem(last=False)

    @property
    def size(self) -> int:
        return len(self._entries)
