"""Emit the distribution entries for the agent plugin package.

Two hosts install the same ``plugin/`` directory from a remote repository and
each verifies it differently:

* The agent's plugin hub reads a ``registry.json`` entry carrying ``path`` plus
  a per-file sha256 list, and rejects the install when the downloaded file set
  is not byte-for-byte what the entry declared.
* The enterprise app's package hub reads a ``catalog.json`` item carrying
  ``path`` plus a flat relative-path list.

Both are generated here from the files actually on disk, so a digest can never
go stale in the repository. This module writes nothing to the network and
publishes nothing; it prints JSON for a release pipeline to place.

This is the *plugin marketplace* channel. The runtime wheel ships through a
separate repository and a separate generator (:mod:`runtime_release`); the two
are independent and neither replaces the other.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from totalclaw_cerebellum import __version__

PLUGIN_NAME = "totalclaw-cerebellum"
PLUGIN_CATEGORY = "routing"
PLUGIN_DISPLAY_NAME = "智脑 2.0 前置路由"
PLUGIN_DESCRIPTION = "扩展 agent 内置小脑 1.0：新增安全预检通道，并在其工具收窄结果上继续收紧。"
_SKIP_DIRECTORIES = frozenset({"__pycache__", ".git"})
_KEY_PATTERN = re.compile(r"^(?P<key>[a-z_]+):\s*(?P<value>\S.*?)\s*$")


class PluginPackagingError(RuntimeError):
    """The plugin directory is missing, malformed, or has drifted from the package."""


def _manifest_scalars(plugin_dir: Path) -> dict[str, str]:
    """Read the flat top-level scalars of ``plugin.yaml`` without a YAML parser."""

    path = plugin_dir / "plugin.yaml"
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise PluginPackagingError(f"cannot read {path}") from exc
    scalars: dict[str, str] = {}
    for line in lines:
        if line.startswith((" ", "\t", "#")) or not line.strip():
            continue
        match = _KEY_PATTERN.match(line)
        if match:
            scalars.setdefault(match.group("key"), match.group("value"))
    return scalars


def plugin_files(plugin_dir: Path) -> tuple[Path, ...]:
    files = [
        path
        for path in sorted(plugin_dir.rglob("*"))
        if path.is_file() and not _SKIP_DIRECTORIES.intersection(path.relative_to(plugin_dir).parts)
    ]
    if not files:
        raise PluginPackagingError(f"no plugin files under {plugin_dir}")
    return tuple(files)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(256 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_plugin_index(plugin_dir: str | Path) -> dict[str, object]:
    """Return the registry entry and catalog item for ``plugin_dir``."""

    root = Path(plugin_dir).expanduser().resolve()
    if not root.is_dir():
        raise PluginPackagingError(f"{root} is not a directory")

    scalars = _manifest_scalars(root)
    name = scalars.get("name", "")
    version = scalars.get("version", "")
    if name != PLUGIN_NAME:
        raise PluginPackagingError(f"plugin.yaml name must be {PLUGIN_NAME!r}, got {name!r}")
    if version != __version__:
        raise PluginPackagingError(
            f"plugin.yaml version {version!r} does not match package version {__version__!r}"
        )

    files = plugin_files(root)
    relative = [file.relative_to(root).as_posix() for file in files]
    repository_path = f"{PLUGIN_CATEGORY}/{PLUGIN_NAME}"

    return {
        "registry_entry": {
            "id": f"totalclaw-plugins/{repository_path}",
            "name": PLUGIN_NAME,
            "version": version,
            "description": PLUGIN_DESCRIPTION,
            "path": repository_path,
            "verified": False,
            "files": [
                {"path": name, "sha256": _sha256(file)}
                for name, file in zip(relative, files, strict=True)
            ],
        },
        "catalog_item": {
            "id": PLUGIN_NAME,
            "name": PLUGIN_DISPLAY_NAME,
            "description": PLUGIN_DESCRIPTION,
            "category": PLUGIN_CATEGORY,
            "version": version,
            "path": repository_path,
            "size": sum(file.stat().st_size for file in files),
            "files": relative,
        },
    }


def run_cli(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="cerebellum-build-plugin-index",
        description="Print the plugin hub registry entry and package hub catalog item.",
    )
    parser.add_argument("plugin_dir", help="path to the plugin/ directory")
    arguments = parser.parse_args(argv)
    try:
        index = build_plugin_index(arguments.plugin_dir)
    except PluginPackagingError as exc:
        parser.exit(status=2, message=f"{exc}\n")
    print(json.dumps(index, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover - module CLI
    raise SystemExit(run_cli())
