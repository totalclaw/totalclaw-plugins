from __future__ import annotations

import asyncio
import re
from collections.abc import Mapping, Sequence
from typing import Any

from totalclaw_cerebellum.domain import (
    CerebellumRequest,
    DataClassification,
    RedactionAction,
    RedactionResult,
    RequestContext,
    ToolExecutionRequest,
    VaultArgumentBinding,
    VaultBindingCheck,
)
from totalclaw_cerebellum.ports import RedactorPort, VaultReferencePort

MAX_VAULT_REFERENCES = 16
_VAULT_SCHEME_RE = re.compile(r"vault://", re.IGNORECASE | re.ASCII)
_VAULT_REFERENCE_RE = re.compile(
    r"vault://[A-Za-z0-9][A-Za-z0-9._~:@%/+\-]{0,479}(?![A-Za-z0-9._~:@%/+\-])"
)
_FORBIDDEN_REFERENCE_SUFFIX = frozenset("?#&=\\")


class VaultReferenceSyntaxError(ValueError):
    """Internal fixed-shape parse failure; never include the source text."""


class NullVaultReference:
    """Default P9 adapter: no Vault reference is trusted."""

    @property
    def configured(self) -> bool:
        return False

    async def validate(
        self,
        reference: str,
        context: RequestContext,
        session_id: str,
        binding: VaultArgumentBinding | None = None,
    ) -> bool:
        del reference, context, session_id, binding
        return False


class ConservativeVaultRedactor:
    """Validate pre-registered opaque references before the normal DLP boundary.

    This adapter never stores, resolves, or returns a secret. A reference is useful
    only when a trusted host port confirms its identity/session binding and TTL.
    """

    def __init__(
        self,
        redactor: RedactorPort,
        vault_reference: VaultReferencePort,
        *,
        timeout_seconds: float = 1.0,
    ) -> None:
        if timeout_seconds <= 0:
            raise ValueError("Vault reference timeout must be positive")
        self._redactor = redactor
        self._vault_reference = vault_reference
        self._timeout_seconds = timeout_seconds

    async def redact(
        self,
        request: CerebellumRequest,
        context: RequestContext,
    ) -> RedactionResult:
        try:
            references = extract_vault_references(request.text)
        except VaultReferenceSyntaxError:
            return _blocked("vault_reference_malformed")
        if not references:
            return await self._redactor.redact(request, context)
        if request.session_id is None or not request.session_id.strip():
            return _blocked("vault_reference_session_required")
        if not context.identity.authenticated:
            return _blocked("vault_reference_identity_required")
        try:
            configured = self._vault_reference.configured
        except Exception:  # noqa: BLE001 - adapter details must not escape
            return _blocked("vault_reference_validator_unavailable")
        if not configured:
            return _blocked("vault_reference_validator_not_configured")

        async def validate(reference: str) -> bool:
            return await asyncio.wait_for(
                self._vault_reference.validate(
                    reference,
                    context,
                    request.session_id or "",
                    None,
                ),
                timeout=self._timeout_seconds,
            )

        try:
            results = await asyncio.gather(*(validate(item) for item in references))
        except TimeoutError:
            return _blocked("vault_reference_validation_timeout")
        except Exception:  # noqa: BLE001 - adapter details must not escape
            return _blocked("vault_reference_validator_unavailable")
        if any(result is not True for result in results):
            return _blocked("vault_reference_invalid")

        result = await self._redactor.redact(request, context)
        if result.policy_action is RedactionAction.BLOCK:
            return result
        return result.model_copy(
            update={
                "entity_count": result.entity_count + len(references),
                "reason_codes": result.reason_codes
                + ("vault_reference_validated",),
            }
        )


def extract_vault_references(text: str) -> tuple[str, ...]:
    """Return strict opaque references without interpreting their host-owned format."""

    starts = [match.start() for match in _VAULT_SCHEME_RE.finditer(text)]
    if not starts:
        return ()
    if len(starts) > MAX_VAULT_REFERENCES:
        raise VaultReferenceSyntaxError("too_many_vault_references")

    references: list[str] = []
    for start in starts:
        match = _VAULT_REFERENCE_RE.match(text, start)
        if match is None:
            raise VaultReferenceSyntaxError("invalid_vault_reference")
        reference = match.group(0)
        if match.end() < len(text) and text[match.end()] in _FORBIDDEN_REFERENCE_SUFFIX:
            raise VaultReferenceSyntaxError("invalid_vault_reference_suffix")
        if any(ord(character) < 0x20 or ord(character) == 0x7F for character in reference):
            raise VaultReferenceSyntaxError("invalid_vault_reference_control")
        if reference not in references:
            references.append(reference)
    return tuple(references)


async def check_vault_bindings(
    request: ToolExecutionRequest,
    *,
    action_id: str,
    session_id: str | None,
    context: RequestContext,
    vault_reference: VaultReferencePort,
    timeout_seconds: float = 1.0,
) -> VaultBindingCheck:
    """Check Vault argument bindings without resolving values or authorizing execution."""

    try:
        found = _top_level_vault_arguments(request.arguments)
    except VaultReferenceSyntaxError:
        return _denied("vault_reference_argument_shape_invalid")
    if not found:
        return VaultBindingCheck(
            allowed=True,
            reference_count=0,
            reason_codes=("vault_reference_absent",),
        )
    if session_id is None or not session_id.strip():
        return _denied("vault_reference_session_required", len(found))
    if not context.identity.authenticated:
        return _denied("vault_reference_identity_required", len(found))
    try:
        configured = vault_reference.configured
    except Exception:  # noqa: BLE001 - adapter details must not escape
        return _denied("vault_reference_validator_unavailable", len(found))
    if not configured:
        return _denied("vault_reference_validator_not_configured", len(found))

    async def validate(argument_name: str, reference: str) -> bool:
        binding = VaultArgumentBinding(
            tool_id=request.tool_id,
            action_id=action_id,
            argument_name=argument_name,
        )
        return await asyncio.wait_for(
            vault_reference.validate(
                reference,
                context,
                session_id,
                binding,
            ),
            timeout=timeout_seconds,
        )

    try:
        results = await asyncio.gather(
            *(validate(argument, reference) for argument, reference in found)
        )
    except TimeoutError:
        return _denied("vault_reference_validation_timeout", len(found))
    except Exception:  # noqa: BLE001 - adapter details must not escape
        return _denied("vault_reference_validator_unavailable", len(found))
    if any(result is not True for result in results):
        return _denied("vault_reference_binding_denied", len(found))
    return VaultBindingCheck(
        allowed=True,
        reference_count=len(found),
        reason_codes=("vault_reference_binding_validated",),
    )


def _top_level_vault_arguments(
    arguments: Mapping[str, Any],
) -> tuple[tuple[str, str], ...]:
    found: list[tuple[str, str]] = []
    for argument_name, value in arguments.items():
        if _contains_vault_scheme(argument_name):
            raise VaultReferenceSyntaxError("vault_reference_in_argument_name")
        if isinstance(value, str):
            references = extract_vault_references(value)
            if not references:
                continue
            if len(references) != 1 or value != references[0]:
                raise VaultReferenceSyntaxError("embedded_vault_reference")
            found.append((argument_name, references[0]))
        elif _nested_contains_vault_reference(value):
            raise VaultReferenceSyntaxError("nested_vault_reference")
    if len(found) > MAX_VAULT_REFERENCES:
        raise VaultReferenceSyntaxError("too_many_vault_references")
    return tuple(found)


def _nested_contains_vault_reference(value: Any) -> bool:
    if isinstance(value, str):
        return _contains_vault_scheme(value)
    if isinstance(value, Mapping):
        return any(
            _contains_vault_scheme(str(key)) or _nested_contains_vault_reference(item)
            for key, item in value.items()
        )
    if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
        return any(_nested_contains_vault_reference(item) for item in value)
    return False


def _contains_vault_scheme(value: str) -> bool:
        return _VAULT_SCHEME_RE.search(value) is not None


def _blocked(reason_code: str) -> RedactionResult:
    return RedactionResult(
        redacted_text="",
        data_classification=DataClassification.L4,
        policy_action=RedactionAction.BLOCK,
        reason_codes=(reason_code,),
    )


def _denied(reason_code: str, reference_count: int = 0) -> VaultBindingCheck:
    return VaultBindingCheck(
        allowed=False,
        reference_count=reference_count,
        reason_codes=(reason_code,),
    )
