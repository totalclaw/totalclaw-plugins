from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from totalclaw_cerebellum.adapters.file_cache import (
    BoundedValidationCache,
    FileVersion,
    file_version,
)
from totalclaw_cerebellum.domain import (
    CatalogEvidenceStatus,
    ToolPlanningProfile,
)

MAX_TOOL_PLANNING_PROFILE_BYTES = 262_144


class ToolPlanningProfileIntegrityError(ValueError):
    """Sanitized startup failure for an invalid F4 planning profile."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


_TOOL_PLANNING_PROFILE_CACHE = BoundedValidationCache[ToolPlanningProfile]()
_TOOL_PLANNING_BINDING_CACHE = BoundedValidationCache[bool](max_entries=64)


def load_tool_planning_profile(
    path: str | Path,
    *,
    environment: str = "development",
) -> ToolPlanningProfile:
    try:
        version = file_version(path)
    except OSError:
        raise ToolPlanningProfileIntegrityError(
            "tool_planning_profile_document_unreadable"
        ) from None
    normalized_environment = environment.casefold()
    profile = _TOOL_PLANNING_PROFILE_CACHE.get_or_load(
        (version, normalized_environment),
        lambda: _load_tool_planning_profile_uncached(
            version,
            normalized_environment,
        ),
    )
    return profile.model_copy(deep=True)


def _load_tool_planning_profile_uncached(
    version: FileVersion,
    environment: str,
) -> ToolPlanningProfile:
    try:
        document = Path(version.path).read_bytes()
        if len(document) > MAX_TOOL_PLANNING_PROFILE_BYTES:
            raise ToolPlanningProfileIntegrityError(
                "tool_planning_profile_document_too_large"
            )
        payload = json.loads(
            document.decode("utf-8"),
            object_pairs_hook=_unique_object,
        )
        profile = ToolPlanningProfile.model_validate(payload)
    except ToolPlanningProfileIntegrityError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise ToolPlanningProfileIntegrityError(
            "tool_planning_profile_document_unreadable"
        ) from None
    except ValidationError:
        raise ToolPlanningProfileIntegrityError(
            "tool_planning_profile_schema_invalid"
        ) from None

    if (
        environment.casefold() == "production"
        and profile.evidence_status is CatalogEvidenceStatus.FIXTURE
    ):
        raise ToolPlanningProfileIntegrityError(
            "fixture_tool_planning_profile_forbidden_in_production"
        )
    return profile


def validate_tool_planning_profile_binding(
    profile: ToolPlanningProfile,
    *,
    catalog_id: str | None,
    available_tool_ids: frozenset[str] | None = None,
    known_tool_ids: frozenset[str] | None = None,
) -> None:
    _TOOL_PLANNING_BINDING_CACHE.get_or_load(
        (
            profile.model_dump_json(),
            catalog_id,
            available_tool_ids,
            known_tool_ids,
        ),
        lambda: _validate_tool_planning_profile_binding_uncached(
            profile,
            catalog_id=catalog_id,
            available_tool_ids=available_tool_ids,
            known_tool_ids=known_tool_ids,
        ),
    )


def _validate_tool_planning_profile_binding_uncached(
    profile: ToolPlanningProfile,
    *,
    catalog_id: str | None,
    available_tool_ids: frozenset[str] | None,
    known_tool_ids: frozenset[str] | None,
) -> bool:
    if catalog_id != profile.catalog_id:
        raise ToolPlanningProfileIntegrityError(
            "tool_planning_profile_catalog_mismatch"
        )
    if available_tool_ids is None:
        return True
    approved_required_tool_ids = frozenset(
        (
            *profile.config.always_include_tool_ids,
            *profile.config.discovery_tool_ids,
            *profile.config.fallback_core_tool_ids,
            *profile.config.fallback_ranked_tool_ids,
            *profile.config.wechat_required_tool_ids,
        )
    )
    if not approved_required_tool_ids.issubset(available_tool_ids):
        raise ToolPlanningProfileIntegrityError(
            "tool_planning_profile_unknown_tool_id"
        )
    if profile.evidence_status is CatalogEvidenceStatus.VALIDATED:
        normalized_tool_ids = tuple(tool_id.casefold() for tool_id in available_tool_ids)
        for rule in profile.config.domain_rules:
            normalized_prefixes = tuple(
                prefix.casefold() for prefix in rule.tool_prefixes
            )
            if not any(
                tool_id.startswith(normalized_prefixes)
                for tool_id in normalized_tool_ids
            ):
                raise ToolPlanningProfileIntegrityError(
                    "tool_planning_profile_unbound_domain"
                )
    if (
        known_tool_ids is not None
        and not set(profile.config.wechat_gui_blocked_tool_ids).issubset(
            known_tool_ids
        )
    ):
        raise ToolPlanningProfileIntegrityError(
            "tool_planning_profile_unknown_tool_id"
        )
    return True


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ToolPlanningProfileIntegrityError(
                "tool_planning_profile_duplicate_json_key"
            )
        result[key] = value
    return result
