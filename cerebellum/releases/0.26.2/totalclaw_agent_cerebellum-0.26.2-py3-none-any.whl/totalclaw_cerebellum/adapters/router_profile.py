from __future__ import annotations

import hashlib
import hmac
import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from totalclaw_cerebellum.adapters.file_cache import (
    BoundedValidationCache,
    FileVersion,
    file_version,
)
from totalclaw_cerebellum.domain import (
    RegistryEvalStatus,
    RouterEvaluationReport,
    RouterProfile,
    RouterProfileEvidenceStatus,
)


class RouterProfileIntegrityError(ValueError):
    """Sanitized startup error for an invalid Router-1 profile."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


_ROUTER_PROFILE_CACHE = BoundedValidationCache[RouterProfile]()
_ROUTER_REPORT_CACHE = BoundedValidationCache[RouterEvaluationReport]()


def load_router_profile(
    path: str | Path,
    *,
    environment: str = "development",
) -> RouterProfile:
    try:
        version = file_version(path)
    except OSError:
        raise RouterProfileIntegrityError(
            "router_profile_document_unreadable"
        ) from None
    normalized_environment = environment.casefold()
    profile = _ROUTER_PROFILE_CACHE.get_or_load(
        (version, normalized_environment),
        lambda: _load_router_profile_uncached(
            version,
            normalized_environment,
        ),
    )
    return profile.model_copy(deep=True)


def _load_router_profile_uncached(
    version: FileVersion,
    environment: str,
) -> RouterProfile:
    try:
        payload = json.loads(
            Path(version.path).read_text(encoding="utf-8"),
            object_pairs_hook=_unique_object,
        )
        profile = RouterProfile.model_validate(payload)
    except RouterProfileIntegrityError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise RouterProfileIntegrityError("router_profile_document_unreadable") from None
    except ValidationError:
        raise RouterProfileIntegrityError("router_profile_schema_invalid") from None

    if (
        environment.casefold() == "production"
        and profile.evidence_status is RouterProfileEvidenceStatus.FIXTURE
    ):
        raise RouterProfileIntegrityError(
            "fixture_router_profile_forbidden_in_production"
        )
    return profile


def verify_router_evaluation_report(
    profile: RouterProfile,
    path: str | Path,
    *,
    max_bytes: int = 10_485_760,
) -> RouterEvaluationReport:
    if max_bytes <= 0:
        raise ValueError("router profile report limit must be positive")
    if (
        profile.evidence_status is not RouterProfileEvidenceStatus.VALIDATED
        or profile.evaluation_report_sha256 is None
    ):
        raise RouterProfileIntegrityError(
            "router_profile_report_requires_validated_profile"
        )
    try:
        version = file_version(path)
    except OSError:
        raise RouterProfileIntegrityError("router_profile_report_unreadable") from None
    report = _ROUTER_REPORT_CACHE.get_or_load(
        (profile.model_dump_json(), version, max_bytes),
        lambda: _verify_router_evaluation_report_uncached(
            profile,
            version,
            max_bytes,
        ),
    )
    return report.model_copy(deep=True)


def _verify_router_evaluation_report_uncached(
    profile: RouterProfile,
    version: FileVersion,
    max_bytes: int,
) -> RouterEvaluationReport:
    if version.size > max_bytes:
        raise RouterProfileIntegrityError("router_profile_report_too_large")
    try:
        digest = hashlib.sha256()
        total_bytes = 0
        chunks: list[bytes] = []
        with Path(version.path).open("rb") as report:
            while chunk := report.read(65_536):
                total_bytes += len(chunk)
                if total_bytes > max_bytes:
                    raise RouterProfileIntegrityError(
                        "router_profile_report_too_large"
                    )
                digest.update(chunk)
                chunks.append(chunk)
    except RouterProfileIntegrityError:
        raise
    except OSError:
        raise RouterProfileIntegrityError("router_profile_report_unreadable") from None

    if not hmac.compare_digest(digest.hexdigest(), profile.evaluation_report_sha256):
        raise RouterProfileIntegrityError("router_profile_report_hash_mismatch")

    try:
        payload = json.loads(
            b"".join(chunks),
            object_pairs_hook=_unique_object,
        )
        evaluation_report = RouterEvaluationReport.model_validate(payload)
    except RouterProfileIntegrityError:
        raise
    except (UnicodeError, json.JSONDecodeError, ValidationError):
        raise RouterProfileIntegrityError("router_profile_report_schema_invalid") from None

    if (
        evaluation_report.model_id != profile.model_id
        or evaluation_report.prompt_version != profile.prompt_version
        or evaluation_report.dataset_version != profile.dataset_version
        or evaluation_report.catalog_id != profile.catalog_id
    ):
        raise RouterProfileIntegrityError("router_profile_report_binding_mismatch")

    metrics = evaluation_report.metrics
    acceptance_failed = (
        evaluation_report.evidence_status is not RouterProfileEvidenceStatus.VALIDATED
        or evaluation_report.status is not RegistryEvalStatus.PASS
        or evaluation_report.action_count < 10
        or evaluation_report.sample_count < 100
        or not evaluation_report.error_review_completed
        or metrics.registry_top5_recall < 0.98
        or metrics.router_top1_tool_accuracy < 0.95
        or metrics.json_schema_valid_rate < 0.995
        or metrics.required_slots_complete_rate < 0.995
        or metrics.tool_hallucination_rate >= 0.005
        or metrics.write_operation_direct_count != 0
        or metrics.unauthorized_candidate_exposure_count != 0
        or metrics.l4_raw_leak_count != 0
        or metrics.redaction_quality_drop_pp > 2.0
    )
    if acceptance_failed:
        raise RouterProfileIntegrityError("router_profile_report_acceptance_failed")

    return evaluation_report


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise RouterProfileIntegrityError("router_profile_duplicate_json_key")
        result[key] = value
    return result
