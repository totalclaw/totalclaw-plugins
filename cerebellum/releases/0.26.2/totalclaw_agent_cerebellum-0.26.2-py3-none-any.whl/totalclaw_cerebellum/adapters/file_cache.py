from __future__ import annotations

from collections.abc import Callable, Hashable
from dataclasses import dataclass
from pathlib import Path
from typing import Generic, TypeVar

T = TypeVar("T")
_MISSING = object()


@dataclass(frozen=True, slots=True)
class FileVersion:
    """A bounded-cache key that changes when the configured file changes."""

    path: str
    modified_ns: int
    size: int


def file_version(path: str | Path) -> FileVersion:
    resolved = Path(path).resolve(strict=True)
    metadata = resolved.stat()
    return FileVersion(
        path=str(resolved),
        modified_ns=metadata.st_mtime_ns,
        size=metadata.st_size,
    )


class BoundedValidationCache(Generic[T]):
    """Small lock-free cache; concurrent misses may safely validate twice."""

    def __init__(self, max_entries: int = 32) -> None:
        if max_entries <= 0:
            raise ValueError("file cache size must be positive")
        self._max_entries = max_entries
        self._values: dict[Hashable, T] = {}

    def get_or_load(
        self,
        key: Hashable,
        loader: Callable[[], T],
    ) -> T:
        cached = self._values.get(key, _MISSING)
        if cached is not _MISSING:
            return cached

        value = loader()
        self._values[key] = value
        while len(self._values) > self._max_entries:
            try:
                oldest = next(iter(self._values))
            except (RuntimeError, StopIteration):
                break
            self._values.pop(oldest, None)
        return value
