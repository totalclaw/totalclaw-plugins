from __future__ import annotations

import asyncio
from collections import OrderedDict
from collections.abc import Callable
from contextvars import ContextVar
from threading import BoundedSemaphore, Event, Lock, Thread

from pydantic import model_validator

from totalclaw_cerebellum.adapters.common import (
    RouteTransportRequest,
    product_failure_decision,
    resolve_transport_identity,
    route_from_transport,
)
from totalclaw_cerebellum.adapters.defaults import (
    NullRewardFeedback,
    UntrustedIdentityResolver,
)
from totalclaw_cerebellum.application import (
    CerebellumService,
    record_feedback_from_host,
)
from totalclaw_cerebellum.application.product_decision import dispatch_ltm_log
from totalclaw_cerebellum.bootstrap import build_service
from totalclaw_cerebellum.domain.models import (
    CapabilityCandidate,
    CerebellumResponse,
    DataClassification,
    ExecutionFeedback,
    FeedbackDispatchReceipt,
    HandoffEnvelope,
    HandoffReceipt,
    IntentType,
    ProductDecision,
    RiskLevel,
    RouteDecision,
    RouteType,
    StrictModel,
    UserTurnHistory,
)
from totalclaw_cerebellum.ports.contracts import (
    BrainPort,
    IdentityResolverPort,
    RewardFeedbackPort,
)


class HostRouteResult(StrictModel):
    """Decision plus the redaction-boundary envelope for the host Brain."""

    response: CerebellumResponse
    brain_handoff: HandoffEnvelope | None = None

    @model_validator(mode="after")
    def require_matching_handoff(self) -> HostRouteResult:
        is_handoff = self.response.decision.route_decision is RouteType.BRAIN_HANDOFF
        if is_handoff and self.brain_handoff is None:
            raise ValueError("brain_handoff requires a host handoff envelope")
        if not is_handoff and self.brain_handoff is not None:
            raise ValueError("only brain_handoff may carry a host handoff envelope")
        return self


class _HostBrainCapture:
    """Per-request BrainPort that hands control back to the embedding host."""

    def __init__(self) -> None:
        self.envelope: HandoffEnvelope | None = None

    @property
    def configured(self) -> bool:
        return True

    async def handoff(self, envelope: HandoffEnvelope) -> HandoffReceipt:
        self.envelope = envelope
        return HandoffReceipt(accepted=True, reason="host_brain_handoff")


_ACTIVE_CAPTURE: ContextVar[_HostBrainCapture | None] = ContextVar(
    "cerebellum_host_brain_capture",
    default=None,
)


class _HostBrainBridge:
    """Reusable BrainPort that dispatches to the current async request context."""

    @property
    def configured(self) -> bool:
        return True

    async def handoff(self, envelope: HandoffEnvelope) -> HandoffReceipt:
        capture = _ACTIVE_CAPTURE.get()
        if capture is None:
            return HandoffReceipt(accepted=False, reason="host_brain_context_missing")
        return await capture.handoff(envelope)


HostServiceFactory = Callable[[BrainPort], CerebellumService]
_HOST_BRAIN_BRIDGE = _HostBrainBridge()
_DEFAULT_HOST_SERVICE: CerebellumService | None = None
_HOST_SYNC_BRIDGE_TIMEOUT_SECONDS = 15.0
_HOST_SYNC_BRIDGE_SLOTS = BoundedSemaphore(32)
_HOST_FACTORY_SERVICES: OrderedDict[
    int,
    tuple[HostServiceFactory, CerebellumService],
] = OrderedDict()


def _default_host_service() -> CerebellumService:
    global _DEFAULT_HOST_SERVICE
    if _DEFAULT_HOST_SERVICE is None:
        _DEFAULT_HOST_SERVICE = build_service(brain=_HOST_BRAIN_BRIDGE)
    return _DEFAULT_HOST_SERVICE


def _host_service_from_factory(
    service_factory: HostServiceFactory,
) -> CerebellumService:
    cache_key = id(service_factory)
    cached = _HOST_FACTORY_SERVICES.get(cache_key)
    if cached is None or cached[0] is not service_factory:
        service = service_factory(_HOST_BRAIN_BRIDGE)
        if len(_HOST_FACTORY_SERVICES) >= 32:
            _HOST_FACTORY_SERVICES.popitem(last=False)
        _HOST_FACTORY_SERVICES[cache_key] = (service_factory, service)
    else:
        service = cached[1]
        _HOST_FACTORY_SERVICES.move_to_end(cache_key)
    return service


async def route_from_host(
    payload: RouteTransportRequest,
    *,
    channel: str,
    identity_resolver: IdentityResolverPort | None = None,
    service_factory: HostServiceFactory | None = None,
) -> HostRouteResult:
    """Run the cerebellum before a host persists input or invokes its Brain.

    The host must short-circuit on every decision except ``brain_handoff``.
    For a handoff it must use ``brain_handoff.redacted_text`` rather than the
    original user text.
    """

    capture = _HostBrainCapture()
    capture_token = _ACTIVE_CAPTURE.set(capture)
    try:
        service = (
            _host_service_from_factory(service_factory)
            if service_factory is not None
            else _default_host_service()
        )
        response = await route_from_transport(
            payload,
            channel=channel,
            service=service,
            identity_resolver=(
                identity_resolver
                if identity_resolver is not None
                else UntrustedIdentityResolver()
            ),
        )
    except Exception:  # noqa: BLE001 - host integration failures must not escape
        capture.envelope = None
        response = _host_failure_response("host_service_unavailable")
    finally:
        _ACTIVE_CAPTURE.reset(capture_token)
    return HostRouteResult(response=response, brain_handoff=capture.envelope)


async def decide_from_host(
    payload: RouteTransportRequest,
    available_candidates: tuple[CapabilityCandidate, ...],
    *,
    channel: str,
    identity_resolver: IdentityResolverPort | None = None,
    service_factory: HostServiceFactory | None = None,
    ltm_context: list[dict[str, object]] | None = None,
    ltm_log_fn: Callable[[dict[str, object]], None] | None = None,
    user_turn_history: UserTurnHistory | None = None,
) -> ProductDecision:
    """Return the Taotu 2.0 safety and planning channels to a trusted host.

    The embedding host owns runtime capability assembly. The service still
    rechecks tenant, role, and scope before any candidate can enter the plan.
    """

    request = payload.to_domain_request()
    try:
        service = (
            _host_service_from_factory(service_factory)
            if service_factory is not None
            else _default_host_service()
        )
        context, failure = await resolve_transport_identity(
            payload,
            channel=channel,
            service=service,
            identity_resolver=(
                identity_resolver
                if identity_resolver is not None
                else UntrustedIdentityResolver()
            ),
        )
        if context is None:
            return product_failure_decision(
                request.request_id,
                failure or "identity_resolution_failed",
                is_write_intent=request.is_write_intent,
            )
        return await service.decide_v2(
            request,
            context,
            available_candidates,
            ltm_context=ltm_context,
            ltm_log_fn=ltm_log_fn,
            user_turn_history=user_turn_history,
        )
    except Exception:  # noqa: BLE001 - host integration details must remain internal
        return product_failure_decision(
            request.request_id,
            "host_decision_service_unavailable",
            is_write_intent=request.is_write_intent,
        )


def decide_from_host_sync(
    payload: RouteTransportRequest,
    available_candidates: tuple[CapabilityCandidate, ...],
    *,
    channel: str,
    identity_resolver: IdentityResolverPort | None = None,
    service_factory: HostServiceFactory | None = None,
    ltm_context: list[dict[str, object]] | None = None,
    ltm_log_fn: Callable[[dict[str, object]], None] | None = None,
    user_turn_history: UserTurnHistory | None = None,
) -> ProductDecision:
    """Bridge a synchronous host to the same fail-closed async decision core."""

    cancelled = Event()
    state_lock = Lock()
    running: list[tuple[asyncio.AbstractEventLoop, asyncio.Task]] = []

    def cancel() -> None:
        with state_lock:
            cancelled.set()
            for loop, task in running:
                loop.call_soon_threadsafe(task.cancel)

    async def invoke() -> ProductDecision:
        with state_lock:
            if cancelled.is_set():
                raise asyncio.CancelledError
            running.append((asyncio.get_running_loop(), asyncio.current_task()))
        try:
            return await invoke_core()
        finally:
            with state_lock:
                running.clear()

    async def invoke_core() -> ProductDecision:
        return await decide_from_host(
            payload,
            available_candidates,
            channel=channel,
            identity_resolver=identity_resolver,
            service_factory=service_factory,
            ltm_context=ltm_context,
            ltm_log_fn=None,  # Only the synchronous caller may accept and log the result.
            user_turn_history=user_turn_history,
        )

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        try:
            decision = asyncio.run(invoke())
            dispatch_ltm_log(decision, ltm_log_fn)
            return decision
        except Exception:  # noqa: BLE001 - sync host details must remain internal
            return _sync_product_failure(payload)

    if not _HOST_SYNC_BRIDGE_SLOTS.acquire(blocking=False):
        return _sync_product_failure(
            payload,
            "host_sync_bridge_capacity_exhausted",
        )

    results: list[ProductDecision] = []

    def run_in_thread() -> None:
        try:
            results.append(asyncio.run(invoke()))
        except (Exception, asyncio.CancelledError):  # noqa: BLE001 - cancellation is terminal
            return
        finally:
            _HOST_SYNC_BRIDGE_SLOTS.release()

    worker = Thread(
        target=run_in_thread,
        name="cerebellum-host-async-bridge",
        daemon=True,
    )
    try:
        worker.start()
    except Exception:  # noqa: BLE001 - thread start failures must fail closed
        _HOST_SYNC_BRIDGE_SLOTS.release()
        return _sync_product_failure(payload)
    try:
        worker.join(timeout=_HOST_SYNC_BRIDGE_TIMEOUT_SECONDS)
    except Exception:  # noqa: BLE001 - thread wait failures must fail closed
        cancel()
        return _sync_product_failure(payload)
    if worker.is_alive():
        cancel()
        return _sync_product_failure(payload, "host_sync_bridge_timeout")
    decision = results[0] if results else _sync_product_failure(payload)
    dispatch_ltm_log(decision, ltm_log_fn)
    return decision


def submit_feedback_from_host(
    decision: ProductDecision,
    feedback: ExecutionFeedback,
    *,
    feedback_port: RewardFeedbackPort | None = None,
) -> FeedbackDispatchReceipt:
    """Queue sanitized feedback for a trusted host-owned learning sink."""

    return record_feedback_from_host(
        decision,
        feedback,
        feedback_port if feedback_port is not None else NullRewardFeedback(),
    )


def _sync_product_failure(
    payload: RouteTransportRequest,
    reason_code: str = "host_sync_bridge_unavailable",
) -> ProductDecision:
    request = payload.to_domain_request()
    return product_failure_decision(
        request.request_id,
        reason_code,
        is_write_intent=request.is_write_intent,
    )


def _host_failure_response(reason_code: str) -> CerebellumResponse:
    return CerebellumResponse(
        decision=RouteDecision(
            intent_type=IntentType.SENSITIVE,
            route_decision=RouteType.BLOCK,
            confidence=1.0,
            risk_level=RiskLevel.CRITICAL,
            data_classification=DataClassification.L4,
            handoff_reason=reason_code,
            policy_reasons=(reason_code,),
        ),
    )
