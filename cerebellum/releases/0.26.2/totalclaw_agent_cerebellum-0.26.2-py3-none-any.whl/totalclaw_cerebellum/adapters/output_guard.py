from __future__ import annotations

import re

from totalclaw_cerebellum.domain import (
    CerebellumRequest,
    DataClassification,
    RedactionAction,
    RedactionResult,
    RequestContext,
)
from totalclaw_cerebellum.ports import RedactorPort

from .vault_references import VaultReferenceSyntaxError, extract_vault_references

_PLACEHOLDER_RE = re.compile(r"\[(?:PHONE|EMAIL|CN_ID|BANK_CARD)_\d+\]")


class RedactorOutputGuard:
    """Apply the configured Redactor to generated text as newly observed L0 data."""

    def __init__(self, redactor: RedactorPort) -> None:
        self._redactor = redactor

    async def inspect(
        self,
        text: str,
        context: RequestContext,
        *,
        source_redacted_text: str,
    ) -> RedactionResult:
        allowed_placeholders = frozenset(_PLACEHOLDER_RE.findall(source_redacted_text))
        output_placeholders = frozenset(_PLACEHOLDER_RE.findall(text))
        if not output_placeholders.issubset(allowed_placeholders):
            return RedactionResult(
                redacted_text="",
                data_classification=DataClassification.L4,
                policy_action=RedactionAction.BLOCK,
                reason_codes=("output_placeholder_not_authorized",),
            )

        try:
            allowed_vault_references = frozenset(
                extract_vault_references(source_redacted_text)
            )
            output_vault_references = frozenset(extract_vault_references(text))
        except VaultReferenceSyntaxError:
            return RedactionResult(
                redacted_text="",
                data_classification=DataClassification.L4,
                policy_action=RedactionAction.BLOCK,
                reason_codes=("output_vault_reference_malformed",),
            )
        if not output_vault_references.issubset(allowed_vault_references):
            return RedactionResult(
                redacted_text="",
                data_classification=DataClassification.L4,
                policy_action=RedactionAction.BLOCK,
                reason_codes=("output_vault_reference_not_authorized",),
            )

        protected_text = text
        markers: dict[str, str] = {}
        for index, placeholder in enumerate(sorted(allowed_placeholders)):
            marker = f"\ue000CEREBELLUM{index}\ue001"
            if marker in protected_text:
                return RedactionResult(
                    redacted_text="",
                    data_classification=DataClassification.L4,
                    policy_action=RedactionAction.BLOCK,
                    reason_codes=("output_placeholder_marker_collision",),
                )
            protected_text = protected_text.replace(placeholder, marker)
            markers[marker] = placeholder
        for index, reference in enumerate(sorted(allowed_vault_references)):
            marker = f"\ue000CEREBELLUMVAULT{index}\ue001"
            if marker in protected_text:
                return RedactionResult(
                    redacted_text="",
                    data_classification=DataClassification.L4,
                    policy_action=RedactionAction.BLOCK,
                    reason_codes=("output_placeholder_marker_collision",),
                )
            protected_text = protected_text.replace(reference, marker)
            markers[marker] = reference

        result = await self._redactor.redact(
            CerebellumRequest(
                text=protected_text,
                data_classification=DataClassification.L0,
            ),
            context,
        )
        if result.policy_action is RedactionAction.BLOCK:
            return result
        restored_text = result.redacted_text
        for marker, placeholder in markers.items():
            restored_text = restored_text.replace(marker, placeholder)
        return result.model_copy(update={"redacted_text": restored_text})
