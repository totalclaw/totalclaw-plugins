from __future__ import annotations

import asyncio
import ipaddress
from collections.abc import Collection
from urllib.parse import urlsplit

from starlette.datastructures import Headers
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from totalclaw_cerebellum.domain import ErrorEnvelope

_BODY_METHODS = frozenset({"POST", "PUT", "PATCH"})


class LoopbackRequestGuardMiddleware:
    """Reject DNS-rebinding Host/Origin headers on local REST decision paths."""

    def __init__(self, app: ASGIApp, *, guarded_paths: Collection[str]) -> None:
        self._app = app
        self._guarded_paths = frozenset(guarded_paths)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope.get("path") not in self._guarded_paths:
            await self._app(scope, receive, send)
            return

        headers = Headers(scope=scope)
        if not _is_loopback_authority(headers.get("host")):
            await _send_error(scope, receive, send, 421, "invalid_host")
            return
        origin = headers.get("origin")
        if origin is not None and not _is_loopback_origin(origin):
            await _send_error(scope, receive, send, 403, "invalid_origin")
            return
        await self._app(scope, receive, send)


class TransportLimitsMiddleware:
    """Bound request bodies and concurrent work before a transport parses user input."""

    def __init__(
        self,
        app: ASGIApp,
        *,
        limited_paths: Collection[str],
        max_request_bytes: int,
        max_concurrency: int,
        acquire_timeout_seconds: float = 0.05,
    ) -> None:
        if max_request_bytes <= 0 or max_concurrency <= 0:
            raise ValueError("transport limits must be positive")
        if acquire_timeout_seconds <= 0:
            raise ValueError("transport acquire timeout must be positive")
        self._app = app
        self._limited_paths = frozenset(limited_paths)
        self._max_request_bytes = max_request_bytes
        self._semaphore = asyncio.Semaphore(max_concurrency)
        self._acquire_timeout_seconds = acquire_timeout_seconds

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope.get("path") not in self._limited_paths:
            await self._app(scope, receive, send)
            return

        try:
            await asyncio.wait_for(
                self._semaphore.acquire(),
                timeout=self._acquire_timeout_seconds,
            )
        except TimeoutError:
            await _send_error(scope, receive, send, 503, "transport_busy")
            return

        try:
            bounded_receive = receive
            if scope.get("method") in _BODY_METHODS:
                bounded_receive = await self._bounded_receive(scope, receive, send)
                if bounded_receive is None:
                    return
            await self._app(scope, bounded_receive, send)
        finally:
            self._semaphore.release()

    async def _bounded_receive(
        self,
        scope: Scope,
        receive: Receive,
        send: Send,
    ) -> Receive | None:
        content_lengths = [
            value
            for key, value in scope.get("headers", ())
            if key.lower() == b"content-length"
        ]
        if len(content_lengths) > 1:
            await _send_error(scope, receive, send, 400, "invalid_content_length")
            return None
        if content_lengths:
            try:
                declared_length = int(content_lengths[0])
            except ValueError:
                await _send_error(scope, receive, send, 400, "invalid_content_length")
                return None
            if declared_length < 0:
                await _send_error(scope, receive, send, 400, "invalid_content_length")
                return None
            if declared_length > self._max_request_bytes:
                await _send_error(scope, receive, send, 413, "request_too_large")
                return None

        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return None
            if message["type"] != "http.request":
                continue
            body.extend(message.get("body", b""))
            if len(body) > self._max_request_bytes:
                await _send_error(scope, receive, send, 413, "request_too_large")
                return None
            if not message.get("more_body", False):
                break

        replayed = False

        async def replay_receive() -> Message:
            nonlocal replayed
            if replayed:
                return await receive()
            replayed = True
            return {
                "type": "http.request",
                "body": bytes(body),
                "more_body": False,
            }

        return replay_receive


async def _send_error(
    scope: Scope,
    receive: Receive,
    send: Send,
    status_code: int,
    code: str,
) -> None:
    response = JSONResponse(
        status_code=status_code,
        content=ErrorEnvelope(
            code=code,
            message="request rejected",
        ).model_dump(mode="json"),
    )
    await response(scope, receive, send)


def _is_loopback_authority(authority: str | None) -> bool:
    if not authority:
        return False
    try:
        parsed = urlsplit(f"//{authority}")
        host = parsed.hostname
        _ = parsed.port
    except ValueError:
        return False
    if (
        host is None
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path
        or parsed.query
        or parsed.fragment
    ):
        return False
    return _is_loopback_host(host)


def _is_loopback_origin(origin: str) -> bool:
    try:
        parsed = urlsplit(origin)
        host = parsed.hostname
        _ = parsed.port
    except ValueError:
        return False
    if (
        parsed.scheme.casefold() != "http"
        or host is None
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path not in {"", "/"}
        or parsed.query
        or parsed.fragment
    ):
        return False
    return _is_loopback_host(host)


def _is_loopback_host(host: str) -> bool:
    if host.casefold() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False
