from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from datetime import date

from totalclaw_cerebellum.domain.models import (
    CerebellumRequest,
    DataClassification,
    RedactionAction,
    RedactionResult,
    RequestContext,
)

_CLASSIFICATION_RANK = {
    DataClassification.L0: 0,
    DataClassification.L1: 1,
    DataClassification.L2: 2,
    DataClassification.L3: 3,
    DataClassification.L4: 4,
}

_ZERO_WIDTH = frozenset({"\u200b", "\u200c", "\u200d", "\u2060", "\ufeff"})

_PRIVATE_KEY_RE = re.compile(
    r"-----begin (?:rsa |ec |openssh )?private key-----",
)
_JWT_RE = re.compile(
    r"(?<![a-z0-9_-])eyj[a-z0-9_-]{5,}\.[a-z0-9_-]{5,}\.[a-z0-9_-]{5,}"
    r"(?![a-z0-9_-])",
)
_API_KEY_RE = re.compile(
    r"(?<![a-z0-9])(?:sk-[a-z0-9_-]{16,}|ghp_[a-z0-9]{20,}|"
    r"xox[baprs]-[a-z0-9-]{16,}|akia[a-z0-9]{16})(?![a-z0-9])",
)
_BEARER_RE = re.compile(r"\bauthorization\s*:\s*bearer\s+[a-z0-9._~+/=-]{12,}")
_CONNECTION_SECRET_RE = re.compile(
    r"\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis)://"
    r"[^/\s:@]+:[^@\s/]+@",
)
_PASSWORD_RE = re.compile(
    r"(?:\b(?:password|passwd|pwd)\b|密码)\s*(?:[:=]|是|为)\s*[^\s,，;；]{4,}",
)
_SIX_DIGIT_RE = re.compile(r"(?<!\d)\d{6}(?!\d)")

_EMAIL_RE = re.compile(
    r"(?<![a-z0-9.!#$%&'*+/=?^_`{|}~-])"
    r"[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9-]+(?:\.[a-z0-9-]+)+"
    r"(?![a-z0-9-])",
)
_PHONE_RE = re.compile(r"(?<!\d)1[3-9](?:[\s-]?\d){9}(?!\d)")
_CN_ID_RE = re.compile(
    r"(?<!\d)\d{6}(?:19|20)\d{2}(?:0[1-9]|1[0-2])"
    r"(?:0[1-9]|[12]\d|3[01])\d{3}[\dx](?![\dx])",
)
_BANK_NUMBER_RE = re.compile(r"(?<!\d)\d(?:[\s-]?\d){12,18}(?!\d)")

_OTP_DIRECT_PREFIX_RE = re.compile(
    r"(?:验证码|校验码|动态码|短信码|verification\s+code|one[- ]time\s+password)"
    r"\s*(?:是|为|[:=])?\s*$",
)
_OTP_DIRECT_SUFFIX_RE = re.compile(
    r"^\s*(?:是|为|[:=])?\s*"
    r"(?:验证码|校验码|动态码|短信码|verification\s+code|one[- ]time\s+password)",
)
_OTP_ABBREVIATION_PREFIX_RE = re.compile(r"\botp\b\s*(?:是|为|[:=])?\s*$")
_OTP_ABBREVIATION_SUFFIX_RE = re.compile(r"^\s*(?:是|为|[:=])?\s*\botp\b")
_BUSINESS_NUMBER_PREFIX_RE = re.compile(
    r"(?:项目|文件|工单|订单|报告)\s*(?:编号|号码|号)\s*(?:是|为|[:=])?\s*$",
)
_OTP_PROJECT_RE = re.compile(r"\botp\s*(?:项目|project|文件|系统)")
_BANK_CONTEXT_RE = re.compile(
    r"(?:银行卡|信用卡|借记卡|卡号|bank\s+card|credit\s+card|debit\s+card)"
)
_RESERVED_PLACEHOLDER_RE = re.compile(
    r"\[(?:phone|email|cn_id|bank_card)_\d+\]",
)


@dataclass(frozen=True, slots=True)
class _NormalizedText:
    value: str
    original_indices: tuple[int, ...]

    def original_span(self, start: int, end: int) -> tuple[int, int]:
        return self.original_indices[start], self.original_indices[end - 1] + 1


@dataclass(frozen=True, slots=True)
class _Finding:
    start: int
    end: int
    info_type: str
    classification: DataClassification
    reason_code: str
    placeholder: str | None


class LocalRuleRedactor:
    """Deterministic local DLP baseline; not a production DLP replacement."""

    async def redact(
        self,
        request: CerebellumRequest,
        context: RequestContext,
    ) -> RedactionResult:
        del context
        if request.data_classification is DataClassification.L4:
            return _blocked(
                DataClassification.L4,
                "l4_data_blocked",
            )

        if _RESERVED_PLACEHOLDER_RE.search(_normalize(request.text).value):
            return _blocked(
                request.data_classification,
                "reserved_placeholder_input_blocked",
            )

        findings = _scan(request.text)
        blocking_findings = tuple(
            finding
            for finding in findings
            if finding.classification is DataClassification.L4
        )
        if blocking_findings:
            return RedactionResult(
                redacted_text="",
                data_classification=DataClassification.L4,
                entity_count=len(findings),
                policy_action=RedactionAction.BLOCK,
                reason_codes=_reason_codes(blocking_findings),
            )

        if not findings:
            if request.data_classification is DataClassification.L0:
                return RedactionResult(
                    redacted_text=request.text,
                    data_classification=DataClassification.L0,
                    policy_action=RedactionAction.ALLOW,
                )
            return _blocked(
                request.data_classification,
                "declared_sensitive_data_unresolved",
            )

        detected_classification = _max_classification(
            *(finding.classification for finding in findings)
        )
        if _classification_rank(detected_classification) < _classification_rank(
            request.data_classification
        ):
            return _blocked(
                request.data_classification,
                "declared_sensitive_data_unresolved",
                entity_count=len(findings),
            )

        classification = _max_classification(
            request.data_classification,
            detected_classification,
        )
        redacted_text = _replace_findings(request.text, findings)
        residual = _scan(redacted_text)
        if residual:
            residual_classification = _max_classification(
                classification,
                *(finding.classification for finding in residual),
            )
            return _blocked(
                residual_classification,
                "redaction_verification_failed",
                entity_count=len(findings) + len(residual),
            )

        return RedactionResult(
            redacted_text=redacted_text,
            data_classification=classification,
            entity_count=len(findings),
            policy_action=RedactionAction.REDACT,
            reason_codes=_reason_codes(findings),
        )


def _scan(text: str) -> tuple[_Finding, ...]:
    normalized = _normalize(text)
    findings: list[_Finding] = []

    findings.extend(
        _regex_findings(
            normalized,
            _PRIVATE_KEY_RE,
            "PRIVATE_KEY",
            DataClassification.L4,
            "private_key_blocked",
        )
    )
    findings.extend(
        _regex_findings(
            normalized,
            _JWT_RE,
            "JWT",
            DataClassification.L4,
            "api_credential_blocked",
        )
    )
    findings.extend(
        _regex_findings(
            normalized,
            _API_KEY_RE,
            "API_KEY",
            DataClassification.L4,
            "api_credential_blocked",
        )
    )
    findings.extend(
        _regex_findings(
            normalized,
            _BEARER_RE,
            "BEARER_TOKEN",
            DataClassification.L4,
            "api_credential_blocked",
        )
    )
    findings.extend(
        _regex_findings(
            normalized,
            _CONNECTION_SECRET_RE,
            "CONNECTION_SECRET",
            DataClassification.L4,
            "connection_secret_blocked",
        )
    )
    findings.extend(
        _regex_findings(
            normalized,
            _PASSWORD_RE,
            "PASSWORD",
            DataClassification.L4,
            "authentication_secret_blocked",
        )
    )
    findings.extend(_otp_findings(normalized))

    findings.extend(
        _regex_findings(
            normalized,
            _EMAIL_RE,
            "EMAIL",
            DataClassification.L1,
            "email_address_redacted",
            placeholder="EMAIL",
        )
    )
    findings.extend(
        _regex_findings(
            normalized,
            _PHONE_RE,
            "PHONE",
            DataClassification.L1,
            "phone_number_redacted",
            placeholder="PHONE",
        )
    )
    findings.extend(_cn_id_findings(normalized))
    findings.extend(_bank_card_findings(normalized))
    return _select_non_overlapping(findings)


def _normalize(text: str) -> _NormalizedText:
    normalized_chars: list[str] = []
    original_indices: list[int] = []
    for index, character in enumerate(text):
        if character in _ZERO_WIDTH:
            continue
        normalized_piece = unicodedata.normalize("NFKC", character).casefold()
        for normalized_character in normalized_piece:
            normalized_chars.append(normalized_character)
            original_indices.append(index)
    return _NormalizedText(
        value="".join(normalized_chars),
        original_indices=tuple(original_indices),
    )


def _regex_findings(
    normalized: _NormalizedText,
    pattern: re.Pattern[str],
    info_type: str,
    classification: DataClassification,
    reason_code: str,
    *,
    placeholder: str | None = None,
) -> list[_Finding]:
    findings: list[_Finding] = []
    for match in pattern.finditer(normalized.value):
        start, end = normalized.original_span(*match.span())
        findings.append(
            _Finding(
                start=start,
                end=end,
                info_type=info_type,
                classification=classification,
                reason_code=reason_code,
                placeholder=placeholder,
            )
        )
    return findings


def _otp_findings(normalized: _NormalizedText) -> list[_Finding]:
    findings: list[_Finding] = []
    for match in _SIX_DIGIT_RE.finditer(normalized.value):
        prefix = normalized.value[max(0, match.start() - 32) : match.start()]
        suffix = normalized.value[match.end() : match.end() + 32]
        window = prefix + suffix
        if _BUSINESS_NUMBER_PREFIX_RE.search(prefix):
            continue
        has_strong_context = (
            _OTP_DIRECT_PREFIX_RE.search(prefix)
            or _OTP_DIRECT_SUFFIX_RE.search(suffix)
        )
        has_otp_abbreviation = (
            _OTP_ABBREVIATION_PREFIX_RE.search(prefix)
            or _OTP_ABBREVIATION_SUFFIX_RE.search(suffix)
        )
        if not has_strong_context and (
            not has_otp_abbreviation or _OTP_PROJECT_RE.search(window)
        ):
            continue
        start, end = normalized.original_span(*match.span())
        findings.append(
            _Finding(
                start=start,
                end=end,
                info_type="ONE_TIME_PASSWORD",
                classification=DataClassification.L4,
                reason_code="authentication_secret_blocked",
                placeholder=None,
            )
        )
    return findings


def _cn_id_findings(normalized: _NormalizedText) -> list[_Finding]:
    findings: list[_Finding] = []
    for match in _CN_ID_RE.finditer(normalized.value):
        candidate = match.group()
        if not _valid_cn_id(candidate):
            continue
        start, end = normalized.original_span(*match.span())
        findings.append(
            _Finding(
                start=start,
                end=end,
                info_type="CN_ID",
                classification=DataClassification.L3,
                reason_code="government_id_redacted",
                placeholder="CN_ID",
            )
        )
    return findings


def _bank_card_findings(normalized: _NormalizedText) -> list[_Finding]:
    findings: list[_Finding] = []
    for match in _BANK_NUMBER_RE.finditer(normalized.value):
        prefix = normalized.value[max(0, match.start() - 24) : match.start()]
        if not _BANK_CONTEXT_RE.search(prefix):
            continue
        digits = re.sub(r"\D", "", match.group())
        if not _valid_luhn(digits):
            continue
        start, end = normalized.original_span(*match.span())
        findings.append(
            _Finding(
                start=start,
                end=end,
                info_type="BANK_CARD",
                classification=DataClassification.L3,
                reason_code="financial_identifier_redacted",
                placeholder="BANK_CARD",
            )
        )
    return findings


def _valid_cn_id(candidate: str) -> bool:
    if candidate[:6] == "000000":
        return False
    try:
        date(
            int(candidate[6:10]),
            int(candidate[10:12]),
            int(candidate[12:14]),
        )
    except ValueError:
        return False
    weights = (7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2)
    check_codes = "10x98765432"
    checksum = sum(int(digit) * weight for digit, weight in zip(candidate[:17], weights))
    return candidate[-1] == check_codes[checksum % 11]


def _valid_luhn(digits: str) -> bool:
    if not 13 <= len(digits) <= 19 or len(set(digits)) == 1:
        return False
    total = 0
    parity = len(digits) % 2
    for index, character in enumerate(digits):
        value = int(character)
        if index % 2 == parity:
            value *= 2
            if value > 9:
                value -= 9
        total += value
    return total % 10 == 0


def _select_non_overlapping(findings: list[_Finding]) -> tuple[_Finding, ...]:
    prioritized = sorted(
        findings,
        key=lambda finding: (
            -_CLASSIFICATION_RANK[finding.classification],
            finding.start,
            -(finding.end - finding.start),
        ),
    )
    selected: list[_Finding] = []
    for finding in prioritized:
        if any(
            finding.start < existing.end and existing.start < finding.end
            for existing in selected
        ):
            continue
        selected.append(finding)
    return tuple(sorted(selected, key=lambda finding: finding.start))


def _replace_findings(text: str, findings: tuple[_Finding, ...]) -> str:
    counters: dict[str, int] = {}
    replacements: list[tuple[int, int, str]] = []
    for finding in findings:
        if finding.placeholder is None:
            continue
        counters[finding.placeholder] = counters.get(finding.placeholder, 0) + 1
        replacement = f"[{finding.placeholder}_{counters[finding.placeholder]}]"
        replacements.append((finding.start, finding.end, replacement))

    result = text
    for start, end, replacement in reversed(replacements):
        result = result[:start] + replacement + result[end:]
    return result


def _reason_codes(findings: tuple[_Finding, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(finding.reason_code for finding in findings))


def _max_classification(
    *values: DataClassification,
) -> DataClassification:
    return max(values, key=_CLASSIFICATION_RANK.__getitem__)


def _classification_rank(value: DataClassification) -> int:
    return _CLASSIFICATION_RANK[value]


def _blocked(
    classification: DataClassification,
    reason_code: str,
    *,
    entity_count: int = 0,
) -> RedactionResult:
    return RedactionResult(
        redacted_text="",
        data_classification=classification,
        entity_count=entity_count,
        policy_action=RedactionAction.BLOCK,
        reason_codes=(reason_code,),
    )
