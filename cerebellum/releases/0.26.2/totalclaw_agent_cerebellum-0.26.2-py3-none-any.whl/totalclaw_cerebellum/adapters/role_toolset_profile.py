from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from totalclaw_cerebellum.adapters.file_cache import (
    BoundedValidationCache,
    FileVersion,
    file_version,
)
from totalclaw_cerebellum.domain import (
    CapabilityCandidate,
    CapabilityReference,
    CatalogEvidenceStatus,
    IdentityContext,
    RoleToolsetProfile,
    SkillIdentityVisibility,
)

MAX_ROLE_TOOLSET_PROFILE_BYTES = 262_144
_TOOLSET_PERMISSION_PREFIX = "toolset."


class RoleToolsetProfileIntegrityError(ValueError):
    """Sanitized startup failure for an invalid P2 role profile."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


_ROLE_TOOLSET_PROFILE_CACHE = BoundedValidationCache[RoleToolsetProfile]()
_ROLE_TOOLSET_BINDING_CACHE = BoundedValidationCache[bool](max_entries=64)


def load_role_toolset_profile(
    path: str | Path,
    *,
    environment: str = "development",
) -> RoleToolsetProfile:
    try:
        version = file_version(path)
    except OSError:
        raise RoleToolsetProfileIntegrityError(
            "role_toolset_profile_document_unreadable"
        ) from None
    normalized_environment = environment.casefold()
    profile = _ROLE_TOOLSET_PROFILE_CACHE.get_or_load(
        (version, normalized_environment),
        lambda: _load_role_toolset_profile_uncached(
            version,
            normalized_environment,
        ),
    )
    return profile.model_copy(deep=True)


def _load_role_toolset_profile_uncached(
    version: FileVersion,
    environment: str,
) -> RoleToolsetProfile:
    try:
        document = Path(version.path).read_bytes()
        if len(document) > MAX_ROLE_TOOLSET_PROFILE_BYTES:
            raise RoleToolsetProfileIntegrityError(
                "role_toolset_profile_document_too_large"
            )
        payload = json.loads(
            document.decode("utf-8"),
            object_pairs_hook=_unique_object,
        )
        profile = RoleToolsetProfile.model_validate(payload)
    except RoleToolsetProfileIntegrityError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise RoleToolsetProfileIntegrityError(
            "role_toolset_profile_document_unreadable"
        ) from None
    except ValidationError:
        raise RoleToolsetProfileIntegrityError(
            "role_toolset_profile_schema_invalid"
        ) from None

    if (
        environment == "production"
        and profile.evidence_status is CatalogEvidenceStatus.FIXTURE
    ):
        raise RoleToolsetProfileIntegrityError(
            "fixture_role_toolset_profile_forbidden_in_production"
        )
    return profile


def validate_role_toolset_profile_binding(
    profile: RoleToolsetProfile,
    *,
    catalog_id: str | None,
    available_toolsets: frozenset[str] | None,
) -> None:
    _ROLE_TOOLSET_BINDING_CACHE.get_or_load(
        (profile.model_dump_json(), catalog_id, available_toolsets),
        lambda: _validate_role_toolset_profile_binding_uncached(
            profile,
            catalog_id=catalog_id,
            available_toolsets=available_toolsets,
        ),
    )


def _validate_role_toolset_profile_binding_uncached(
    profile: RoleToolsetProfile,
    *,
    catalog_id: str | None,
    available_toolsets: frozenset[str] | None,
) -> bool:
    if catalog_id != profile.catalog_id:
        raise RoleToolsetProfileIntegrityError(
            "role_toolset_profile_catalog_mismatch"
        )
    if available_toolsets is None:
        return True
    configured_toolsets = frozenset(
        (
            *profile.core_toolsets,
            *(
                toolset
                for toolsets in profile.role_toolsets.values()
                for toolset in toolsets
            ),
        )
    )
    if not configured_toolsets.issubset(available_toolsets):
        raise RoleToolsetProfileIntegrityError(
            "role_toolset_profile_unknown_toolset"
        )
    return True


class RoleToolsetIdentityFilter:
    """Apply the 0803 P2 profile to display tools only, never authorization."""

    def __init__(self, profile: RoleToolsetProfile) -> None:
        self.profile = profile
        self._role_toolsets = {
            role.casefold(): frozenset(toolsets)
            for role, toolsets in profile.role_toolsets.items()
        }

    @property
    def configured(self) -> bool:
        return True

    async def evaluate(
        self,
        identity: IdentityContext,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> SkillIdentityVisibility:
        roles = frozenset(role.casefold() for role in identity.roles)
        if not identity.authenticated or not roles:
            return SkillIdentityVisibility()
        if not roles.issubset(self._role_toolsets):
            return SkillIdentityVisibility(
                reason_codes=("role_toolset_unknown_show_all",),
            )

        allowed_toolsets = set(self.profile.core_toolsets)
        for role in roles:
            allowed_toolsets.update(self._role_toolsets[role])

        hidden = tuple(
            CapabilityReference(
                tool_id=candidate.tool.tool_id,
                action_id=candidate.action.action_id,
            )
            for candidate in candidates
            if _candidate_is_outside_toolsets(candidate, allowed_toolsets)
        )
        return SkillIdentityVisibility(
            hidden_capabilities=hidden,
            reason_codes=("role_toolset_profile_applied",),
        )


def catalog_toolsets(candidates: tuple[CapabilityCandidate, ...]) -> frozenset[str]:
    return frozenset(
        toolset
        for candidate in candidates
        for toolset in _candidate_toolsets(candidate)
    )


def _candidate_toolsets(candidate: CapabilityCandidate) -> frozenset[str]:
    return permission_toolsets(candidate.tool.required_permissions)


def permission_toolsets(required_permissions: frozenset[str]) -> frozenset[str]:
    return frozenset(
        permission[len(_TOOLSET_PERMISSION_PREFIX) :].casefold()
        for permission in required_permissions
        if permission.casefold().startswith(_TOOLSET_PERMISSION_PREFIX)
        and len(permission) > len(_TOOLSET_PERMISSION_PREFIX)
    )


def _candidate_is_outside_toolsets(
    candidate: CapabilityCandidate,
    allowed_toolsets: set[str],
) -> bool:
    toolsets = _candidate_toolsets(candidate)
    return bool(toolsets) and toolsets.isdisjoint(allowed_toolsets)


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise RoleToolsetProfileIntegrityError(
                "role_toolset_profile_duplicate_json_key"
            )
        result[key] = value
    return result
