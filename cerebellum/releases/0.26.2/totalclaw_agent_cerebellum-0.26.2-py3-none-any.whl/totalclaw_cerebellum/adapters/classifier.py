"""Classification backends behind :class:`ClassifierPort`.

Three adapters, in increasing order of trust required:

``NullClassifier``
    The default. Never configured, so the calibrated stage stays inactive and
    the routing ladder behaves exactly as it did before.

``DeterministicLexicalClassifier``
    An offline, dependency-free baseline that answers the same three primitives
    from lexical overlap. It ships no model and downloads nothing. Its evidence
    status is ``deterministic``, and it declares neither arithmetic trust nor
    injection resistance, so the calibrated stage will refuse to let it decide
    a write or an arithmetic turn. It exists so the stage is testable and so a
    host can run it in shadow mode before wiring a real backend.

``HttpClassificationClient``
    A boundary for a real classification endpoint. Loopback-only unless a
    trusted operator opts into a remote host, strict response validation, hard
    response-size ceiling, and no vendor type is allowed past this module.
"""

from __future__ import annotations

import json
import math
import re
import unicodedata
from collections import Counter
from urllib.parse import urlsplit

import httpx

from totalclaw_cerebellum.domain import (
    NONE_OF_THESE_OPTION,
    BooleanVerdict,
    ChoiceVerdict,
    ClassificationBatch,
    ClassificationVerdicts,
    ClassifierEvidenceStatus,
    ClassifierProfile,
    ScoreVerdict,
)

_SEGMENT_PATTERN = re.compile(r"[a-z0-9]+|[㐀-䶿一-鿿]")
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})
_INJECTION_MARKERS = (
    "ignore previous",
    "ignore all previous",
    "disregard the above",
    "system prompt",
    "you are now",
    "developer mode",
    "忽略之前",
    "忽略上面",
    "系统提示词",
    "扮演管理员",
)
_WRITE_MARKERS = (
    "delete",
    "remove",
    "drop",
    "transfer",
    "deploy",
    "shutdown",
    "revoke",
    "删除",
    "转账",
    "下线",
    "撤销",
    "上线",
)


def _tokens(text: str) -> list[str]:
    normalized = unicodedata.normalize("NFKC", text).casefold()
    return _SEGMENT_PATTERN.findall(normalized)


def _contains_any(text: str, markers: tuple[str, ...]) -> bool:
    normalized = unicodedata.normalize("NFKC", text).casefold()
    return any(marker in normalized for marker in markers)


def _normalize(weights: list[float]) -> tuple[float, ...]:
    total = sum(weights)
    if total <= 0.0 or not math.isfinite(total):
        uniform = 1.0 / len(weights)
        return tuple(uniform for _ in weights)
    scaled = [weight / total for weight in weights]
    # Re-absorb floating point drift into the largest bucket so the strict
    # domain validator always sees a normalized distribution.
    drift = 1.0 - sum(scaled)
    top = max(range(len(scaled)), key=scaled.__getitem__)
    scaled[top] = min(1.0, max(0.0, scaled[top] + drift))
    return tuple(scaled)


class NullClassifier:
    """Default backend: always inactive."""

    @property
    def configured(self) -> bool:
        return False

    @property
    def profile(self) -> ClassifierProfile | None:
        return None

    async def classify(self, batch: ClassificationBatch) -> ClassificationVerdicts:
        raise RuntimeError("classifier_not_configured")


class DeterministicLexicalClassifier:
    """Offline lexical baseline for the three classification primitives."""

    classifier_id = "deterministic_lexical_v1"

    def __init__(self, *, max_batched_questions: int = 32) -> None:
        self._profile = ClassifierProfile(
            classifier_id=self.classifier_id,
            evidence_status=ClassifierEvidenceStatus.DETERMINISTIC,
            max_options=255,
            max_batched_questions=max_batched_questions,
            selection_trusted_languages=frozenset({"en", "zh"}),
            arithmetic_trusted=False,
            multi_hop_trusted=False,
            injection_resistant=False,
        )

    @property
    def configured(self) -> bool:
        return True

    @property
    def profile(self) -> ClassifierProfile:
        return self._profile

    async def classify(self, batch: ClassificationBatch) -> ClassificationVerdicts:
        query = Counter(_tokens(batch.redacted_text))
        return ClassificationVerdicts(
            classifier_id=self.classifier_id,
            booleans=tuple(
                BooleanVerdict(
                    question_id=question.question_id,
                    probability_true=(
                        0.95 if _contains_any(batch.redacted_text, _INJECTION_MARKERS) else 0.02
                    ),
                )
                for question in batch.booleans
            ),
            choices=tuple(
                ChoiceVerdict(
                    question_id=question.question_id,
                    probabilities=self._choice_distribution(query, question.options),
                )
                for question in batch.choices
            ),
            scores=tuple(
                ScoreVerdict(
                    question_id=question.question_id,
                    distribution=self._score_distribution(
                        batch.redacted_text,
                        question.scale_size,
                    ),
                )
                for question in batch.scores
            ),
        )

    def _choice_distribution(
        self,
        query: Counter[str],
        options: tuple[str, ...],
    ) -> tuple[float, ...]:
        weights: list[float] = []
        for option in options:
            if option == NONE_OF_THESE_OPTION:
                weights.append(0.0)
                continue
            option_tokens = set(_tokens(option))
            overlap = sum(query[token] for token in option_tokens)
            weights.append(float(overlap))
        # The sentinel absorbs whatever the option set failed to explain, which
        # is what keeps a weak match from being reported as a confident one.
        matched = sum(weights)
        weights[-1] = 1.0 if matched <= 0.0 else 1.0 / (1.0 + matched)
        return _normalize(weights)

    def _score_distribution(self, text: str, scale_size: int) -> tuple[float, ...]:
        weights = [1.0 for _ in range(scale_size)]
        if _contains_any(text, _WRITE_MARKERS):
            weights[-1] += float(scale_size)
        else:
            weights[0] += float(scale_size)
        return _normalize(weights)


class ClassifierResponseError(RuntimeError):
    """Fixed-code failure for an unusable classification response."""


class HttpClassificationClient:
    """Strict boundary for an external classification endpoint."""

    def __init__(
        self,
        *,
        base_url: str,
        classifier_id: str,
        profile: ClassifierProfile | None = None,
        allow_remote: bool = False,
        timeout_seconds: float = 1.0,
        max_response_bytes: int = 65_536,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        parsed = urlsplit(base_url)
        if parsed.scheme not in {"http", "https"}:
            raise ValueError("classifier base_url must be an http(s) URL")
        if not allow_remote and (parsed.hostname or "").casefold() not in _LOOPBACK_HOSTS:
            raise ValueError("classifier base_url must be loopback unless remote is allowed")
        if timeout_seconds <= 0.0:
            raise ValueError("classifier timeout must be positive")
        if max_response_bytes < 1024:
            raise ValueError("classifier response ceiling is too small")
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.max_response_bytes = max_response_bytes
        self._transport = transport
        self._profile = profile or ClassifierProfile(
            classifier_id=classifier_id,
            evidence_status=ClassifierEvidenceStatus.FIXTURE,
        )
        if self._profile.classifier_id != classifier_id:
            raise ValueError("classifier profile id must match the configured classifier id")

    @property
    def configured(self) -> bool:
        return True

    @property
    def profile(self) -> ClassifierProfile:
        return self._profile

    async def classify(self, batch: ClassificationBatch) -> ClassificationVerdicts:
        payload = {
            "input": batch.redacted_text,
            "language": batch.language,
            "boolean": [
                {"id": item.question_id, "proposition": item.proposition}
                for item in batch.booleans
            ],
            "choice": [
                {"id": item.question_id, "prompt": item.prompt, "options": list(item.options)}
                for item in batch.choices
            ],
            "score": [
                {"id": item.question_id, "prompt": item.prompt, "scale": item.scale_size}
                for item in batch.scores
            ],
        }
        async with httpx.AsyncClient(
            timeout=self.timeout_seconds,
            transport=self._transport,
        ) as client:
            response = await client.post(f"{self.base_url}/classify", json=payload)
        if response.status_code != 200:
            raise ClassifierResponseError("classifier_http_status")
        body = response.content[: self.max_response_bytes + 1]
        if len(body) > self.max_response_bytes:
            raise ClassifierResponseError("classifier_response_too_large")
        try:
            parsed = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ClassifierResponseError("classifier_response_not_json") from exc
        if not isinstance(parsed, dict):
            raise ClassifierResponseError("classifier_response_not_object")
        try:
            return ClassificationVerdicts(
                classifier_id=str(parsed.get("classifier_id", "")),
                booleans=tuple(
                    BooleanVerdict(
                        question_id=str(item["id"]),
                        probability_true=float(item["probability_true"]),
                    )
                    for item in parsed.get("boolean", ())
                ),
                choices=tuple(
                    ChoiceVerdict(
                        question_id=str(item["id"]),
                        probabilities=tuple(float(value) for value in item["probabilities"]),
                    )
                    for item in parsed.get("choice", ())
                ),
                scores=tuple(
                    ScoreVerdict(
                        question_id=str(item["id"]),
                        distribution=tuple(float(value) for value in item["distribution"]),
                    )
                    for item in parsed.get("score", ())
                ),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ClassifierResponseError("classifier_response_schema") from exc
