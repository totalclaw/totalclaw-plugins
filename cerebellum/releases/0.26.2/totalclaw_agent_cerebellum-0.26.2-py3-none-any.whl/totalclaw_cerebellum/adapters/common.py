from __future__ import annotations

import asyncio
from typing import Literal

from pydantic import Field, model_validator

from totalclaw_cerebellum.application import CerebellumService
from totalclaw_cerebellum.domain.models import (
    CapabilityReference,
    CerebellumRequest,
    CerebellumResponse,
    DataClassification,
    IdentityHints,
    LocaleTag,
    LtmContextEntry,
    PlanningLevel,
    ProductDecision,
    ProductSafetyDecision,
    RequestContext,
    RequestIdentifier,
    RiskLevel,
    SafetyAction,
    StrictModel,
    ToolBudgetPlan,
    UserTurnHistory,
)
from totalclaw_cerebellum.ports.contracts import IdentityResolverPort

MAX_AVAILABLE_CAPABILITIES = 4_096
MAX_LTM_CONTEXT_ENTRIES = 5


class RouteTransportRequest(StrictModel):
    """Shared HTTP/MCP input. Identity fields remain untrusted until resolved."""

    text: str = Field(min_length=1, max_length=32_768)
    tenant_id: str = Field(min_length=1)
    user_id: str = Field(min_length=1)
    request_id: RequestIdentifier | None = None
    session_id: RequestIdentifier | None = None
    locale: LocaleTag = "zh-CN"
    granted_scopes: frozenset[str] = Field(default_factory=frozenset)
    data_classification: DataClassification = DataClassification.L0
    is_write_intent: bool = False

    def to_domain_request(self) -> CerebellumRequest:
        values = {
            "text": self.text,
            "session_id": self.session_id,
            "locale": self.locale,
            "data_classification": self.data_classification,
            "is_write_intent": self.is_write_intent,
        }
        if self.request_id is not None:
            values["request_id"] = self.request_id
        return CerebellumRequest.model_validate(values)

    def identity_hints(self) -> IdentityHints:
        return IdentityHints(
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            granted_scopes=self.granted_scopes,
        )


class ProductDecisionTransportRequest(RouteTransportRequest):
    """HTTP decision input; capability policy facts are never accepted here."""

    schema_version: Literal["1"]
    available_capabilities: tuple[CapabilityReference, ...] = Field(
        default=(),
        max_length=MAX_AVAILABLE_CAPABILITIES,
    )
    ltm_context: tuple[LtmContextEntry, ...] = Field(
        default=(),
        max_length=MAX_LTM_CONTEXT_ENTRIES,
    )
    user_turn_history: UserTurnHistory | None = None

    @model_validator(mode="after")
    def require_unique_capability_references(self) -> ProductDecisionTransportRequest:
        references = tuple(
            (item.tool_id, item.action_id) for item in self.available_capabilities
        )
        if len(references) != len(set(references)):
            raise ValueError("available capability references must be unique")
        return self


async def resolve_transport_identity(
    payload: RouteTransportRequest,
    *,
    channel: str,
    service: CerebellumService,
    identity_resolver: IdentityResolverPort,
) -> tuple[RequestContext | None, str | None]:
    """Resolve untrusted hints without allowing adapter exceptions to escape."""

    try:
        context = RequestContext.model_validate(
            await asyncio.wait_for(
                identity_resolver.resolve(payload.identity_hints(), channel),
                timeout=service.timeouts.identity_seconds,
            )
        )
    except TimeoutError:
        return None, "identity_timeout"
    except Exception:  # noqa: BLE001 - transport details must not cross the boundary
        return None, "identity_resolution_failed"
    return context, None


async def route_from_transport(
    payload: RouteTransportRequest,
    *,
    channel: str,
    service: CerebellumService,
    identity_resolver: IdentityResolverPort,
) -> CerebellumResponse:
    request = payload.to_domain_request()
    context, failure = await resolve_transport_identity(
        payload,
        channel=channel,
        service=service,
        identity_resolver=identity_resolver,
    )
    if context is None:
        return await service.identity_failure_response(
            request,
            failure or "identity_resolution_failed",
        )
    return await service.route(request, context)


async def decide_from_transport(
    payload: ProductDecisionTransportRequest,
    *,
    channel: str,
    service: CerebellumService,
    identity_resolver: IdentityResolverPort,
) -> ProductDecision:
    """Resolve HTTP capability references against the trusted authorized Registry."""

    request = payload.to_domain_request()
    context, identity_failure = await resolve_transport_identity(
        payload,
        channel=channel,
        service=service,
        identity_resolver=identity_resolver,
    )
    if context is None:
        return product_failure_decision(
            request.request_id,
            identity_failure or "identity_resolution_failed",
            is_write_intent=request.is_write_intent,
        )

    requested = tuple(
        (item.tool_id, item.action_id) for item in payload.available_capabilities
    )
    candidate_reason: str | None = None
    candidates = ()
    if requested:
        try:
            registry_configured = service.registry.configured
            if not registry_configured:
                candidate_reason = "candidate_registry_unconfigured"
            else:
                authorized = await asyncio.wait_for(
                    service.registry.list_authorized(context.identity),
                    timeout=service.timeouts.registry_seconds,
                )
                by_reference = {
                    (candidate.tool.tool_id, candidate.action.action_id): candidate
                    for candidate in authorized
                }
                candidates = tuple(
                    by_reference[reference]
                    for reference in requested
                    if reference in by_reference
                )
                if len(candidates) != len(requested):
                    candidate_reason = "candidate_reference_filtered"
        except TimeoutError:
            candidate_reason = "candidate_registry_timeout"
        except Exception:  # noqa: BLE001 - Registry details must remain internal
            candidate_reason = "candidate_registry_unavailable"

    try:
        decision = await service.decide_v2(
            request,
            context,
            candidates,
            ltm_context=[item.model_dump(mode="python") for item in payload.ltm_context],
            user_turn_history=payload.user_turn_history,
        )
    except Exception:  # noqa: BLE001 - a valid transport request must fail closed
        return product_failure_decision(
            request.request_id,
            "product_decision_unavailable",
            is_write_intent=request.is_write_intent,
        )
    if candidate_reason is None:
        return decision
    plan_payload = decision.plan.model_dump(mode="python")
    plan_payload.update(
        degraded=True,
        reason_codes=decision.plan.reason_codes + (candidate_reason,),
    )
    return ProductDecision(
        request_id=decision.request_id,
        safety=decision.safety,
        plan=ToolBudgetPlan.model_validate(plan_payload),
    )


def product_failure_decision(
    request_id: str,
    reason_code: str,
    *,
    is_write_intent: bool = False,
) -> ProductDecision:
    """Return the fixed fail-closed ProductDecision used at adapter boundaries."""

    return ProductDecision(
        request_id=request_id,
        safety=ProductSafetyDecision(
            action=SafetyAction.BLOCK,
            redacted_text=None,
            data_classification=DataClassification.L4,
            risk_level=RiskLevel.CRITICAL,
            is_write_intent=is_write_intent,
            reason_codes=(reason_code,),
        ),
        plan=ToolBudgetPlan(
            tools=(),
            display_tools=(),
            authorized_capability_count=0,
            authorized_tool_count=0,
            level=PlanningLevel.BYPASS,
            narrowed=False,
            degraded=True,
            reason_codes=(reason_code,),
        ),
    )
