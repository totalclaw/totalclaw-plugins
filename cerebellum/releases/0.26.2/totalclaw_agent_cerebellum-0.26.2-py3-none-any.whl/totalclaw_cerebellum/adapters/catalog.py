from __future__ import annotations

import json
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from pydantic import ValidationError

from totalclaw_cerebellum.adapters.file_cache import (
    BoundedValidationCache,
    FileVersion,
    file_version,
)
from totalclaw_cerebellum.domain import (
    CapabilityCatalog,
    CatalogEvidenceStatus,
    ToolCard,
)


class CatalogIntegrityError(ValueError):
    """A sanitized startup error for an invalid capability catalog."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


_CATALOG_CACHE = BoundedValidationCache[CapabilityCatalog]()


def load_capability_catalog(
    path: str | Path,
    *,
    environment: str = "development",
) -> CapabilityCatalog:
    try:
        version = file_version(path)
    except OSError:
        raise CatalogIntegrityError("catalog_document_unreadable") from None
    normalized_environment = environment.casefold()
    catalog = _CATALOG_CACHE.get_or_load(
        (version, normalized_environment),
        lambda: _load_capability_catalog_uncached(
            version,
            normalized_environment,
        ),
    )
    return catalog.model_copy(deep=True)


def _load_capability_catalog_uncached(
    version: FileVersion,
    environment: str,
) -> CapabilityCatalog:
    try:
        payload = json.loads(
            Path(version.path).read_text(encoding="utf-8"),
            object_pairs_hook=_unique_object,
        )
        catalog = CapabilityCatalog.model_validate(payload)
        _validate_tool_schemas(catalog.tools)
    except CatalogIntegrityError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise CatalogIntegrityError("catalog_document_unreadable") from None
    except ValidationError:
        raise CatalogIntegrityError("catalog_schema_invalid") from None

    if (
        environment.casefold() == "production"
        and catalog.evidence_status is CatalogEvidenceStatus.FIXTURE
    ):
        raise CatalogIntegrityError("fixture_catalog_forbidden_in_production")
    return catalog


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise CatalogIntegrityError("catalog_duplicate_json_key")
        result[key] = value
    return result


def _validate_tool_schemas(tools: Iterable[ToolCard]) -> None:
    try:
        for tool in tools:
            Draft202012Validator.check_schema(tool.input_schema)
            if tool.output_schema is not None:
                Draft202012Validator.check_schema(tool.output_schema)
    except SchemaError:
        raise CatalogIntegrityError("catalog_tool_schema_invalid") from None
