from __future__ import annotations

import asyncio
import re
from typing import Any

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError
from mcp.server.transport_security import TransportSecuritySettings
from starlette.types import ASGIApp

from totalclaw_cerebellum.adapters.candidate_view import model_visible_candidate
from totalclaw_cerebellum.adapters.common import RouteTransportRequest, route_from_transport
from totalclaw_cerebellum.adapters.defaults import UntrustedIdentityResolver
from totalclaw_cerebellum.adapters.transport_limits import TransportLimitsMiddleware
from totalclaw_cerebellum.application import CerebellumService
from totalclaw_cerebellum.bootstrap import build_service
from totalclaw_cerebellum.domain.models import IdentityHints
from totalclaw_cerebellum.ports.contracts import IdentityResolverPort

MCP_TOOL_NAMES = ("cerebellum_route", "registry_search", "service_status")
MCP_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})
_SAFE_TOOL_FAILURES = {
    "cerebellum_route": "route_request_failed",
    "registry_search": "registry_search_failed",
    "service_status": "service_status_failed",
}


class _SafeFastMCP(FastMCP):
    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> Any:
        try:
            return await super().call_tool(name, arguments)
        except Exception:  # noqa: BLE001 - MCP errors must never echo input or port details
            raise ToolError(
                _SAFE_TOOL_FAILURES.get(name, "tool_request_failed")
            ) from None


def create_mcp_server(
    service: CerebellumService | None = None,
    identity_resolver: IdentityResolverPort | None = None,
    *,
    host: str = "127.0.0.1",
    port: int = 8081,
    streamable_http_path: str = "/mcp",
    json_response: bool = False,
    stateless_http: bool = True,
    log_level: str = "INFO",
) -> FastMCP:
    normalized_host = host.casefold()
    if normalized_host not in MCP_LOOPBACK_HOSTS:
        raise ValueError("MCP Streamable HTTP is restricted to a loopback host")
    if not 1 <= port <= 65_535:
        raise ValueError("MCP Streamable HTTP port must be between 1 and 65535")
    if not _is_safe_mcp_path(streamable_http_path):
        raise ValueError("MCP Streamable HTTP path must be a non-root absolute path")

    active_service = service or build_service()
    active_identity_resolver = identity_resolver or UntrustedIdentityResolver()
    server = _SafeFastMCP(
        "TotalClaw Cerebellum",
        host=normalized_host,
        port=port,
        streamable_http_path=streamable_http_path,
        json_response=json_response,
        stateless_http=stateless_http,
        log_level=log_level.upper(),
        transport_security=_loopback_transport_security(),
    )

    @server.tool(name="cerebellum_route")
    async def cerebellum_route(
        text: str,
        tenant_id: str,
        user_id: str,
        request_id: str | None = None,
        session_id: str | None = None,
        locale: str = "zh-CN",
        granted_scopes: list[str] | None = None,
        data_classification: str = "L0",
        is_write_intent: bool = False,
    ) -> dict[str, Any]:
        """Route a request without executing a real tool."""
        response = await route_from_transport(
            RouteTransportRequest(
                text=text,
                tenant_id=tenant_id,
                user_id=user_id,
                request_id=request_id,
                session_id=session_id,
                locale=locale,
                granted_scopes=frozenset(granted_scopes or ()),
                data_classification=data_classification,
                is_write_intent=is_write_intent,
            ),
            channel="mcp",
            service=active_service,
            identity_resolver=active_identity_resolver,
        )
        return response.model_dump(mode="json")

    @server.tool(name="registry_search")
    async def registry_search(
        query: str,
        tenant_id: str,
        user_id: str,
        granted_scopes: list[str] | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Search approved ToolCard/ActionCard pairs visible to the resolved identity."""
        try:
            context = await asyncio.wait_for(
                active_identity_resolver.resolve(
                    IdentityHints(
                        tenant_id=tenant_id,
                        user_id=user_id,
                        granted_scopes=frozenset(granted_scopes or ()),
                    ),
                    "mcp",
                ),
                timeout=active_service.timeouts.identity_seconds,
            )
        except TimeoutError:
            raise RuntimeError("identity_resolution_timeout") from None
        except Exception:  # noqa: BLE001 - MCP boundary returns a fixed tool error
            raise RuntimeError("identity_resolution_failed") from None
        candidates = await active_service.search_registry(query, context, limit)
        return [model_visible_candidate(candidate) for candidate in candidates]

    @server.tool(name="service_status")
    def service_status() -> dict[str, Any]:
        """Return component status without implying model or executor availability."""
        return active_service.status().model_dump(mode="json")

    return server


def create_mcp_http_app(
    service: CerebellumService | None = None,
    identity_resolver: IdentityResolverPort | None = None,
    *,
    host: str = "127.0.0.1",
    port: int = 8081,
    streamable_http_path: str = "/mcp",
    max_request_bytes: int = 262_144,
    max_concurrency: int = 32,
    log_level: str = "WARNING",
) -> ASGIApp:
    server = create_mcp_server(
        service,
        identity_resolver,
        host=host,
        port=port,
        streamable_http_path=streamable_http_path,
        json_response=False,
        stateless_http=True,
        log_level=log_level,
    )
    return TransportLimitsMiddleware(
        server.streamable_http_app(),
        limited_paths={streamable_http_path},
        max_request_bytes=max_request_bytes,
        max_concurrency=max_concurrency,
    )


def _loopback_transport_security() -> TransportSecuritySettings:
    return TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=[
            "127.0.0.1",
            "127.0.0.1:*",
            "localhost",
            "localhost:*",
            "[::1]",
            "[::1]:*",
        ],
        allowed_origins=[
            "http://127.0.0.1:*",
            "http://localhost:*",
            "http://[::1]:*",
        ],
    )


def _is_safe_mcp_path(value: str) -> bool:
    return bool(
        value != "/"
        and not value.endswith("/")
        and re.fullmatch(r"/[A-Za-z0-9._~/-]+", value)
        and all(segment not in {"", ".", ".."} for segment in value.split("/")[1:])
    )
