"""Entry point used by the TotalClaw agent plugin shim.

The shim that ships inside the agent is deliberately tiny: it downloads this
runtime, imports this module, and calls one function per turn. Everything that
decides anything lives here, so the distributed plugin carries no routing logic
of its own and cannot drift from the service.

Both entry points are total: a failure anywhere returns a safety hold rather
than raising into the host's turn loop.
"""

from __future__ import annotations

from collections.abc import Callable

from totalclaw_cerebellum import __version__
from totalclaw_cerebellum.adapters.common import (
    RouteTransportRequest,
    product_failure_decision,
)
from totalclaw_cerebellum.adapters.host import (
    HostServiceFactory,
    decide_from_host,
    decide_from_host_sync,
)
from totalclaw_cerebellum.application.calibrated_router import (
    CalibratedClassificationRouter,
)
from totalclaw_cerebellum.application.legacy_extension import compose_extension
from totalclaw_cerebellum.domain.models import (
    CalibratedRoutingOutcome,
    CapabilityCandidate,
    CerebellumExtensionResult,
    ClassifierRoutingConfig,
    ExtensionMode,
    LegacyEngineSnapshot,
    ProductDecision,
    RedactionAction,
    SafeRoutingRequest,
    SafetyAction,
    UserTurnHistory,
)
from totalclaw_cerebellum.ports.contracts import ClassifierPort, IdentityResolverPort


def _safe_extension_result(reason_code: str, payload: RouteTransportRequest) -> CerebellumExtensionResult:
    request = payload.to_domain_request()
    return CerebellumExtensionResult(
        cerebellum_version=__version__,
        mode=ExtensionMode.SAFETY_HOLD,
        decision=product_failure_decision(
            request.request_id,
            reason_code,
            is_write_intent=request.is_write_intent,
        ),
        tool_ids=(),
        reason_codes=("extension_safety_hold", reason_code),
    )


def _safe_routing_view(
    payload: RouteTransportRequest,
    decision: ProductDecision,
) -> SafeRoutingRequest | None:
    """Rebuild the post-redaction view the classifier is allowed to see.

    ``redaction_action`` is reported as ``redact`` rather than ``allow``: the
    product safety channel does not say whether the text was rewritten, and the
    conservative reading is the correct one at this boundary.
    """

    if decision.safety.action is not SafetyAction.ALLOW:
        return None
    if decision.safety.redacted_text is None:
        return None
    try:
        return SafeRoutingRequest(
            request_id=decision.request_id,
            session_id=payload.session_id,
            locale=payload.locale,
            redacted_text=decision.safety.redacted_text,
            data_classification=decision.safety.data_classification,
            redaction_action=RedactionAction.REDACT,
            is_write_intent=decision.safety.is_write_intent,
        )
    except ValueError:
        return None


async def _calibrate(
    payload: RouteTransportRequest,
    decision: ProductDecision,
    candidates: tuple[CapabilityCandidate, ...],
    classifier: ClassifierPort | None,
    classifier_config: ClassifierRoutingConfig | None,
    classifier_timeout_seconds: float,
) -> CalibratedRoutingOutcome | None:
    router = CalibratedClassificationRouter(
        classifier=classifier,
        config=classifier_config,
        timeout_seconds=classifier_timeout_seconds,
    )
    if not router.active:
        return None
    safe_request = _safe_routing_view(payload, decision)
    if safe_request is None:
        return None
    return await router.evaluate(safe_request, candidates)


async def extend_legacy_engine(
    payload: RouteTransportRequest,
    available_candidates: tuple[CapabilityCandidate, ...],
    *,
    channel: str,
    legacy: LegacyEngineSnapshot | None = None,
    identity_resolver: IdentityResolverPort | None = None,
    service_factory: HostServiceFactory | None = None,
    classifier: ClassifierPort | None = None,
    classifier_config: ClassifierRoutingConfig | None = None,
    classifier_timeout_seconds: float = 1.0,
    ltm_context: list[dict[str, object]] | None = None,
    ltm_log_fn: Callable[[dict[str, object]], None] | None = None,
    user_turn_history: UserTurnHistory | None = None,
) -> CerebellumExtensionResult:
    """Extend the host's 1.0 pre-router with the 2.0 safety and plan channels."""

    try:
        decision = await decide_from_host(
            payload,
            available_candidates,
            channel=channel,
            identity_resolver=identity_resolver,
            service_factory=service_factory,
            ltm_context=ltm_context,
            ltm_log_fn=ltm_log_fn,
            user_turn_history=user_turn_history,
        )
        calibration = await _calibrate(
            payload,
            decision,
            available_candidates,
            classifier,
            classifier_config,
            classifier_timeout_seconds,
        )
        return compose_extension(
            cerebellum_version=__version__,
            decision=decision,
            legacy=legacy,
            calibration=calibration,
        )
    except Exception:  # noqa: BLE001 - the host turn loop must never see our failures
        return _safe_extension_result("extension_unavailable", payload)


def extend_legacy_engine_sync(
    payload: RouteTransportRequest,
    available_candidates: tuple[CapabilityCandidate, ...],
    *,
    channel: str,
    legacy: LegacyEngineSnapshot | None = None,
    identity_resolver: IdentityResolverPort | None = None,
    service_factory: HostServiceFactory | None = None,
    ltm_context: list[dict[str, object]] | None = None,
    ltm_log_fn: Callable[[dict[str, object]], None] | None = None,
    user_turn_history: UserTurnHistory | None = None,
) -> CerebellumExtensionResult:
    """Synchronous variant for the agent's synchronous turn loop.

    The calibrated stage is deliberately absent here: the synchronous bridge is
    already a thread hop, and the 1.0 engine's contract is a zero-cost
    pre-router. Hosts that want the classification stage drive the async entry
    point instead.
    """

    try:
        decision = decide_from_host_sync(
            payload,
            available_candidates,
            channel=channel,
            identity_resolver=identity_resolver,
            service_factory=service_factory,
            ltm_context=ltm_context,
            ltm_log_fn=ltm_log_fn,
            user_turn_history=user_turn_history,
        )
        return compose_extension(
            cerebellum_version=__version__,
            decision=decision,
            legacy=legacy,
            calibration=None,
        )
    except Exception:  # noqa: BLE001 - the host turn loop must never see our failures
        return _safe_extension_result("extension_unavailable", payload)


__all__ = [
    "extend_legacy_engine",
    "extend_legacy_engine_sync",
]
