from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from jsonschema.exceptions import ValidationError as JsonSchemaValidationError

from totalclaw_cerebellum.domain.models import (
    ActionCard,
    AffinitySnapshotHandle,
    ApprovalRequirement,
    AuditEvent,
    CapabilityCandidate,
    CapabilityCatalog,
    CapabilityReference,
    CatalogEvidenceStatus,
    CerebellumRequest,
    ConfirmationPolicy,
    DataClassification,
    FalseBlockRecord,
    HandoffEnvelope,
    HandoffReceipt,
    IdentityContext,
    IdentityHints,
    IntentType,
    MemoryEvent,
    MemoryWriteReceipt,
    OperationKind,
    RedactionAction,
    RedactionResult,
    RequestContext,
    RiskLevel,
    RouteDecision,
    Router0Result,
    Router0Status,
    Router1Output,
    RouterProfile,
    RouterProfileEvidenceStatus,
    RouteType,
    RoutingFeedbackRecord,
    SafeRoutingRequest,
    SkillIdentityVisibility,
    ToolCard,
    ToolExecutionRequest,
    ToolExecutionResult,
    ToolStatus,
)

#: Router-0 的写操作词表。子串匹配，大小写无关。
#:
#: 这份表只会让判定更保守：命中即 confirm，漏判才是真正的失败模式。一个中文
#: 删除请求写成「删掉」而不是「删除」就直接放行，是实际踩到过的漏判，所以同义
#: 写法要一并覆盖。相反，过于通用的英文词（单独的 ``drop`` / ``push`` /
#: ``commit``）会把正常的读请求打成 confirm，所以只收它们的动宾搭配。
WRITE_MARKERS = frozenset(
    {
        # 删除 / 清除
        "删除",
        "删掉",
        "清空",
        "移除",
        "卸载",
        "格式化",
        "重置",
        "覆盖",
        # 发送 / 资金
        "发送",
        "付款",
        "转账",
        "下单",
        # 运维 / 权限
        "修改权限",
        "下线",
        "撤销",
        "停用",
        "禁用",
        "关机",
        "重启",
        "部署",
        "推送代码",
        "提交代码",
        # English
        "delete",
        "remove",
        "overwrite",
        "truncate",
        "drop table",
        "drop database",
        "rm -rf",
        "shutdown",
        "reboot",
        "revoke",
        "deploy",
        "git push",
        "git commit",
        "send",
        "pay",
    }
)


class UntrustedIdentityResolver:
    """Fail closed until an authenticated transport adapter replaces this resolver."""

    async def resolve(self, hints: IdentityHints, channel: str) -> RequestContext:
        return RequestContext(
            identity=IdentityContext(
                tenant_id=hints.tenant_id,
                user_id=hints.user_id,
                authenticated=False,
                source=f"unverified_{channel}_hints",
            ),
            channel=channel,
            memory_write_allowed=False,
        )


class MetadataOnlyRedactor:
    """Boundary placeholder; caller classification is metadata, not verified DLP output."""

    async def redact(self, request: CerebellumRequest, context: RequestContext) -> RedactionResult:
        if request.data_classification is DataClassification.L0:
            return RedactionResult(
                redacted_text=request.text,
                data_classification=DataClassification.L0,
                policy_action=RedactionAction.ALLOW,
            )
        reason = (
            "l4_data_blocked"
            if request.data_classification is DataClassification.L4
            else "sensitive_redactor_not_configured"
        )
        return RedactionResult(
            redacted_text="",
            data_classification=request.data_classification,
            policy_action=RedactionAction.BLOCK,
            reason_codes=(reason,),
        )


class RuleRouter0:
    async def route(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
    ) -> Router0Result:
        normalized = request.redacted_text.casefold()
        is_write = request.is_write_intent or any(marker in normalized for marker in WRITE_MARKERS)
        if is_write:
            return Router0Result(
                status=Router0Status.CONFIRM,
                is_write_op=True,
                risk_level=RiskLevel.HIGH,
                reason_codes=("write_operation_requires_confirmation",),
            )
        return Router0Result(status=Router0Status.UNRESOLVED)


class NullRouter1:
    @property
    def configured(self) -> bool:
        return False

    @property
    def model_id(self) -> None:
        return None

    @property
    def prompt_version(self) -> None:
        return None

    async def route(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> Router1Output:
        return Router1Output(
            decision=RouteDecision(
                intent_type=IntentType.UNKNOWN,
                route_decision=RouteType.BRAIN_HANDOFF,
                confidence=0.0,
                data_classification=request.data_classification,
                handoff_reason="router_not_configured",
                policy_reasons=("router1_unavailable",),
            )
        )


class NoopBrain:
    @property
    def configured(self) -> bool:
        return False

    async def handoff(self, envelope: HandoffEnvelope) -> HandoffReceipt:
        return HandoffReceipt(accepted=False, reason="brain_not_configured")


class NoopMemory:
    @property
    def enabled(self) -> bool:
        return False

    async def append(self, event: MemoryEvent) -> MemoryWriteReceipt:
        return MemoryWriteReceipt(persisted=False, reason="memory_disabled")

    async def search(self, tenant_id: str, query: str, limit: int = 5) -> tuple[dict, ...]:
        return ()


class NullAffinityLearning:
    """Default P4 adapter: no learned state and no effect on ordering."""

    @property
    def enabled(self) -> bool:
        return False

    async def global_top_tools(self, limit: int) -> tuple[str, ...]:
        return ()

    async def top_tools_for_domain(self, domain: str, limit: int) -> tuple[str, ...]:
        return ()

    async def sort_by_affinity(
        self,
        tool_ids: tuple[str, ...],
        domain: str,
    ) -> tuple[str, ...]:
        return tool_ids

    async def success_rate(self, tool_id: str, domain: str) -> float | None:
        return None

    async def snapshot(self) -> AffinitySnapshotHandle | None:
        return None

    async def restore(self, snapshot: AffinitySnapshotHandle) -> None:
        return None


class NullApprovalIntrospection:
    """Default P11 adapter: approval state is unknown and never inferred."""

    @property
    def configured(self) -> bool:
        return False

    async def would_require_approval(
        self,
        tool_id: str,
        args_digest: str,
    ) -> ApprovalRequirement:
        return ApprovalRequirement.UNKNOWN


class NullRewardFeedback:
    """Default P5 adapter: host learning writes are disabled."""

    @property
    def enabled(self) -> bool:
        return False

    def record_tool_result(
        self,
        domain: str,
        tool_name: str,
        succeeded: bool,
    ) -> None:
        return None

    def record_routing(self, record: RoutingFeedbackRecord) -> None:
        return None

    def record_false_block(self, record: FalseBlockRecord) -> None:
        return None


@dataclass(slots=True)
class InMemoryRegistry:
    catalog: CapabilityCatalog | None = None
    tools: dict[str, ToolCard] = field(default_factory=dict)
    actions: dict[str, ActionCard] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.catalog is None:
            return
        if self.tools or self.actions:
            raise ValueError("catalog cannot be combined with explicit tools or actions")
        self.tools = {tool.tool_id: tool for tool in self.catalog.tools}
        self.actions = {action.action_id: action for action in self.catalog.actions}

    @classmethod
    def from_catalog(cls, catalog: CapabilityCatalog) -> InMemoryRegistry:
        return cls(catalog=catalog)

    @property
    def configured(self) -> bool:
        return self.catalog is not None

    @property
    def catalog_id(self) -> str | None:
        return self.catalog.catalog_id if self.catalog is not None else None

    @property
    def evidence_status(self) -> CatalogEvidenceStatus | None:
        return self.catalog.evidence_status if self.catalog is not None else None

    @property
    def capability_count(self) -> int:
        return sum(
            1
            for action in self.actions.values()
            if (
                (tool := self.tools.get(action.tool_id)) is not None
                and tool.status is ToolStatus.APPROVED
            )
        )

    async def list_authorized(
        self,
        identity: IdentityContext,
    ) -> tuple[CapabilityCandidate, ...]:
        visible: list[CapabilityCandidate] = []
        for action in sorted(self.actions.values(), key=lambda item: item.action_id):
            tool = self.tools.get(action.tool_id)
            if tool is None or tool.status is not ToolStatus.APPROVED:
                continue
            if tool.allowed_tenants and (
                not identity.authenticated or identity.tenant_id not in tool.allowed_tenants
            ):
                continue
            if tool.allowed_roles and (
                not identity.authenticated or not tool.allowed_roles.intersection(identity.roles)
            ):
                continue
            if tool.required_permissions and (
                not identity.authenticated
                or not tool.required_permissions.issubset(identity.granted_scopes)
            ):
                continue
            visible.append(
                CapabilityCandidate(
                    tool=tool,
                    action=action,
                )
            )
        return tuple(visible)


class IdentityRetriever:
    @property
    def kind(self) -> str:
        return "identity"

    async def retrieve(
        self,
        query: str,
        candidates: tuple[CapabilityCandidate, ...],
        limit: int = 5,
    ) -> tuple[CapabilityCandidate, ...]:
        return candidates[:limit]


class DeclaredSkillIdentityFilter:
    """Hide only explicitly irrelevant skills; missing identity metadata shows all."""

    @property
    def configured(self) -> bool:
        return True

    async def evaluate(
        self,
        identity: IdentityContext,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> SkillIdentityVisibility:
        if not identity.authenticated or not identity.identity_labels:
            return SkillIdentityVisibility()

        normalized_identity_labels = {
            _normalize_identity_label(label) for label in identity.identity_labels
        }
        hidden = tuple(
            CapabilityReference(
                tool_id=candidate.tool.tool_id,
                action_id=candidate.action.action_id,
            )
            for candidate in candidates
            if candidate.action.relevant_identity_labels
            and normalized_identity_labels.isdisjoint(
                _normalize_identity_label(label)
                for label in candidate.action.relevant_identity_labels
            )
        )
        return SkillIdentityVisibility(
            hidden_capabilities=hidden,
            reason_codes=("identity_irrelevant_hidden",) if hidden else (),
        )


def _normalize_identity_label(value: str) -> str:
    return unicodedata.normalize("NFKC", value).strip().casefold()


class FailClosedPolicy:
    def __init__(self, router_profile: RouterProfile | None = None) -> None:
        self.router_profile = router_profile

    async def evaluate(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
        decision: RouteDecision,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> RouteDecision:
        if decision.route_decision is RouteType.BLOCK:
            return _replace_decision(
                decision,
                data_classification=_max_classification(
                    request.data_classification,
                    decision.data_classification,
                ),
                risk_level=_max_risk(decision.risk_level, RiskLevel.CRITICAL),
            )

        if _classification_rank(decision.data_classification) < _classification_rank(
            request.data_classification
        ):
            return _policy_handoff(
                decision,
                request,
                "model_data_classification_downgrade",
                "data_classification_downgrade_rejected",
            )

        effective_classification = _max_classification(
            request.data_classification,
            decision.data_classification,
        )
        for candidate in candidates:
            if (
                candidate.tool.status is not ToolStatus.APPROVED
                or candidate.action.tool_id != candidate.tool.tool_id
            ):
                return _policy_handoff(
                    decision,
                    request,
                    "unapproved_capability_candidate",
                    "candidate_not_approved",
                )
            if not _candidate_is_authorized(candidate, context.identity):
                return _policy_block(
                    decision,
                    effective_classification,
                    "unauthorized_candidate_exposed",
                )
            try:
                Draft202012Validator.check_schema(candidate.tool.input_schema)
            except SchemaError:
                return _policy_block(
                    decision,
                    effective_classification,
                    "invalid_approved_tool_schema",
                )

        selected_candidate = _selected_candidate(decision, candidates)
        if (decision.selected_tool is None) != (decision.selected_action is None):
            return _policy_handoff(
                decision,
                request,
                "incomplete_capability_selection",
                "selected_capability_incomplete",
            )
        if (
            decision.selected_tool is not None
            and decision.selected_action is not None
            and selected_candidate is None
        ):
            return _policy_handoff(
                decision,
                request,
                "unknown_or_unapproved_capability",
                "selected_capability_not_approved",
            )

        acceptance_failure = self._actionable_route_failure(
            decision,
            selected_candidate,
            candidates,
        )
        if acceptance_failure is not None:
            handoff_reason, reason_code = acceptance_failure
            return _policy_handoff(
                decision,
                request,
                handoff_reason,
                reason_code,
            )

        tool_risk = (
            selected_candidate.tool.risk_level
            if selected_candidate is not None
            else RiskLevel.LOW
        )
        data_risk = _data_risk(effective_classification)
        operation_kind = (
            selected_candidate.action.operation_kind
            if selected_candidate is not None
            else None
        )
        is_write = (
            request.is_write_intent
            or decision.is_write_op
            or operation_kind is OperationKind.WRITE
        )
        intent_risk = RiskLevel.HIGH if is_write else decision.risk_level
        final_risk = _max_risk(intent_risk, tool_risk, data_risk)
        trusted_updates: dict[str, object] = {
            "data_classification": effective_classification,
            "risk_level": final_risk,
            "is_write_op": is_write,
        }
        if is_write and decision.route_decision is RouteType.TOOL_DIRECT:
            trusted_updates["route_decision"] = RouteType.CONFIRM
        decision = _replace_decision(decision, **trusted_updates)

        if selected_candidate is not None:
            missing_required = tuple(
                dict.fromkeys(
                    (
                        *selected_candidate.action.required_slots,
                        *tuple(selected_candidate.tool.input_schema.get("required", ())),
                    )
                )
            )
            missing_required = tuple(
                slot for slot in missing_required if slot not in decision.slots
            )
            if missing_required:
                return _replace_decision(
                    decision,
                    route_decision=RouteType.CLARIFY,
                    missing_required=missing_required,
                    handoff_reason="missing_required_slots",
                    policy_reasons=decision.policy_reasons + ("required_slots_missing",),
                )

            try:
                Draft202012Validator(selected_candidate.tool.input_schema).validate(
                    decision.slots
                )
            except JsonSchemaValidationError:
                return _policy_handoff(
                    decision,
                    request,
                    "invalid_tool_arguments",
                    "tool_arguments_schema_mismatch",
                )

        confirmation_required = is_write
        if selected_candidate is not None:
            confirmation_required = confirmation_required or (
                operation_kind is not OperationKind.READ
            )
            confirmation_required = confirmation_required or (
                selected_candidate.tool.confirmation_policy is ConfirmationPolicy.ALWAYS
            )
            confirmation_required = confirmation_required or (
                selected_candidate.tool.confirmation_policy
                is ConfirmationPolicy.RISK_BASED
                and final_risk is not RiskLevel.LOW
            )
        if confirmation_required:
            return _replace_decision(
                decision,
                route_decision=RouteType.CONFIRM,
                handoff_reason="write_confirmation_required",
                policy_reasons=decision.policy_reasons
                + ("write_operation_requires_confirmation",),
            )

        if decision.route_decision is RouteType.TOOL_DIRECT:
            if selected_candidate is None:
                return _policy_handoff(
                    decision,
                    request,
                    "missing_capability_selection",
                    "tool_direct_capability_missing",
                )
            if operation_kind is not OperationKind.READ or final_risk is not RiskLevel.LOW:
                return _replace_decision(
                    decision,
                    route_decision=RouteType.CONFIRM,
                    handoff_reason="risk_confirmation_required",
                    policy_reasons=decision.policy_reasons
                    + ("tool_direct_not_low_risk_read",),
                )

        return decision

    def _actionable_route_failure(
        self,
        decision: RouteDecision,
        selected_candidate: CapabilityCandidate | None,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> tuple[str, str] | None:
        if decision.route_decision not in {
            RouteType.TOOL_DIRECT,
            RouteType.SLM_ANSWER,
        }:
            return None

        profile = self.router_profile
        if (
            profile is None
            or profile.evidence_status is not RouterProfileEvidenceStatus.VALIDATED
        ):
            return "router_profile_not_validated", "actionable_route_profile_locked"

        if decision.route_decision is RouteType.SLM_ANSWER:
            if not profile.slm_answer_enabled:
                return "slm_answer_not_enabled", "actionable_route_disabled"
            if decision.confidence < profile.slm_answer_min_confidence:
                return "router1_low_confidence", "slm_answer_confidence_below_threshold"
            return None

        if not profile.tool_direct_enabled:
            return "tool_direct_not_enabled", "actionable_route_disabled"
        if selected_candidate is None:
            return "missing_capability_selection", "tool_direct_capability_missing"
        if (
            decision.confidence < profile.tool_direct_min_confidence
            or decision.tool_confidence < profile.tool_direct_min_confidence
        ):
            return "router1_low_confidence", "tool_confidence_below_threshold"
        if not candidates or candidates[0] is not selected_candidate:
            return "router1_candidate_ambiguous", "selected_candidate_not_top_ranked"

        next_best_score = max(
            (
                candidate.retrieval_score
                for candidate in candidates
                if candidate is not selected_candidate
            ),
            default=0.0,
        )
        margin = max(0.0, selected_candidate.retrieval_score - next_best_score)
        if margin < profile.tool_direct_min_retrieval_margin:
            return "router1_candidate_ambiguous", "retrieval_margin_below_threshold"
        return None


_RISK_RANK = {
    RiskLevel.LOW: 0,
    RiskLevel.MEDIUM: 1,
    RiskLevel.HIGH: 2,
    RiskLevel.CRITICAL: 3,
}

_CLASSIFICATION_RANK = {
    DataClassification.L0: 0,
    DataClassification.L1: 1,
    DataClassification.L2: 2,
    DataClassification.L3: 3,
    DataClassification.L4: 4,
}

_DATA_RISK = {
    DataClassification.L0: RiskLevel.LOW,
    DataClassification.L1: RiskLevel.LOW,
    DataClassification.L2: RiskLevel.MEDIUM,
    DataClassification.L3: RiskLevel.HIGH,
    DataClassification.L4: RiskLevel.CRITICAL,
}


def _replace_decision(decision: RouteDecision, **updates: object) -> RouteDecision:
    values = decision.model_dump(mode="python")
    values.update(updates)
    return RouteDecision.model_validate(values)


def _max_risk(*values: RiskLevel) -> RiskLevel:
    return max(values, key=_RISK_RANK.__getitem__)


def _classification_rank(value: DataClassification) -> int:
    return _CLASSIFICATION_RANK[value]


def _max_classification(
    *values: DataClassification,
) -> DataClassification:
    return max(values, key=_CLASSIFICATION_RANK.__getitem__)


def _data_risk(value: DataClassification) -> RiskLevel:
    return _DATA_RISK[value]


def _selected_candidate(
    decision: RouteDecision,
    candidates: tuple[CapabilityCandidate, ...],
) -> CapabilityCandidate | None:
    for candidate in candidates:
        if (
            candidate.tool.tool_id == decision.selected_tool
            and candidate.action.action_id == decision.selected_action
        ):
            return candidate
    return None


def _candidate_is_authorized(
    candidate: CapabilityCandidate,
    identity: IdentityContext,
) -> bool:
    tool = candidate.tool
    if tool.allowed_tenants and (
        not identity.authenticated or identity.tenant_id not in tool.allowed_tenants
    ):
        return False
    if tool.allowed_roles and (
        not identity.authenticated or not tool.allowed_roles.intersection(identity.roles)
    ):
        return False
    return not tool.required_permissions or (
        identity.authenticated
        and tool.required_permissions.issubset(identity.granted_scopes)
    )


def _policy_handoff(
    decision: RouteDecision,
    request: SafeRoutingRequest,
    handoff_reason: str,
    reason_code: str,
) -> RouteDecision:
    classification = _max_classification(
        request.data_classification,
        decision.data_classification,
    )
    return RouteDecision(
        intent_type=decision.intent_type,
        route_decision=RouteType.BRAIN_HANDOFF,
        confidence=0.0,
        is_write_op=decision.is_write_op,
        risk_level=_max_risk(
            decision.risk_level,
            _data_risk(classification),
            RiskLevel.HIGH,
        ),
        data_classification=classification,
        handoff_reason=handoff_reason,
        policy_reasons=decision.policy_reasons + (reason_code,),
        trace_id=decision.trace_id,
    )


def _policy_block(
    decision: RouteDecision,
    classification: DataClassification,
    reason_code: str,
) -> RouteDecision:
    return RouteDecision(
        intent_type=IntentType.SENSITIVE,
        route_decision=RouteType.BLOCK,
        confidence=1.0,
        is_write_op=decision.is_write_op,
        risk_level=RiskLevel.CRITICAL,
        data_classification=classification,
        handoff_reason=reason_code,
        policy_reasons=decision.policy_reasons + (reason_code,),
        trace_id=decision.trace_id,
    )


class NoopAudit:
    async def record(self, event: AuditEvent) -> None:
        return None


class ExecutionDisabledError(RuntimeError):
    pass


class DisabledExecutor:
    @property
    def enabled(self) -> bool:
        return False

    async def execute(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        raise ExecutionDisabledError("tool execution is disabled in the skeleton release")
