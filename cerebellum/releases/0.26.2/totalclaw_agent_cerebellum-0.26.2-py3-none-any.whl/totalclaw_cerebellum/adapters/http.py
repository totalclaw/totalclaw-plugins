from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from totalclaw_cerebellum import __version__
from totalclaw_cerebellum.adapters.common import (
    ProductDecisionTransportRequest,
    RouteTransportRequest,
    decide_from_transport,
    route_from_transport,
)
from totalclaw_cerebellum.adapters.defaults import UntrustedIdentityResolver
from totalclaw_cerebellum.adapters.transport_limits import (
    LoopbackRequestGuardMiddleware,
    TransportLimitsMiddleware,
)
from totalclaw_cerebellum.application import CerebellumService
from totalclaw_cerebellum.bootstrap import build_service
from totalclaw_cerebellum.domain.models import (
    CerebellumResponse,
    ErrorEnvelope,
    ProductDecision,
    ServiceStatus,
)
from totalclaw_cerebellum.ports.contracts import IdentityResolverPort
from totalclaw_cerebellum.settings import Settings


def create_app(
    service: CerebellumService | None = None,
    identity_resolver: IdentityResolverPort | None = None,
) -> FastAPI:
    settings = Settings()
    active_service = service or build_service()
    active_identity_resolver = identity_resolver or UntrustedIdentityResolver()
    app = FastAPI(
        title="TotalClaw Cerebellum",
        version=__version__,
        description="Security-first routing skeleton; no real tool execution.",
    )
    app.add_middleware(
        TransportLimitsMiddleware,
        limited_paths={"/v1/decision", "/v1/route"},
        max_request_bytes=settings.http_max_request_bytes,
        max_concurrency=settings.http_max_concurrency,
    )
    app.add_middleware(
        LoopbackRequestGuardMiddleware,
        guarded_paths={"/v1/decision", "/v1/route"},
    )

    @app.exception_handler(RequestValidationError)
    async def validation_error(
        request: Request,
        exc: RequestValidationError,
    ) -> JSONResponse:
        del request, exc
        return JSONResponse(
            status_code=422,
            content=ErrorEnvelope(
                code="transport_validation_failed",
                message="request schema validation failed",
            ).model_dump(mode="json"),
        )

    @app.get("/healthz", response_model=ServiceStatus)
    async def healthz() -> ServiceStatus:
        return active_service.status()

    @app.get("/readyz", response_model=ServiceStatus)
    async def readyz() -> ServiceStatus:
        return active_service.status()

    @app.post("/v1/route", response_model=CerebellumResponse)
    async def route(payload: RouteTransportRequest) -> CerebellumResponse:
        return await route_from_transport(
            payload,
            channel="http",
            service=active_service,
            identity_resolver=active_identity_resolver,
        )

    @app.post("/v1/decision", response_model=ProductDecision)
    async def decision(payload: ProductDecisionTransportRequest) -> ProductDecision:
        return await decide_from_transport(
            payload,
            channel="http",
            service=active_service,
            identity_resolver=active_identity_resolver,
        )

    return app
