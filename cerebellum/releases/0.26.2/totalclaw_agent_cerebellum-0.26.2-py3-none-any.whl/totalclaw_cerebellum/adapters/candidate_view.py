from __future__ import annotations

from typing import Any

from totalclaw_cerebellum.domain import CapabilityCandidate


def model_visible_candidate(candidate: CapabilityCandidate) -> dict[str, Any]:
    """Return the only capability fields allowed across a model/transport boundary."""

    return {
        "tool_id": candidate.tool.tool_id,
        "action_id": candidate.action.action_id,
        "name": candidate.tool.name,
        "description": candidate.tool.description,
        "intent": candidate.action.intent,
        "operation_kind": candidate.action.operation_kind.value,
        "required_slots": list(candidate.action.required_slots),
        "input_schema": candidate.tool.input_schema,
        "risk_level": candidate.tool.risk_level.value,
        "confirmation_policy": candidate.tool.confirmation_policy.value,
        "retrieval_score": candidate.retrieval_score,
    }
