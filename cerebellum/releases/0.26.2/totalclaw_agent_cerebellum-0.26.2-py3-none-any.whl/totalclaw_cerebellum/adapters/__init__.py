"""Default and protocol-specific adapters."""
