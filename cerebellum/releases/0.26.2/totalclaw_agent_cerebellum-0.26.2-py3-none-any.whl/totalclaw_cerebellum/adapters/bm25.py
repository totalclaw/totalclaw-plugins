from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter

from totalclaw_cerebellum.domain import CapabilityCandidate

_SEGMENT_PATTERN = re.compile(r"[a-z0-9]+|[\u3400-\u4dbf\u4e00-\u9fff]+")
_PLACEHOLDER_PATTERN = re.compile(
    r"(?<![a-z0-9_])\[?(?:phone|email|cn_id|bank_card)_\d+\]?(?![a-z0-9_])"
)


class DeterministicBM25Retriever:
    """Small, dependency-free BM25 baseline for authorized capability candidates."""

    k1 = 1.2
    b = 0.75

    @property
    def kind(self) -> str:
        return "bm25_v1"

    async def retrieve(
        self,
        query: str,
        candidates: tuple[CapabilityCandidate, ...],
        limit: int = 5,
    ) -> tuple[CapabilityCandidate, ...]:
        if limit <= 0 or not candidates:
            return ()
        query_tokens = _tokenize(query)
        if not query_tokens:
            return ()
        strong_query_tokens = _strong_tokens(query)

        documents = tuple(_candidate_tokens(candidate) for candidate in candidates)
        document_frequencies: Counter[str] = Counter()
        for document in documents:
            document_frequencies.update(set(document))
        average_length = sum(len(document) for document in documents) / len(documents)

        scored: list[tuple[float, CapabilityCandidate]] = []
        query_frequencies = Counter(query_tokens)
        document_count = len(documents)
        for candidate, document in zip(candidates, documents, strict=True):
            frequencies = Counter(document)
            if strong_query_tokens and not strong_query_tokens.intersection(frequencies):
                continue
            raw_score = 0.0
            for token, query_frequency in query_frequencies.items():
                frequency = frequencies[token]
                if frequency == 0:
                    continue
                document_frequency = document_frequencies[token]
                inverse_document_frequency = math.log(
                    1.0
                    + (document_count - document_frequency + 0.5)
                    / (document_frequency + 0.5)
                )
                length_ratio = len(document) / average_length if average_length else 0.0
                denominator = frequency + self.k1 * (
                    1.0 - self.b + self.b * length_ratio
                )
                raw_score += (
                    inverse_document_frequency
                    * frequency
                    * (self.k1 + 1.0)
                    / denominator
                    * query_frequency
                )
            if raw_score > 0.0:
                scored.append((raw_score, candidate))

        if not scored:
            return ()
        scored.sort(
            key=lambda item: (
                -item[0],
                item[1].tool.tool_id,
                item[1].action.action_id,
            )
        )
        return tuple(
            candidate.model_copy(
                update={"retrieval_score": raw_score / (raw_score + 1.0)}
            )
            for raw_score, candidate in scored[:limit]
        )


def _candidate_tokens(candidate: CapabilityCandidate) -> tuple[str, ...]:
    action = candidate.action
    tool = candidate.tool
    weighted_fields = (
        (action.intent, 3),
        *((example, 3) for example in action.positive_examples),
        (tool.name, 2),
        (tool.tool_id, 2),
        (action.action_id, 2),
        *((tag, 2) for tag in sorted(action.tags)),
        (tool.description, 1),
    )
    tokens: list[str] = []
    for value, weight in weighted_fields:
        field_tokens = _tokenize(value)
        for _ in range(weight):
            tokens.extend(field_tokens)
    return tuple(tokens)


def _tokenize(value: str) -> tuple[str, ...]:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    normalized = _PLACEHOLDER_PATTERN.sub(" ", normalized)
    tokens: list[str] = []
    for segment in _SEGMENT_PATTERN.findall(normalized):
        if segment.isascii():
            tokens.append(segment)
            continue
        characters = tuple(segment)
        tokens.extend(characters)
        tokens.extend(
            characters[index] + characters[index + 1]
            for index in range(len(characters) - 1)
        )
    return tuple(tokens)


def _strong_tokens(value: str) -> set[str]:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    normalized = _PLACEHOLDER_PATTERN.sub(" ", normalized)
    tokens: set[str] = set()
    for segment in _SEGMENT_PATTERN.findall(normalized):
        if segment.isascii():
            if len(segment) >= 2:
                tokens.add(segment)
            continue
        tokens.update(
            segment[index : index + 2]
            for index in range(len(segment) - 1)
        )
    return tokens
