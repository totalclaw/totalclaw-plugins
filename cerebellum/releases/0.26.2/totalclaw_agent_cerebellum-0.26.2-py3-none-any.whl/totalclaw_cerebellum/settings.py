from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CEREBELLUM_", env_file=".env", extra="ignore")

    host: str = "127.0.0.1"
    port: int = Field(default=8080, ge=1, le=65535)
    http_max_request_bytes: int = Field(
        default=262_144,
        ge=4096,
        le=4_194_304,
    )
    http_max_concurrency: int = Field(default=64, ge=1, le=1024)
    log_level: str = "INFO"
    environment: str = "development"
    catalog_path: Path | None = None
    mcp_http_host: str = "127.0.0.1"
    mcp_http_port: int = Field(default=8081, ge=1, le=65535)
    mcp_http_path: str = Field(
        default="/mcp",
        pattern=r"^/[A-Za-z0-9._~/-]+$",
    )
    mcp_http_max_request_bytes: int = Field(
        default=262_144,
        ge=4096,
        le=4_194_304,
    )
    mcp_http_max_concurrency: int = Field(default=32, ge=1, le=1024)
    router1_base_url: str | None = None
    router1_model: str | None = None
    router1_profile_path: Path | None = None
    router1_evaluation_report_path: Path | None = None
    tool_planning_profile_path: Path | None = None
    role_toolset_profile_path: Path | None = None
    tool_plan_cache_enabled: bool = True
    tool_plan_cache_ttl_seconds: float = Field(
        default=60.0,
        gt=0.0,
        le=3_600.0,
    )
    tool_plan_cache_max_entries: int = Field(
        default=512,
        ge=1,
        le=10_000,
    )
    classifier_backend: Literal["none", "deterministic", "http"] = "none"
    classifier_base_url: str | None = None
    classifier_id: str | None = None
    classifier_allow_remote: bool = False
    classifier_timeout_seconds: float = Field(default=1.0, gt=0.0, le=10.0)
    classifier_max_response_bytes: int = Field(
        default=65_536,
        ge=1024,
        le=1_048_576,
    )
    classifier_routing_enabled: bool = False
    classifier_shortlist_size: int = Field(default=32, ge=2, le=255)
    router1_allow_remote: bool = False
    router1_max_output_tokens: int = Field(default=512, ge=64, le=4096)
    router1_max_response_bytes: int = Field(
        default=65_536,
        ge=1024,
        le=1_048_576,
    )

    @field_validator("host", "mcp_http_host")
    @classmethod
    def require_loopback_http_host(cls, value: str) -> str:
        normalized = value.casefold()
        if normalized not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("HTTP listeners are restricted to a loopback host")
        return normalized

    @field_validator("mcp_http_path")
    @classmethod
    def require_safe_mcp_http_path(cls, value: str) -> str:
        if (
            value == "/"
            or value.endswith("/")
            or any(segment in {"", ".", ".."} for segment in value.split("/")[1:])
        ):
            raise ValueError("MCP Streamable HTTP path must be a non-root absolute path")
        return value
