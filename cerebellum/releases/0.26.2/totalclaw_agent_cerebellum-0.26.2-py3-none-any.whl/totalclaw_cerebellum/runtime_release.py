"""Emit the runtime package index for the release repository.

This is the *runtime* channel, independent of the plugin marketplace channel in
:mod:`plugin_packaging`. It publishes one artifact -- the wheel -- through its
own repository, and the consumers are:

* ``totalclaw get cerebellum`` in the agent CLI, and
* the enterprise app's 通用设置 → 泰途智脑 2.0 → 升级 button,

both of which call the same installer in the agent. The wheel ships from the
``cerebellum/`` subdirectory of the plugin repository, alongside but independent
of the plugin marketplace's ``registry.json``.

The index is the only thing those consumers read before they download anything,
so it carries everything needed to refuse a bad download: an exact size, a
pinned sha256, and per-region source lists.

It carries the runtime wheel only. Model weights are deliberately not
distributed from here -- local model download is an explicit non-goal of this
repository, and the host already owns a weight-download channel.

The index is generated from the wheel actually on disk and merged into any
existing index, so published history is preserved and a digest can never be
hand-written. This module writes nothing to the network.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from totalclaw_cerebellum import __version__

RUNTIME_NAME = "totalclaw-cerebellum"
DEFAULT_REPO_BASE = "https://gitee.com/jlzdyx/totalclaw-plugins"
DEFAULT_PATH_PREFIX = "cerebellum"
PYTHON_REQUIRES = ">=3.11,<3.13"
_WHEEL_PATTERN = re.compile(
    r"^totalclaw_agent_cerebellum-(?P<version>[0-9][0-9A-Za-z.+!-]*)-py3-none-any\.whl$"
)
_MAX_WHEEL_BYTES = 64 * 1024 * 1024


class RuntimeReleaseError(RuntimeError):
    """The wheel is missing, misnamed, oversized, or drifted from the package."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(256 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def version_key(version: str) -> tuple[int, ...]:
    """Sort key for the dotted numeric versions this project publishes."""

    parts: list[int] = []
    for chunk in version.split("."):
        digits = "".join(iter(_leading_digits(chunk)))
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def _leading_digits(chunk: str) -> str:
    for index, character in enumerate(chunk):
        if not character.isdigit():
            return chunk[:index]
    return chunk


def build_release_entry(
    wheel_path: str | Path,
    *,
    repo_base: str = DEFAULT_REPO_BASE,
    branch: str = "master",
    path_prefix: str = DEFAULT_PATH_PREFIX,
) -> dict[str, object]:
    """Describe one publishable wheel."""

    wheel = Path(wheel_path).expanduser().resolve()
    if not wheel.is_file():
        raise RuntimeReleaseError(f"{wheel} is not a file")
    match = _WHEEL_PATTERN.match(wheel.name)
    if match is None:
        raise RuntimeReleaseError(
            f"unexpected wheel name {wheel.name!r}; "
            "expected totalclaw_agent_cerebellum-<version>-py3-none-any.whl"
        )
    version = match.group("version")
    if version != __version__:
        raise RuntimeReleaseError(
            f"wheel version {version!r} does not match package version {__version__!r}"
        )
    size = wheel.stat().st_size
    if size <= 0 or size > _MAX_WHEEL_BYTES:
        raise RuntimeReleaseError(f"wheel size {size} is outside the publishable range")

    base = repo_base.rstrip("/")
    if not base.startswith("https://"):
        raise RuntimeReleaseError("repo_base must be an https URL")
    prefix = path_prefix.strip("/")
    if ".." in prefix.split("/"):
        raise RuntimeReleaseError("path_prefix cannot escape the repository")
    segments = "/".join(part for part in (prefix, "releases", version) if part)
    raw = f"{base}/raw/{branch}/{segments}/{wheel.name}"

    return {
        "version": version,
        "python_requires": PYTHON_REQUIRES,
        "wheel": wheel.name,
        "size_bytes": size,
        "sha256": _sha256(wheel),
        # Both regions point at the same repository today. The field exists so a
        # mirror can be added without changing any consumer.
        "sources": {"cn": [raw], "intl": [raw]},
    }


def build_release_index(
    wheel_path: str | Path,
    *,
    repo_base: str = DEFAULT_REPO_BASE,
    branch: str = "master",
    path_prefix: str = DEFAULT_PATH_PREFIX,
    existing: dict[str, object] | None = None,
) -> dict[str, object]:
    """Merge a new release into the published index."""

    entry = build_release_entry(
        wheel_path,
        repo_base=repo_base,
        branch=branch,
        path_prefix=path_prefix,
    )
    releases: list[dict[str, object]] = []
    if existing is not None:
        if str(existing.get("schema_version")) != "1":
            raise RuntimeReleaseError("existing index schema_version is not supported")
        previous = existing.get("releases")
        if not isinstance(previous, list):
            raise RuntimeReleaseError("existing index has no release list")
        releases = [
            item
            for item in previous
            if isinstance(item, dict) and item.get("version") != entry["version"]
        ]
    releases.append(entry)
    releases.sort(key=lambda item: version_key(str(item.get("version", ""))))
    return {
        "schema_version": "1",
        "runtime_name": RUNTIME_NAME,
        "latest": str(releases[-1]["version"]),
        "releases": releases,
    }


def run_cli(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="cerebellum-build-release-index",
        description="Print the runtime repository index.json for a built wheel.",
    )
    parser.add_argument("wheel", help="path to the built .whl")
    parser.add_argument(
        "--repo-base",
        default=DEFAULT_REPO_BASE,
        help=f"runtime repository base URL (default: {DEFAULT_REPO_BASE})",
    )
    parser.add_argument("--branch", default="master", help="branch serving raw files")
    parser.add_argument(
        "--path-prefix",
        default=DEFAULT_PATH_PREFIX,
        help=f"subdirectory inside the repository (default: {DEFAULT_PATH_PREFIX})",
    )
    parser.add_argument(
        "--merge",
        default=None,
        help="existing index.json to merge into, so published history is kept",
    )
    arguments = parser.parse_args(argv)

    existing = None
    if arguments.merge is not None:
        try:
            existing = json.loads(Path(arguments.merge).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            parser.exit(status=2, message=f"cannot read {arguments.merge}: {exc}\n")
    try:
        index = build_release_index(
            arguments.wheel,
            repo_base=arguments.repo_base,
            branch=arguments.branch,
            path_prefix=arguments.path_prefix,
            existing=existing,
        )
    except RuntimeReleaseError as exc:
        parser.exit(status=2, message=f"{exc}\n")
    print(json.dumps(index, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover - module CLI
    raise SystemExit(run_cli())
