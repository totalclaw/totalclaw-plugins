from __future__ import annotations

import argparse
import os
import stat
import sys
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Annotated, Any, Literal

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError
from pydantic import BaseModel, ConfigDict, Field

from totalclaw_cerebellum.domain import (
    ConfirmationPolicy,
    OperationKind,
    RiskLevel,
)

REFERENCE_FILESYSTEM_TOOL_NAMES = (
    "sandbox_fs.list_directory",
    "sandbox_fs.get_file_info",
    "sandbox_fs.read_text_file",
    "sandbox_fs.search_text",
    "sandbox_fs.create_text_file",
    "sandbox_fs.replace_text",
)

_ALLOWED_SUFFIXES = frozenset({".md", ".txt"})
_MAX_FILE_BYTES = 1_048_576
_MAX_WRITE_BYTES = 262_144
_MAX_SEARCH_FILES = 200
_MAX_PREVIEW_CHARS = 240

RelativePath = Annotated[str, Field(min_length=1, max_length=512)]
MaxEntries = Annotated[int, Field(ge=1, le=200)]
MaxChars = Annotated[int, Field(ge=1, le=100_000)]
MaxResults = Annotated[int, Field(ge=1, le=100)]
SearchQuery = Annotated[str, Field(min_length=1, max_length=256)]
WriteContent = Annotated[str, Field(max_length=_MAX_WRITE_BYTES)]
ExpectedText = Annotated[str, Field(min_length=1, max_length=65_536)]
ReplacementText = Annotated[str, Field(max_length=65_536)]
MaxReplacements = Annotated[int, Field(ge=1, le=100)]


class _ReferenceResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ReferenceActionContract(_ReferenceResult):
    tool_id: str
    action_id: str
    external_tool_name: str
    intent: str
    operation_kind: OperationKind
    risk_level: RiskLevel
    confirmation_policy: ConfirmationPolicy
    required_scope: str


REFERENCE_FILESYSTEM_ACTION_CONTRACTS = (
    ReferenceActionContract(
        tool_id="sandbox_fs.list_directory",
        action_id="sandbox_fs.list_directory.invoke",
        external_tool_name="sandbox_fs.list_directory",
        intent="List direct children of a directory inside the test sandbox",
        operation_kind=OperationKind.READ,
        risk_level=RiskLevel.LOW,
        confirmation_policy=ConfirmationPolicy.NEVER,
        required_scope="sandbox:files:list",
    ),
    ReferenceActionContract(
        tool_id="sandbox_fs.get_file_info",
        action_id="sandbox_fs.get_file_info.invoke",
        external_tool_name="sandbox_fs.get_file_info",
        intent="Get metadata for one text file inside the test sandbox",
        operation_kind=OperationKind.READ,
        risk_level=RiskLevel.LOW,
        confirmation_policy=ConfirmationPolicy.NEVER,
        required_scope="sandbox:files:metadata",
    ),
    ReferenceActionContract(
        tool_id="sandbox_fs.read_text_file",
        action_id="sandbox_fs.read_text_file.invoke",
        external_tool_name="sandbox_fs.read_text_file",
        intent="Read bounded UTF-8 content from one test sandbox file",
        operation_kind=OperationKind.READ,
        risk_level=RiskLevel.MEDIUM,
        confirmation_policy=ConfirmationPolicy.RISK_BASED,
        required_scope="sandbox:files:read",
    ),
    ReferenceActionContract(
        tool_id="sandbox_fs.search_text",
        action_id="sandbox_fs.search_text.invoke",
        external_tool_name="sandbox_fs.search_text",
        intent="Search bounded UTF-8 content below one test sandbox directory",
        operation_kind=OperationKind.READ,
        risk_level=RiskLevel.MEDIUM,
        confirmation_policy=ConfirmationPolicy.RISK_BASED,
        required_scope="sandbox:files:search",
    ),
    ReferenceActionContract(
        tool_id="sandbox_fs.create_text_file",
        action_id="sandbox_fs.create_text_file.invoke",
        external_tool_name="sandbox_fs.create_text_file",
        intent="Create a new text file without overwriting an existing file",
        operation_kind=OperationKind.WRITE,
        risk_level=RiskLevel.HIGH,
        confirmation_policy=ConfirmationPolicy.ALWAYS,
        required_scope="sandbox:files:create",
    ),
    ReferenceActionContract(
        tool_id="sandbox_fs.replace_text",
        action_id="sandbox_fs.replace_text.invoke",
        external_tool_name="sandbox_fs.replace_text",
        intent="Replace explicitly expected text in one existing sandbox file",
        operation_kind=OperationKind.WRITE,
        risk_level=RiskLevel.HIGH,
        confirmation_policy=ConfirmationPolicy.ALWAYS,
        required_scope="sandbox:files:write",
    ),
)


class DirectoryEntry(_ReferenceResult):
    name: str
    kind: Literal["directory", "file", "symlink", "other"]


class ListDirectoryResult(_ReferenceResult):
    directory: str
    entries: tuple[DirectoryEntry, ...]
    truncated: bool


class FileInfoResult(_ReferenceResult):
    path: str
    size_bytes: int = Field(ge=0)
    modified_at: datetime


class ReadTextResult(_ReferenceResult):
    path: str
    content: str
    truncated: bool


class SearchMatch(_ReferenceResult):
    path: str
    line_number: int = Field(ge=1)
    preview: str


class SearchTextResult(_ReferenceResult):
    directory: str
    matches: tuple[SearchMatch, ...]
    scanned_file_count: int = Field(ge=0)
    truncated: bool


class WriteTextResult(_ReferenceResult):
    path: str
    bytes_written: int = Field(ge=0)


class ReplaceTextResult(WriteTextResult):
    replacement_count: int = Field(ge=1)


class SandboxFilesystemError(ValueError):
    """Fixed-code failure that never embeds a path or file content."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


class _StrictReferenceMCP(FastMCP):
    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> Any:
        tool = self._tool_manager.get_tool(name)
        if tool is not None:
            allowed = frozenset(tool.parameters.get("properties", {}))
            if not set(arguments).issubset(allowed):
                raise ToolError("sandbox_arguments_invalid")
        try:
            return await super().call_tool(name, arguments)
        except ToolError:
            raise
        except Exception:  # noqa: BLE001 - validation errors must not echo arguments
            raise ToolError("sandbox_arguments_invalid") from None


class SandboxFilesystem:
    """Small real filesystem implementation constrained to one test sandbox."""

    def __init__(self, root: str | Path, *, write_enabled: bool = False) -> None:
        supplied_root = Path(root)
        if supplied_root.is_symlink():
            raise SandboxFilesystemError("sandbox_root_invalid")
        try:
            resolved_root = supplied_root.resolve(strict=True)
        except OSError:
            raise SandboxFilesystemError("sandbox_root_invalid") from None
        if not resolved_root.is_dir():
            raise SandboxFilesystemError("sandbox_root_invalid")
        self._root = resolved_root
        self._write_enabled = write_enabled

    @property
    def write_enabled(self) -> bool:
        return self._write_enabled

    def list_directory(
        self,
        relative_directory: str = ".",
        max_entries: int = 100,
    ) -> ListDirectoryResult:
        directory = self._resolve_existing_directory(relative_directory)
        entries: list[DirectoryEntry] = []
        try:
            children = sorted(directory.iterdir(), key=lambda item: item.name.casefold())
        except OSError:
            raise SandboxFilesystemError("sandbox_directory_unreadable") from None
        for child in children[:max_entries]:
            entries.append(DirectoryEntry(name=child.name, kind=self._entry_kind(child)))
        return ListDirectoryResult(
            directory=self._display_path(directory),
            entries=tuple(entries),
            truncated=len(children) > max_entries,
        )

    def get_file_info(self, relative_path: str) -> FileInfoResult:
        path = self._resolve_existing_text_file(relative_path)
        try:
            metadata = path.stat()
        except OSError:
            raise SandboxFilesystemError("sandbox_file_unreadable") from None
        return FileInfoResult(
            path=self._display_path(path),
            size_bytes=metadata.st_size,
            modified_at=datetime.fromtimestamp(metadata.st_mtime, tz=UTC),
        )

    def read_text_file(
        self,
        relative_path: str,
        max_chars: int = 10_000,
    ) -> ReadTextResult:
        path = self._resolve_existing_text_file(relative_path)
        content = self._read_bounded_utf8(path)
        return ReadTextResult(
            path=self._display_path(path),
            content=content[:max_chars],
            truncated=len(content) > max_chars,
        )

    def search_text(
        self,
        query: str,
        relative_directory: str = ".",
        max_results: int = 20,
    ) -> SearchTextResult:
        if not query or len(query) > 256:
            raise SandboxFilesystemError("sandbox_query_invalid")
        directory = self._resolve_existing_directory(relative_directory)
        matches: list[SearchMatch] = []
        scanned_file_count = 0
        reached_scan_limit = False

        for path in self._iter_text_files(directory):
            if scanned_file_count >= _MAX_SEARCH_FILES:
                reached_scan_limit = True
                break
            scanned_file_count += 1
            content = self._read_bounded_utf8(path)
            for line_number, line in enumerate(content.splitlines(), start=1):
                if query.casefold() not in line.casefold():
                    continue
                matches.append(
                    SearchMatch(
                        path=self._display_path(path),
                        line_number=line_number,
                        preview=line[:_MAX_PREVIEW_CHARS],
                    )
                )
                if len(matches) >= max_results:
                    return SearchTextResult(
                        directory=self._display_path(directory),
                        matches=tuple(matches),
                        scanned_file_count=scanned_file_count,
                        truncated=True,
                    )
        return SearchTextResult(
            directory=self._display_path(directory),
            matches=tuple(matches),
            scanned_file_count=scanned_file_count,
            truncated=reached_scan_limit,
        )

    def create_text_file(self, relative_path: str, content: str) -> WriteTextResult:
        self._require_write_enabled()
        encoded = self._validate_write_content(content)
        path = self._resolve_new_text_file(relative_path)
        try:
            with path.open("x", encoding="utf-8", newline="\n") as output:
                output.write(content)
                output.flush()
                os.fsync(output.fileno())
        except FileExistsError:
            raise SandboxFilesystemError("sandbox_file_already_exists") from None
        except OSError:
            raise SandboxFilesystemError("sandbox_file_write_failed") from None
        return WriteTextResult(
            path=self._display_path(path),
            bytes_written=len(encoded),
        )

    def replace_text(
        self,
        relative_path: str,
        expected_old_text: str,
        replacement: str,
        max_replacements: int = 1,
    ) -> ReplaceTextResult:
        self._require_write_enabled()
        if not expected_old_text or len(expected_old_text) > 65_536:
            raise SandboxFilesystemError("sandbox_expected_text_invalid")
        if not 1 <= max_replacements <= 100:
            raise SandboxFilesystemError("sandbox_replacement_limit_invalid")
        path = self._resolve_existing_text_file(relative_path)
        content = self._read_bounded_utf8(path)
        available = content.count(expected_old_text)
        if available == 0:
            raise SandboxFilesystemError("sandbox_expected_text_not_found")
        replacement_count = min(available, max_replacements)
        updated = content.replace(expected_old_text, replacement, max_replacements)
        encoded = self._validate_write_content(updated)
        self._rewrite_open_file(path, content, updated)
        return ReplaceTextResult(
            path=self._display_path(path),
            bytes_written=len(encoded),
            replacement_count=replacement_count,
        )

    def _resolve_existing_directory(self, value: str) -> Path:
        path = self._resolve_existing(value)
        if not path.is_dir():
            raise SandboxFilesystemError("sandbox_directory_required")
        return path

    def _resolve_existing_text_file(self, value: str) -> Path:
        parts = self._validated_parts(value, allow_root=False)
        self._require_allowed_suffix(parts[-1])
        path = self._resolve_existing_parts(parts)
        if not path.is_file():
            raise SandboxFilesystemError("sandbox_file_required")
        try:
            size_bytes = path.stat().st_size
        except OSError:
            raise SandboxFilesystemError("sandbox_file_unreadable") from None
        if size_bytes > _MAX_FILE_BYTES:
            raise SandboxFilesystemError("sandbox_file_too_large")
        return path

    def _resolve_existing(self, value: str) -> Path:
        return self._resolve_existing_parts(self._validated_parts(value, allow_root=True))

    def _resolve_existing_parts(self, parts: tuple[str, ...]) -> Path:
        candidate = self._root.joinpath(*parts)
        self._reject_symlink_components(parts, include_leaf=True)
        try:
            resolved = candidate.resolve(strict=True)
        except FileNotFoundError:
            raise SandboxFilesystemError("sandbox_path_not_found") from None
        except OSError:
            raise SandboxFilesystemError("sandbox_path_invalid") from None
        self._require_within_root(resolved)
        return resolved

    def _resolve_new_text_file(self, value: str) -> Path:
        parts = self._validated_parts(value, allow_root=False)
        self._require_allowed_suffix(parts[-1])
        parent_parts = parts[:-1]
        parent = self._resolve_existing_parts(parent_parts)
        if not parent.is_dir():
            raise SandboxFilesystemError("sandbox_parent_directory_required")
        candidate = parent / parts[-1]
        if candidate.is_symlink():
            raise SandboxFilesystemError("sandbox_symlink_forbidden")
        self._require_within_root(candidate)
        return candidate

    def _validated_parts(
        self,
        value: str,
        *,
        allow_root: bool,
    ) -> tuple[str, ...]:
        if (
            not value
            or len(value) > 512
            or value.startswith("/")
            or value.endswith("/")
            or "//" in value
            or "\\" in value
            or any(ord(character) < 32 for character in value)
        ):
            raise SandboxFilesystemError("sandbox_relative_path_invalid")
        if value == ".":
            if allow_root:
                return ()
            raise SandboxFilesystemError("sandbox_relative_path_invalid")
        path = PurePosixPath(value)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
            raise SandboxFilesystemError("sandbox_relative_path_invalid")
        return path.parts

    def _reject_symlink_components(
        self,
        parts: tuple[str, ...],
        *,
        include_leaf: bool,
    ) -> None:
        current = self._root
        checked_parts = parts if include_leaf else parts[:-1]
        for part in checked_parts:
            current /= part
            if current.is_symlink():
                raise SandboxFilesystemError("sandbox_symlink_forbidden")

    def _require_within_root(self, path: Path) -> None:
        try:
            path.relative_to(self._root)
        except ValueError:
            raise SandboxFilesystemError("sandbox_path_outside_root") from None

    def _require_allowed_suffix(self, filename: str) -> None:
        if Path(filename).suffix.casefold() not in _ALLOWED_SUFFIXES:
            raise SandboxFilesystemError("sandbox_file_extension_forbidden")

    def _read_bounded_utf8(self, path: Path) -> str:
        try:
            raw = path.read_bytes()
        except OSError:
            raise SandboxFilesystemError("sandbox_file_unreadable") from None
        if len(raw) > _MAX_FILE_BYTES:
            raise SandboxFilesystemError("sandbox_file_too_large")
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            raise SandboxFilesystemError("sandbox_file_not_utf8") from None

    def _validate_write_content(self, content: str) -> bytes:
        encoded = content.encode("utf-8")
        if len(encoded) > _MAX_WRITE_BYTES:
            raise SandboxFilesystemError("sandbox_write_too_large")
        return encoded

    def _rewrite_open_file(
        self,
        path: Path,
        expected_current: str,
        updated: str,
    ) -> None:
        flags = os.O_RDWR
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        try:
            descriptor = os.open(path, flags)
        except OSError:
            raise SandboxFilesystemError("sandbox_file_write_failed") from None
        try:
            metadata = os.fstat(descriptor)
            if not stat.S_ISREG(metadata.st_mode):
                raise SandboxFilesystemError("sandbox_file_required")
            with os.fdopen(descriptor, "r+", encoding="utf-8", newline="\n") as output:
                descriptor = -1
                output.seek(0)
                current = output.read()
                if len(current.encode("utf-8")) > _MAX_FILE_BYTES:
                    raise SandboxFilesystemError("sandbox_file_too_large")
                if current != expected_current:
                    raise SandboxFilesystemError("sandbox_file_changed")
                output.seek(0)
                output.write(updated)
                output.truncate()
                output.flush()
                os.fsync(output.fileno())
        except UnicodeDecodeError:
            raise SandboxFilesystemError("sandbox_file_not_utf8") from None
        except SandboxFilesystemError:
            raise
        except OSError:
            raise SandboxFilesystemError("sandbox_file_write_failed") from None
        finally:
            if descriptor >= 0:
                os.close(descriptor)

    def _iter_text_files(self, directory: Path):
        for current_root, directory_names, filenames in os.walk(
            directory,
            followlinks=False,
        ):
            current = Path(current_root)
            directory_names[:] = sorted(
                (name for name in directory_names if not (current / name).is_symlink()),
                key=str.casefold,
            )
            for filename in sorted(filenames, key=str.casefold):
                path = current / filename
                if path.is_symlink() or path.suffix.casefold() not in _ALLOWED_SUFFIXES:
                    continue
                try:
                    resolved = path.resolve(strict=True)
                except OSError:
                    continue
                self._require_within_root(resolved)
                if resolved.is_file():
                    yield resolved

    def _entry_kind(self, path: Path) -> Literal["directory", "file", "symlink", "other"]:
        if path.is_symlink():
            return "symlink"
        if path.is_dir():
            return "directory"
        if path.is_file():
            return "file"
        return "other"

    def _display_path(self, path: Path) -> str:
        relative = path.relative_to(self._root)
        return relative.as_posix() or "."

    def _require_write_enabled(self) -> None:
        if not self._write_enabled:
            raise SandboxFilesystemError("sandbox_write_disabled")


def create_reference_filesystem_mcp_server(
    root: str | Path,
    *,
    write_enabled: bool = False,
) -> FastMCP:
    filesystem = SandboxFilesystem(root, write_enabled=write_enabled)
    server = _StrictReferenceMCP(
        "TotalClaw Reference Filesystem",
        log_level="WARNING",
    )

    @server.tool(name="sandbox_fs.list_directory")
    def list_directory(
        relative_directory: RelativePath = ".",
        max_entries: MaxEntries = 100,
    ) -> ListDirectoryResult:
        """List direct children of one directory inside the explicit test sandbox."""
        return _safe_call(
            filesystem.list_directory,
            relative_directory,
            max_entries,
        )

    @server.tool(name="sandbox_fs.get_file_info")
    def get_file_info(relative_path: RelativePath) -> FileInfoResult:
        """Return metadata for one allowed UTF-8 text file inside the test sandbox."""
        return _safe_call(filesystem.get_file_info, relative_path)

    @server.tool(name="sandbox_fs.read_text_file")
    def read_text_file(
        relative_path: RelativePath,
        max_chars: MaxChars = 10_000,
    ) -> ReadTextResult:
        """Read bounded UTF-8 text from one allowed file inside the test sandbox."""
        return _safe_call(filesystem.read_text_file, relative_path, max_chars)

    @server.tool(name="sandbox_fs.search_text")
    def search_text(
        query: SearchQuery,
        relative_directory: RelativePath = ".",
        max_results: MaxResults = 20,
    ) -> SearchTextResult:
        """Search bounded UTF-8 text files below one test sandbox directory."""
        return _safe_call(
            filesystem.search_text,
            query,
            relative_directory,
            max_results,
        )

    @server.tool(name="sandbox_fs.create_text_file")
    def create_text_file(
        relative_path: RelativePath,
        content: WriteContent,
    ) -> WriteTextResult:
        """Create a new text file when test write mode is explicitly enabled."""
        return _safe_call(filesystem.create_text_file, relative_path, content)

    @server.tool(name="sandbox_fs.replace_text")
    def replace_text(
        relative_path: RelativePath,
        expected_old_text: ExpectedText,
        replacement: ReplacementText,
        max_replacements: MaxReplacements = 1,
    ) -> ReplaceTextResult:
        """Replace expected text in one file when test write mode is enabled."""
        return _safe_call(
            filesystem.replace_text,
            relative_path,
            expected_old_text,
            replacement,
            max_replacements,
        )

    for tool_name in REFERENCE_FILESYSTEM_TOOL_NAMES:
        registered = server._tool_manager.get_tool(tool_name)
        if registered is None:
            raise RuntimeError("reference filesystem tool registration failed")
        registered.parameters["additionalProperties"] = False

    return server


def run_reference_filesystem_mcp(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="cerebellum-reference-fs-mcp",
        description="Run the non-production sandbox filesystem reference server over stdio.",
    )
    parser.add_argument("--root", required=True)
    parser.add_argument("--enable-write", action="store_true")
    arguments = parser.parse_args(argv)
    try:
        server = create_reference_filesystem_mcp_server(
            arguments.root,
            write_enabled=arguments.enable_write,
        )
    except SandboxFilesystemError:
        sys.stderr.write("reference_filesystem_configuration_invalid\n")
        raise SystemExit(2) from None
    server.run(transport="stdio")


def _safe_call(function, *arguments):
    try:
        return function(*arguments)
    except SandboxFilesystemError as error:
        raise ToolError(error.reason_code) from None
    except Exception:  # noqa: BLE001 - tool errors must not expose paths or content
        raise ToolError("sandbox_operation_failed") from None


if __name__ == "__main__":
    run_reference_filesystem_mcp()
