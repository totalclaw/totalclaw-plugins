from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections.abc import Iterable
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from pydantic import ValidationError

from totalclaw_cerebellum.domain import (
    ActionCard,
    CapabilityCatalog,
    CatalogEvidenceStatus,
    ConfirmationPolicy,
    McpDiscoverySnapshot,
    McpIntakeDisposition,
    McpIntakeIssue,
    McpIntakeItem,
    McpIntakeReport,
    McpIntakeStatus,
    McpIssueSeverity,
    McpReviewDecision,
    McpReviewManifest,
    McpToolReview,
    McpToolSnapshot,
    McpValidationEvidence,
    OperationKind,
    RiskLevel,
    ToolCard,
    ToolStatus,
)


class McpIntakeInputError(ValueError):
    """Sanitized failure for an unreadable or inconsistent intake artifact."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


def load_mcp_snapshot(path: str | Path) -> McpDiscoverySnapshot:
    return _load_model(path, McpDiscoverySnapshot, "mcp_snapshot")


def load_mcp_evidence(path: str | Path) -> McpValidationEvidence:
    return _load_model(path, McpValidationEvidence, "mcp_evidence")


def load_mcp_review(path: str | Path) -> McpReviewManifest:
    return _load_model(path, McpReviewManifest, "mcp_review")


def snapshot_digest(snapshot: McpDiscoverySnapshot) -> str:
    payload = snapshot.model_dump(mode="json", by_alias=True)
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def intake_mcp_snapshot(
    snapshot: McpDiscoverySnapshot,
    *,
    evidence: McpValidationEvidence | None = None,
    review: McpReviewManifest | None = None,
    catalog_id: str | None = None,
) -> McpIntakeReport:
    digest = snapshot_digest(snapshot)
    tools_by_name = {tool.name: tool for tool in snapshot.tools}
    _validate_related_artifacts(snapshot, digest, tools_by_name, evidence, review)

    review_by_name = {item.tool_name: item for item in review.tools} if review is not None else {}
    issues = _evidence_issues(evidence)
    successful_evidence_tools = (
        {case.tool_name for case in evidence.cases if case.passed and case.tool_name is not None}
        if evidence is not None
        else set()
    )
    server_issues = [issue for issue in issues if issue.tool_name is None]
    per_tool_issues: dict[str, list[McpIntakeIssue]] = {
        tool.name: _static_tool_issues(tool) for tool in snapshot.tools
    }
    for issue in issues:
        if issue.tool_name is not None:
            per_tool_issues[issue.tool_name].append(issue)

    server_blocked = any(
        issue.tool_name is None
        and issue.severity in {McpIssueSeverity.ERROR, McpIssueSeverity.CRITICAL}
        for issue in issues
    )
    catalog_tools: list[ToolCard] = []
    catalog_actions: list[ActionCard] = []
    items: list[McpIntakeItem] = []
    all_issues = list(issues)

    for tool in snapshot.tools:
        tool_issues = per_tool_issues[tool.name]
        review_item = review_by_name.get(tool.name)
        if review_item is not None and review_item.decision is McpReviewDecision.REJECT:
            tool_issues.extend(
                McpIntakeIssue(
                    code=code,
                    severity=McpIssueSeverity.ERROR,
                    tool_name=tool.name,
                )
                for code in review_item.reason_codes
            )
        if (
            review_item is not None
            and review_item.decision is McpReviewDecision.APPROVE
            and tool.name not in successful_evidence_tools
        ):
            tool_issues.append(
                McpIntakeIssue(
                    code="mcp_review_approval_missing_tool_evidence",
                    severity=McpIssueSeverity.ERROR,
                    tool_name=tool.name,
                )
            )
        blocking_issue = server_blocked or any(
            issue.severity in {McpIssueSeverity.ERROR, McpIssueSeverity.CRITICAL}
            for issue in tool_issues
        )
        disposition = _disposition(review_item, blocking_issue)
        if (
            review_item is not None
            and review_item.decision is McpReviewDecision.APPROVE
            and blocking_issue
        ):
            blocked_issue = McpIntakeIssue(
                code="mcp_review_approval_blocked_by_findings",
                severity=McpIssueSeverity.ERROR,
                tool_name=tool.name,
            )
            tool_issues.append(blocked_issue)
        effective_issues = _unique_issues([*server_issues, *tool_issues])
        all_issues.extend(effective_issues)

        tool_id = _tool_id(snapshot.server_id, tool.name)
        action_id = f"{tool_id}.invoke"
        schema_valid = not any(
            issue.code
            in {
                "mcp_input_schema_invalid",
                "mcp_input_schema_not_object",
                "mcp_required_property_undefined",
                "mcp_output_schema_invalid",
                "mcp_external_schema_reference_forbidden",
            }
            for issue in tool_issues
        )
        operation_kind = (
            review_item.operation_kind
            if disposition is McpIntakeDisposition.APPROVED and review_item is not None
            else OperationKind.UNKNOWN
        )
        items.append(
            McpIntakeItem(
                external_tool_name=tool.name,
                tool_id=tool_id,
                action_id=action_id,
                disposition=disposition,
                operation_kind=operation_kind,
                issue_codes=tuple(sorted({issue.code for issue in effective_issues})),
            )
        )
        if not schema_valid:
            continue
        card, action = _catalog_entries(
            snapshot,
            tool,
            tool_id,
            action_id,
            disposition,
            review_item,
        )
        catalog_tools.append(card)
        catalog_actions.append(action)

    approved_count = sum(item.disposition is McpIntakeDisposition.APPROVED for item in items)
    pending_count = sum(item.disposition is McpIntakeDisposition.PENDING for item in items)
    rejected_count = sum(item.disposition is McpIntakeDisposition.REJECTED for item in items)
    status = (
        McpIntakeStatus.REJECTED
        if rejected_count == len(items)
        else (McpIntakeStatus.REVIEWED_FIXTURE if approved_count else McpIntakeStatus.QUARANTINED)
    )
    active_catalog_id = catalog_id or _catalog_id(snapshot.snapshot_id)
    catalog = CapabilityCatalog(
        schema_version="1",
        catalog_id=active_catalog_id,
        evidence_status=CatalogEvidenceStatus.FIXTURE,
        tools=tuple(catalog_tools),
        actions=tuple(catalog_actions),
    )
    return McpIntakeReport(
        schema_version="1",
        snapshot_id=snapshot.snapshot_id,
        server_id=snapshot.server_id,
        server_version=snapshot.server_version,
        snapshot_digest=digest,
        evidence_status=CatalogEvidenceStatus.FIXTURE,
        status=status,
        source_tool_count=len(snapshot.tools),
        catalog_tool_count=len(catalog.tools),
        pending_tool_count=pending_count,
        approved_tool_count=approved_count,
        rejected_tool_count=rejected_count,
        items=tuple(items),
        issues=tuple(_unique_issues(all_issues)),
        catalog=catalog,
        notes=(
            "mcp_intake_is_offline_and_never_invokes_external_tools",
            "mcp_intake_cannot_mint_validated_catalogs",
            "mcp_annotations_and_descriptions_are_untrusted",
        ),
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="cerebellum-import-mcp-snapshot",
        description="Import an offline MCP tools/list snapshot into a fixture quarantine report.",
    )
    parser.add_argument("--snapshot", required=True)
    parser.add_argument("--evidence")
    parser.add_argument("--review")
    parser.add_argument("--catalog-id")
    parser.add_argument("--output")
    parser.add_argument("--catalog-output")
    arguments = parser.parse_args(argv)

    try:
        snapshot = load_mcp_snapshot(arguments.snapshot)
        evidence = load_mcp_evidence(arguments.evidence) if arguments.evidence is not None else None
        review = load_mcp_review(arguments.review) if arguments.review is not None else None
        report = intake_mcp_snapshot(
            snapshot,
            evidence=evidence,
            review=review,
            catalog_id=arguments.catalog_id,
        )
        _write_json(
            report.model_dump(mode="json", by_alias=True),
            arguments.output,
            "mcp_intake_output_unwritable",
        )
        if arguments.catalog_output is not None:
            _write_json(
                report.catalog.model_dump(mode="json"),
                arguments.catalog_output,
                "mcp_intake_catalog_output_unwritable",
            )
    except McpIntakeInputError:
        _write_error("mcp_intake_input_invalid")
        return 2

    return 1 if report.status is McpIntakeStatus.REJECTED else 0


def run_cli() -> None:
    raise SystemExit(main())


def _load_model(path: str | Path, model_type: Any, prefix: str) -> Any:
    try:
        payload = json.loads(
            Path(path).read_text(encoding="utf-8"),
            object_pairs_hook=_unique_object,
        )
        return model_type.model_validate(payload)
    except McpIntakeInputError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise McpIntakeInputError(f"{prefix}_unreadable") from None
    except ValidationError:
        raise McpIntakeInputError(f"{prefix}_invalid") from None


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise McpIntakeInputError("mcp_intake_duplicate_json_key")
        result[key] = value
    return result


def _validate_related_artifacts(
    snapshot: McpDiscoverySnapshot,
    digest: str,
    tools_by_name: dict[str, McpToolSnapshot],
    evidence: McpValidationEvidence | None,
    review: McpReviewManifest | None,
) -> None:
    for artifact in (evidence, review):
        if artifact is None:
            continue
        if artifact.snapshot_id != snapshot.snapshot_id:
            raise McpIntakeInputError("mcp_intake_snapshot_id_mismatch")
        if artifact.snapshot_digest != digest:
            raise McpIntakeInputError("mcp_intake_snapshot_digest_mismatch")
    if evidence is not None:
        names = {
            item.tool_name
            for item in (*evidence.cases, *evidence.findings)
            if item.tool_name is not None
        }
        if not names.issubset(tools_by_name):
            raise McpIntakeInputError("mcp_evidence_unknown_tool")
    if review is not None:
        names = {item.tool_name for item in review.tools}
        if not names.issubset(tools_by_name):
            raise McpIntakeInputError("mcp_review_unknown_tool")


def _evidence_issues(
    evidence: McpValidationEvidence | None,
) -> list[McpIntakeIssue]:
    if evidence is None:
        return []
    issues = list(evidence.findings)
    for case in evidence.cases:
        if case.passed:
            continue
        issues.append(
            McpIntakeIssue(
                code=case.reason_code,
                severity=McpIssueSeverity.ERROR,
                tool_name=case.tool_name,
            )
        )
    return _unique_issues(issues)


def _static_tool_issues(tool: McpToolSnapshot) -> list[McpIntakeIssue]:
    issues: list[McpIntakeIssue] = []
    try:
        Draft202012Validator.check_schema(tool.input_schema)
    except SchemaError:
        issues.append(_issue("mcp_input_schema_invalid", McpIssueSeverity.ERROR, tool.name))
        return issues
    if tool.input_schema.get("type") != "object":
        issues.append(_issue("mcp_input_schema_not_object", McpIssueSeverity.ERROR, tool.name))
    required = tool.input_schema.get("required", [])
    properties = tool.input_schema.get("properties", {})
    if (
        isinstance(required, list)
        and isinstance(properties, dict)
        and any(name not in properties for name in required)
    ):
        issues.append(
            _issue(
                "mcp_required_property_undefined",
                McpIssueSeverity.ERROR,
                tool.name,
            )
        )
    if tool.input_schema.get("additionalProperties") is not False:
        issues.append(
            _issue(
                "mcp_input_schema_allows_additional_properties",
                McpIssueSeverity.WARNING,
                tool.name,
            )
        )
    if _contains_external_schema_reference(tool.input_schema) or (
        tool.output_schema is not None and _contains_external_schema_reference(tool.output_schema)
    ):
        issues.append(
            _issue(
                "mcp_external_schema_reference_forbidden",
                McpIssueSeverity.ERROR,
                tool.name,
            )
        )
    if tool.output_schema is not None:
        try:
            Draft202012Validator.check_schema(tool.output_schema)
        except SchemaError:
            issues.append(_issue("mcp_output_schema_invalid", McpIssueSeverity.ERROR, tool.name))
            return issues
    if not tool.description:
        issues.append(_issue("mcp_description_missing", McpIssueSeverity.WARNING, tool.name))
    if tool.annotations is not None:
        issues.append(_issue("mcp_annotations_untrusted", McpIssueSeverity.WARNING, tool.name))
    if _contains_schema_annotations(tool.input_schema) or (
        tool.output_schema is not None and _contains_schema_annotations(tool.output_schema)
    ):
        issues.append(
            _issue(
                "mcp_schema_annotations_stripped",
                McpIssueSeverity.WARNING,
                tool.name,
            )
        )
    return issues


def _issue(
    code: str,
    severity: McpIssueSeverity,
    tool_name: str | None,
) -> McpIntakeIssue:
    return McpIntakeIssue(code=code, severity=severity, tool_name=tool_name)


def _disposition(
    review: McpToolReview | None,
    blocking_issue: bool,
) -> McpIntakeDisposition:
    if blocking_issue:
        return McpIntakeDisposition.REJECTED
    if review is None:
        return McpIntakeDisposition.PENDING
    if review.decision is McpReviewDecision.REJECT:
        return McpIntakeDisposition.REJECTED
    return McpIntakeDisposition.APPROVED


def _catalog_entries(
    snapshot: McpDiscoverySnapshot,
    tool: McpToolSnapshot,
    tool_id: str,
    action_id: str,
    disposition: McpIntakeDisposition,
    review: McpToolReview | None,
) -> tuple[ToolCard, ActionCard]:
    approved = disposition is McpIntakeDisposition.APPROVED and review is not None
    intent = review.intent if approved else f"Unreviewed MCP capability {tool.name}"
    operation_kind = review.operation_kind if approved else OperationKind.UNKNOWN
    risk_level = review.risk_level if approved else RiskLevel.HIGH
    confirmation_policy = review.confirmation_policy if approved else ConfirmationPolicy.ALWAYS
    status = (
        ToolStatus.APPROVED
        if approved
        else (
            ToolStatus.DISABLED
            if disposition is McpIntakeDisposition.REJECTED
            else ToolStatus.PENDING
        )
    )
    input_schema = _routing_safe_schema(tool.input_schema)
    output_schema = (
        _routing_safe_schema(tool.output_schema) if tool.output_schema is not None else None
    )
    required_slots = tuple(input_schema.get("required", ()))
    card = ToolCard(
        tool_id=tool_id,
        version=snapshot.server_version,
        name=tool.name,
        description=intent,
        input_schema=input_schema,
        output_schema=output_schema,
        source=snapshot.source,
        owner="external_mcp_unreviewed",
        publisher=snapshot.server_id,
        platform="mcp",
        transport=snapshot.transport.value,
        required_permissions=(review.required_permissions if approved else frozenset()),
        risk_level=risk_level,
        confirmation_policy=confirmation_policy,
        allowed_tenants=review.allowed_tenants if approved else frozenset(),
        allowed_roles=review.allowed_roles if approved else frozenset(),
        signature_status="unknown",
        health_status="unverified",
        status=status,
    )
    action = ActionCard(
        action_id=action_id,
        tool_id=tool_id,
        intent=intent,
        operation_kind=operation_kind,
        required_slots=required_slots,
        positive_examples=review.positive_examples if approved else (),
        tags=(review.tags if approved else frozenset({"mcp", snapshot.server_id, tool.name})),
        failure_policy="brain_handoff",
        source_ref=f"mcp_snapshot:{snapshot.snapshot_id}:{tool.name}",
    )
    return card, action


_SCHEMA_ANNOTATION_KEYS = frozenset(
    {
        "$comment",
        "default",
        "deprecated",
        "description",
        "examples",
        "readOnly",
        "title",
        "writeOnly",
    }
)


_SCHEMA_MAPS = frozenset({"properties", "patternProperties", "$defs", "definitions",
                          "dependentSchemas"})
_SCHEMA_ARRAYS = frozenset({"allOf", "anyOf", "oneOf", "prefixItems"})
_SCHEMA_SINGLES = frozenset({"items", "contains", "additionalProperties",
                             "unevaluatedProperties", "unevaluatedItems",
                             "propertyNames", "not", "if", "then", "else", "contentSchema"})


def _routing_safe_schema(value: Any) -> Any:
    if not isinstance(value, dict):
        return deepcopy(value)
    result = {}
    for key, item in value.items():
        if key in _SCHEMA_ANNOTATION_KEYS:
            continue
        if key in _SCHEMA_MAPS:
            result[key] = {name: _routing_safe_schema(schema) for name, schema in item.items()}
        elif key in _SCHEMA_ARRAYS:
            result[key] = [_routing_safe_schema(schema) for schema in item]
        elif key in _SCHEMA_SINGLES:
            result[key] = _routing_safe_schema(item)
        else:
            # Required names, enum/const payloads and extension data are not schema nodes.
            result[key] = deepcopy(item)
    return result


def _contains_schema_annotations(value: Any) -> bool:
    return _routing_safe_schema(value) != value


def _contains_external_schema_reference(value: Any) -> bool:
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"$ref", "$dynamicRef"} and (
                not isinstance(item, str) or not item.startswith("#")
            ):
                return True
            if _contains_external_schema_reference(item):
                return True
    if isinstance(value, list):
        return any(_contains_external_schema_reference(item) for item in value)
    return False


def _tool_id(server_id: str, tool_name: str) -> str:
    raw = f"mcp.{server_id}.{tool_name}"
    max_length = 121
    if len(raw) <= max_length:
        return raw
    suffix = hashlib.sha256(raw.encode()).hexdigest()[:12]
    return f"{raw[: max_length - len(suffix) - 1]}.{suffix}"


def _catalog_id(snapshot_id: str) -> str:
    raw = f"mcp-quarantine.{snapshot_id}"
    if len(raw) <= 128:
        return raw
    suffix = hashlib.sha256(raw.encode()).hexdigest()[:12]
    return f"{raw[:115]}.{suffix}"


def _unique_issues(issues: Iterable[McpIntakeIssue]) -> list[McpIntakeIssue]:
    unique: dict[tuple[str, str, str | None], McpIntakeIssue] = {}
    for issue in issues:
        key = (issue.code, issue.severity.value, issue.tool_name)
        unique[key] = issue
    return [
        unique[key]
        for key in sorted(
            unique,
            key=lambda item: (item[2] or "", item[0], item[1]),
        )
    ]


def _write_json(
    payload: dict[str, Any],
    output: str | None,
    error_code: str,
) -> None:
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(serialized)
        return
    try:
        Path(output).write_text(serialized, encoding="utf-8")
    except OSError:
        _write_error(error_code)
        raise SystemExit(2) from None


def _write_error(code: str) -> None:
    sys.stderr.write(
        json.dumps(
            {"status": "fail", "error_code": code},
            ensure_ascii=False,
            separators=(",", ":"),
        )
        + "\n"
    )


if __name__ == "__main__":
    run_cli()
