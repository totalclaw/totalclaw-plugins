from __future__ import annotations

import math
import unicodedata
from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated, Any, Literal
from uuid import uuid4

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, model_validator


def _canonical_locale(value: str) -> str:
    language, *subtags = value.split("-")
    return "-".join([language.lower(), *(
        part.title() if len(part) == 4 else part.upper() for part in subtags
    )])


RequestIdentifier = Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")]
LocaleTag = Annotated[
    str,
    Field(pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z]{4})?(?:-(?:[A-Za-z]{2}|[0-9]{3}))?$"),
    AfterValidator(_canonical_locale),
]

ReasonCode = Annotated[str, Field(pattern=r"^[a-z0-9_]{1,128}$")]
CapabilityId = Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")]
DomainKeyword = Annotated[str, Field(min_length=1, max_length=128)]
IdentityLabel = Annotated[str, Field(min_length=1, max_length=128)]
ToolMemoryName = Annotated[str, Field(min_length=1, max_length=128)]
RoleProfileId = Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")]
ToolsetId = Annotated[str, Field(pattern=r"^[a-z0-9_.-]{1,128}$")]
UserTurnText = Annotated[str, Field(min_length=1, max_length=32_768)]
VaultArgumentName = Annotated[
    str,
    Field(pattern=r"^[A-Za-z_][A-Za-z0-9_.-]{0,127}$"),
]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DataClassification(StrEnum):
    L0 = "L0"
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"


class RiskLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class RouteType(StrEnum):
    TOOL_DIRECT = "tool_direct"
    SLM_ANSWER = "slm_answer"
    BRAIN_HANDOFF = "brain_handoff"
    CLARIFY = "clarify"
    CONFIRM = "confirm"
    BLOCK = "block"


class IntentType(StrEnum):
    TOOL = "tool"
    QA = "qa"
    REASONING = "reasoning"
    CHAT = "chat"
    SENSITIVE = "sensitive"
    UNKNOWN = "unknown"


class ToolStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    DISABLED = "disabled"


class CatalogEvidenceStatus(StrEnum):
    FIXTURE = "fixture"
    VALIDATED = "validated"


class RouterProfileEvidenceStatus(StrEnum):
    FIXTURE = "fixture"
    VALIDATED = "validated"


class RegistryEvalCategory(StrEnum):
    POSITIVE = "positive"
    DISAMBIGUATION = "disambiguation"
    NO_MATCH = "no_match"
    AUTHORIZATION = "authorization"
    WRITE_OR_REDACTED = "write_or_redacted"


class RegistryEvalStatus(StrEnum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    NOT_EVALUATED = "not_evaluated"


class ConfirmationPolicy(StrEnum):
    NEVER = "never"
    ALWAYS = "always"
    RISK_BASED = "risk_based"


class RedactionAction(StrEnum):
    ALLOW = "allow"
    REDACT = "redact"
    BLOCK = "block"


class OperationKind(StrEnum):
    READ = "read"
    WRITE = "write"
    UNKNOWN = "unknown"


class McpTransportKind(StrEnum):
    STDIO = "stdio"
    STREAMABLE_HTTP = "streamable_http"
    SSE = "sse"


class McpIntakeDisposition(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class McpIntakeStatus(StrEnum):
    QUARANTINED = "quarantined"
    REVIEWED_FIXTURE = "reviewed_fixture"
    REJECTED = "rejected"


class McpIssueSeverity(StrEnum):
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class McpReviewDecision(StrEnum):
    APPROVE = "approve"
    REJECT = "reject"


class Router0Status(StrEnum):
    UNRESOLVED = "unresolved"
    CONFIRM = "confirm"
    BLOCK = "block"


class SafetyAction(StrEnum):
    ALLOW = "allow"
    CLARIFY = "clarify"
    CONFIRM = "confirm"
    BLOCK = "block"
    HANDOFF = "handoff"


class PlanningLevel(StrEnum):
    BYPASS = "bypass"
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"


class ComputeBudgetLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    EXTREME = "extreme"


class ApprovalRequirement(StrEnum):
    """Read-only host approval hint; never an execution authorization."""

    NONE = "none"
    MEDIUM = "medium"
    HIGH = "high"
    EXTREME = "extreme"
    UNKNOWN = "unknown"


class CerebellumRequest(StrictModel):
    text: str = Field(min_length=1, max_length=32_768)
    request_id: RequestIdentifier = Field(default_factory=lambda: uuid4().hex)
    session_id: RequestIdentifier | None = None
    locale: LocaleTag = "zh-CN"
    data_classification: DataClassification = DataClassification.L0
    is_write_intent: bool = False


class SafeRoutingRequest(StrictModel):
    """The only request shape allowed past the redaction boundary."""

    request_id: RequestIdentifier
    session_id: RequestIdentifier | None = None
    locale: LocaleTag
    redacted_text: str = Field(min_length=1, max_length=32_768)
    data_classification: DataClassification
    redaction_action: RedactionAction
    is_write_intent: bool = False

    @model_validator(mode="after")
    def require_safe_routing_data(self) -> SafeRoutingRequest:
        if self.data_classification is DataClassification.L4:
            raise ValueError("L4 data cannot cross the redaction boundary")
        if self.redaction_action is RedactionAction.BLOCK:
            raise ValueError("blocked data cannot become a safe routing request")
        return self


class IdentityHints(StrictModel):
    """Untrusted identity values received at a transport boundary."""

    tenant_id: str = Field(min_length=1)
    user_id: str = Field(min_length=1)
    granted_scopes: frozenset[str] = Field(default_factory=frozenset)


class IdentityContext(StrictModel):
    """Identity claims resolved by a trusted adapter, never directly from request fields."""

    tenant_id: str = Field(min_length=1)
    user_id: str = Field(min_length=1)
    granted_scopes: frozenset[str] = Field(default_factory=frozenset)
    roles: frozenset[str] = Field(default_factory=frozenset)
    identity_labels: frozenset[IdentityLabel] = Field(
        default_factory=frozenset,
        max_length=64,
    )
    authenticated: bool = False
    source: str = Field(min_length=1)

    @model_validator(mode="after")
    def reject_privileges_for_unverified_identity(self) -> IdentityContext:
        if not self.authenticated and (
            self.granted_scopes or self.roles or self.identity_labels
        ):
            raise ValueError(
                "unverified identities cannot carry scopes, roles, or identity labels"
            )
        if any(not label.strip() for label in self.identity_labels):
            raise ValueError("identity labels cannot be blank")
        return self


class RequestContext(StrictModel):
    identity: IdentityContext
    channel: str = Field(min_length=1)
    memory_write_allowed: bool = False

    @model_validator(mode="after")
    def require_authenticated_memory_permission(self) -> RequestContext:
        if self.memory_write_allowed and not self.identity.authenticated:
            raise ValueError("memory permission requires an authenticated identity")
        return self


class LtmContextEntry(StrictModel):
    """Host-provided relevant history before the redaction boundary."""

    text: str = Field(min_length=1, max_length=32_768)
    domains: tuple[DomainKeyword, ...] = Field(default=(), max_length=64)
    tools: tuple[ToolMemoryName, ...] = Field(default=(), max_length=256)
    success: bool
    score: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    ts: float = Field(allow_inf_nan=False)


class UserTurnHistory(StrictModel):
    """Complete prior user turns supplied separately from relevant LTM."""

    schema_version: Literal["1"]
    turns: tuple[UserTurnText, ...] = Field(default=(), max_length=64)

    @model_validator(mode="after")
    def enforce_aggregate_size(self) -> UserTurnHistory:
        if sum(len(turn) for turn in self.turns) > 131_072:
            raise ValueError("user turn history exceeds aggregate text limit")
        return self


class SafeLtmContextEntry(StrictModel):
    """Redacted history allowed to influence only the planning channel."""

    redacted_text: str = Field(min_length=1, max_length=32_768)
    domains: tuple[DomainKeyword, ...] = Field(default=(), max_length=64)
    tools: tuple[ToolMemoryName, ...] = Field(default=(), max_length=256)
    success: bool
    score: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    ts: float = Field(allow_inf_nan=False)
    data_classification: DataClassification

    @model_validator(mode="after")
    def reject_l4_history(self) -> SafeLtmContextEntry:
        if self.data_classification is DataClassification.L4:
            raise ValueError("L4 history cannot enter tool planning")
        return self


class LtmDecisionLog(StrictModel):
    user_message: str = Field(min_length=1, max_length=32_768)
    domains: tuple[DomainKeyword, ...] = Field(default=(), max_length=64)
    tools: tuple[CapabilityId, ...] = Field(default=(), max_length=4096)
    level: PlanningLevel
    narrowed: bool
    degraded: bool
    budget: str = Field(min_length=1, max_length=32)
    ts: float = Field(allow_inf_nan=False)


class PortTimeouts(StrictModel):
    identity_seconds: float = Field(default=2.0, gt=0)
    redactor_seconds: float = Field(default=2.0, gt=0)
    router0_seconds: float = Field(default=2.0, gt=0)
    registry_seconds: float = Field(default=5.0, gt=0)
    retriever_seconds: float = Field(default=5.0, gt=0)
    skill_identity_filter_seconds: float = Field(default=2.0, gt=0)
    affinity_learning_seconds: float = Field(default=0.05, gt=0)
    approval_introspection_seconds: float = Field(default=0.05, gt=0)
    vault_reference_seconds: float = Field(default=1.0, gt=0)
    ltm_context_seconds: float = Field(default=0.05, gt=0)
    user_history_seconds: float = Field(default=2.0, gt=0)
    classifier_seconds: float = Field(default=1.0, gt=0)
    router1_seconds: float = Field(default=4.0, gt=0)
    policy_seconds: float = Field(default=2.0, gt=0)
    output_guard_seconds: float = Field(default=2.0, gt=0)
    brain_seconds: float = Field(default=30.0, gt=0)
    memory_seconds: float = Field(default=2.0, gt=0)
    audit_seconds: float = Field(default=2.0, gt=0)


class AffinitySnapshotHandle(StrictModel):
    """Opaque host-owned reference to a replayable affinity-learning snapshot."""

    schema_version: Literal["1"] = "1"
    snapshot_id: CapabilityId
    state_version: CapabilityId
    state_digest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class RouteDecision(StrictModel):
    intent_type: IntentType = IntentType.UNKNOWN
    route_decision: RouteType
    confidence: float = Field(ge=0.0, le=1.0)
    selected_tool: str | None = None
    selected_action: str | None = None
    tool_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    is_write_op: bool = False
    risk_level: RiskLevel = RiskLevel.LOW
    data_classification: DataClassification = DataClassification.L0
    slots: dict[str, Any] = Field(default_factory=dict)
    missing_required: tuple[str, ...] = ()
    handoff_reason: str | None = None
    policy_reasons: tuple[str, ...] = ()
    trace_id: str = Field(default_factory=lambda: uuid4().hex)

    @model_validator(mode="after")
    def enforce_fail_closed_invariants(self) -> RouteDecision:
        if self.is_write_op and self.route_decision is RouteType.TOOL_DIRECT:
            raise ValueError("write operations cannot use tool_direct")
        if (
            self.data_classification is DataClassification.L4
            and self.route_decision is not RouteType.BLOCK
        ):
            raise ValueError("L4 data must be blocked")
        if self.route_decision is RouteType.TOOL_DIRECT and (
            not self.selected_tool or not self.selected_action
        ):
            raise ValueError("tool_direct requires selected_tool and selected_action")
        return self


class ToolCard(StrictModel):
    tool_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    version: str = Field(min_length=1)
    name: str = Field(min_length=1)
    description: str = Field(min_length=1)
    input_schema: dict[str, Any]
    output_schema: dict[str, Any] | None = None
    source: str
    owner: str
    publisher: str | None = None
    platform: str
    transport: str
    required_permissions: frozenset[str] = Field(default_factory=frozenset)
    risk_level: RiskLevel = RiskLevel.LOW
    confirmation_policy: ConfirmationPolicy = ConfirmationPolicy.RISK_BASED
    data_classification: DataClassification = DataClassification.L0
    allowed_tenants: frozenset[str] = Field(default_factory=frozenset)
    allowed_roles: frozenset[str] = Field(default_factory=frozenset)
    endpoint_allowlist: tuple[str, ...] = ()
    package_hash: str | None = None
    signature_status: str = "unknown"
    timeout_ms: int = Field(default=30_000, gt=0)
    max_calls_per_turn: int = Field(default=1, gt=0)
    health_status: str = "unknown"
    last_verified_at: datetime | None = None
    status: ToolStatus = ToolStatus.PENDING


class ActionCard(StrictModel):
    action_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    tool_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    intent: str = Field(min_length=1)
    operation_kind: OperationKind
    required_slots: tuple[str, ...] = ()
    preconditions: tuple[str, ...] = ()
    positive_examples: tuple[str, ...] = ()
    near_negative_examples: tuple[str, ...] = ()
    forbidden_examples: tuple[str, ...] = ()
    tags: frozenset[str] = Field(default_factory=frozenset)
    relevant_identity_labels: frozenset[IdentityLabel] = Field(
        default_factory=frozenset,
        max_length=64,
    )
    failure_policy: str = "brain_handoff"
    source_ref: str | None = None

    @model_validator(mode="after")
    def reject_blank_identity_labels(self) -> ActionCard:
        if any(not label.strip() for label in self.relevant_identity_labels):
            raise ValueError("relevant identity labels cannot be blank")
        return self


class CapabilityCatalog(StrictModel):
    schema_version: str = Field(pattern=r"^1$")
    catalog_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    evidence_status: CatalogEvidenceStatus
    tools: tuple[ToolCard, ...]
    actions: tuple[ActionCard, ...]

    @model_validator(mode="after")
    def enforce_catalog_integrity(self) -> CapabilityCatalog:
        tool_ids = tuple(tool.tool_id for tool in self.tools)
        action_ids = tuple(action.action_id for action in self.actions)
        if len(tool_ids) != len(set(tool_ids)):
            raise ValueError("catalog contains duplicate tool_id")
        if len(action_ids) != len(set(action_ids)):
            raise ValueError("catalog contains duplicate action_id")
        known_tools = set(tool_ids)
        if any(action.tool_id not in known_tools for action in self.actions):
            raise ValueError("catalog action references an unknown tool_id")
        return self


class McpToolAnnotations(StrictModel):
    """Untrusted MCP hints retained for review, never used as policy facts."""

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    title: str | None = Field(default=None, min_length=1, max_length=256)
    read_only_hint: bool | None = Field(default=None, alias="readOnlyHint")
    destructive_hint: bool | None = Field(default=None, alias="destructiveHint")
    idempotent_hint: bool | None = Field(default=None, alias="idempotentHint")
    open_world_hint: bool | None = Field(default=None, alias="openWorldHint")


class McpToolSnapshot(StrictModel):
    """Normalized, strict subset of one MCP tools/list entry."""

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    name: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    title: str | None = Field(default=None, min_length=1, max_length=256)
    description: str | None = Field(default=None, max_length=8_192)
    input_schema: dict[str, Any] = Field(alias="inputSchema")
    output_schema: dict[str, Any] | None = Field(default=None, alias="outputSchema")
    annotations: McpToolAnnotations | None = None


class McpDiscoverySnapshot(StrictModel):
    """Offline MCP discovery artifact. It never contains credentials or tool results."""

    schema_version: Literal["1"]
    snapshot_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    server_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    server_version: str = Field(min_length=1, max_length=128)
    transport: McpTransportKind
    source: str = Field(min_length=1, max_length=512)
    captured_at: datetime
    tools: tuple[McpToolSnapshot, ...]

    @model_validator(mode="after")
    def require_unique_tools(self) -> McpDiscoverySnapshot:
        names = tuple(tool.name for tool in self.tools)
        if not names:
            raise ValueError("MCP snapshot must contain at least one tool")
        if len(names) != len(set(names)):
            raise ValueError("MCP snapshot contains duplicate tool names")
        return self


class McpIntakeIssue(StrictModel):
    code: str = Field(pattern=r"^[a-z0-9_]{1,128}$")
    severity: McpIssueSeverity
    tool_name: str | None = Field(
        default=None,
        pattern=r"^[A-Za-z0-9_.-]{1,128}$",
    )


class McpValidationCase(StrictModel):
    case_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    tool_name: str | None = Field(
        default=None,
        pattern=r"^[A-Za-z0-9_.-]{1,128}$",
    )
    expected_outcome: str = Field(min_length=1, max_length=128)
    observed_outcome: str = Field(min_length=1, max_length=128)
    passed: bool
    reason_code: str = Field(pattern=r"^[a-z0-9_]{1,128}$")


class McpValidationEvidence(StrictModel):
    schema_version: Literal["1"]
    evidence_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    snapshot_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    snapshot_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    evidence_status: CatalogEvidenceStatus
    client_kind: str = Field(min_length=1, max_length=128)
    sample_count: int = Field(ge=1)
    cases: tuple[McpValidationCase, ...]
    findings: tuple[McpIntakeIssue, ...] = ()

    @model_validator(mode="after")
    def require_consistent_cases(self) -> McpValidationEvidence:
        case_ids = tuple(case.case_id for case in self.cases)
        if len(case_ids) != self.sample_count:
            raise ValueError("MCP evidence sample_count does not match cases")
        if len(case_ids) != len(set(case_ids)):
            raise ValueError("MCP evidence contains duplicate case IDs")
        return self


class McpToolReview(StrictModel):
    tool_name: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    decision: McpReviewDecision
    operation_kind: OperationKind = OperationKind.UNKNOWN
    risk_level: RiskLevel = RiskLevel.HIGH
    confirmation_policy: ConfirmationPolicy = ConfirmationPolicy.ALWAYS
    intent: str | None = Field(default=None, min_length=1, max_length=1_024)
    positive_examples: tuple[str, ...] = ()
    tags: frozenset[str] = Field(default_factory=frozenset)
    required_permissions: frozenset[str] = Field(default_factory=frozenset)
    allowed_tenants: frozenset[str] = Field(default_factory=frozenset)
    allowed_roles: frozenset[str] = Field(default_factory=frozenset)
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def require_safe_explicit_review(self) -> McpToolReview:
        if self.decision is McpReviewDecision.APPROVE:
            if self.operation_kind is OperationKind.UNKNOWN:
                raise ValueError("approved MCP tools require explicit operation_kind")
            if (
                self.operation_kind is OperationKind.WRITE
                and self.confirmation_policy is not ConfirmationPolicy.ALWAYS
            ):
                raise ValueError("MCP write tools require always confirmation")
            if not self.intent:
                raise ValueError("approved MCP tools require reviewed intent")
        if self.decision is McpReviewDecision.REJECT and not self.reason_codes:
            raise ValueError("rejected MCP tools require at least one reason code")
        return self


class McpReviewManifest(StrictModel):
    schema_version: Literal["1"]
    review_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    snapshot_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    snapshot_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    reviewer: str = Field(min_length=1, max_length=256)
    reviewed_at: datetime
    evidence_status: CatalogEvidenceStatus = CatalogEvidenceStatus.FIXTURE
    tools: tuple[McpToolReview, ...]

    @model_validator(mode="after")
    def require_safe_review_scope(self) -> McpReviewManifest:
        if self.evidence_status is not CatalogEvidenceStatus.FIXTURE:
            raise ValueError("MCP intake cannot mint validated catalogs")
        names = tuple(review.tool_name for review in self.tools)
        if len(names) != len(set(names)):
            raise ValueError("MCP review contains duplicate tool names")
        return self


class McpIntakeItem(StrictModel):
    external_tool_name: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    tool_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    action_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    disposition: McpIntakeDisposition
    operation_kind: OperationKind
    issue_codes: tuple[str, ...] = ()


class McpIntakeReport(StrictModel):
    schema_version: Literal["1"]
    snapshot_id: str
    server_id: str
    server_version: str
    snapshot_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    evidence_status: CatalogEvidenceStatus
    status: McpIntakeStatus
    source_tool_count: int = Field(ge=1)
    catalog_tool_count: int = Field(ge=0)
    pending_tool_count: int = Field(ge=0)
    approved_tool_count: int = Field(ge=0)
    rejected_tool_count: int = Field(ge=0)
    items: tuple[McpIntakeItem, ...]
    issues: tuple[McpIntakeIssue, ...] = ()
    catalog: CapabilityCatalog
    notes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def require_consistent_counts(self) -> McpIntakeReport:
        dispositions = tuple(item.disposition for item in self.items)
        if len(self.items) != self.source_tool_count:
            raise ValueError("MCP intake item count mismatch")
        if dispositions.count(McpIntakeDisposition.PENDING) != self.pending_tool_count:
            raise ValueError("MCP intake pending count mismatch")
        if dispositions.count(McpIntakeDisposition.APPROVED) != self.approved_tool_count:
            raise ValueError("MCP intake approved count mismatch")
        if dispositions.count(McpIntakeDisposition.REJECTED) != self.rejected_tool_count:
            raise ValueError("MCP intake rejected count mismatch")
        if len(self.catalog.tools) != self.catalog_tool_count:
            raise ValueError("MCP intake catalog count mismatch")
        return self


class RouterProfile(StrictModel):
    """Versioned evidence and acceptance thresholds for actionable Router-1 output."""

    schema_version: str = Field(pattern=r"^1$")
    profile_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    model_id: str = Field(min_length=1, max_length=256)
    prompt_version: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    catalog_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    dataset_version: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    evidence_status: RouterProfileEvidenceStatus
    evaluation_report_sha256: str | None = Field(
        default=None,
        pattern=r"^[a-f0-9]{64}$",
    )
    tool_direct_enabled: bool
    slm_answer_enabled: bool
    tool_direct_min_confidence: float = Field(gt=0.0, le=1.0)
    tool_direct_min_retrieval_margin: float = Field(ge=0.0, le=1.0)
    slm_answer_min_confidence: float = Field(gt=0.0, le=1.0)

    @model_validator(mode="after")
    def require_report_for_validated_profile(self) -> RouterProfile:
        if (
            self.evidence_status is RouterProfileEvidenceStatus.VALIDATED
            and self.evaluation_report_sha256 is None
        ):
            raise ValueError("validated RouterProfile requires an evaluation report hash")
        return self


class CapabilityReference(StrictModel):
    tool_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    action_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")


class SkillIdentityVisibility(StrictModel):
    """Soft display-only result; it never changes capability authorization."""

    hidden_capabilities: tuple[CapabilityReference, ...] = ()
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def reject_duplicate_hidden_capabilities(self) -> SkillIdentityVisibility:
        references = tuple(
            (item.tool_id, item.action_id) for item in self.hidden_capabilities
        )
        if len(references) != len(set(references)):
            raise ValueError("identity visibility cannot contain duplicate capabilities")
        return self


class RegistryEvalCase(StrictModel):
    case_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    category: RegistryEvalCategory
    query: str = Field(min_length=1, max_length=32_768)
    identity: IdentityContext
    expected_top1: CapabilityReference | None = None
    expected_top5: tuple[CapabilityReference, ...] = ()
    forbidden_candidates: tuple[CapabilityReference, ...] = ()

    @model_validator(mode="after")
    def require_expected_shape(self) -> RegistryEvalCase:
        if self.category is RegistryEvalCategory.NO_MATCH:
            if self.expected_top1 is not None or self.expected_top5:
                raise ValueError("no_match cases cannot declare expected candidates")
        elif self.category is RegistryEvalCategory.AUTHORIZATION:
            return self
        elif self.expected_top1 is None:
            raise ValueError("non-no_match cases require expected_top1")
        return self


class RegistryEvalDataset(StrictModel):
    dataset_version: str = Field(min_length=1)
    evidence_status: CatalogEvidenceStatus
    cases: tuple[RegistryEvalCase, ...]

    @model_validator(mode="after")
    def require_unique_cases(self) -> RegistryEvalDataset:
        case_ids = tuple(case.case_id for case in self.cases)
        if len(case_ids) != len(set(case_ids)):
            raise ValueError("dataset contains duplicate case_id")
        if not case_ids:
            raise ValueError("dataset must contain at least one case")
        return self


class RegistryEvalReport(StrictModel):
    dataset_version: str
    catalog_id: str
    catalog_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    evidence_status: CatalogEvidenceStatus
    sample_count: int = Field(ge=1)
    top1_evaluated: int = Field(ge=0)
    top5_evaluated: int = Field(ge=0)
    no_match_evaluated: int = Field(ge=0)
    top1_accuracy: float | None = Field(default=None, ge=0.0, le=1.0)
    top5_recall: float | None = Field(default=None, ge=0.0, le=1.0)
    no_match_accuracy: float | None = Field(default=None, ge=0.0, le=1.0)
    unauthorized_exposure_count: int = Field(ge=0)
    failed_case_ids: tuple[str, ...] = ()
    latency_p50_ms: float = Field(ge=0.0)
    latency_p95_ms: float = Field(ge=0.0)
    status: RegistryEvalStatus
    notes: tuple[str, ...] = ()


class RouterEvaluationRandomness(StrictModel):
    temperature: float = Field(ge=0.0, le=2.0)
    seed: int | None = None


class RouterEvaluationMetrics(StrictModel):
    registry_top5_recall: float = Field(ge=0.0, le=1.0)
    router_top1_tool_accuracy: float = Field(ge=0.0, le=1.0)
    json_schema_valid_rate: float = Field(ge=0.0, le=1.0)
    required_slots_complete_rate: float = Field(ge=0.0, le=1.0)
    tool_hallucination_rate: float = Field(ge=0.0, le=1.0)
    write_operation_direct_count: int = Field(ge=0)
    unauthorized_candidate_exposure_count: int = Field(ge=0)
    l4_raw_leak_count: int = Field(ge=0)
    redaction_quality_drop_pp: float = Field(ge=0.0, le=100.0)


class RouterEvaluationReport(StrictModel):
    """Strict evidence document required before actionable Router routes unlock."""

    schema_version: str = Field(pattern=r"^1$")
    report_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    evidence_status: RouterProfileEvidenceStatus
    status: RegistryEvalStatus
    model_id: str = Field(min_length=1, max_length=256)
    quantization: str = Field(min_length=1, max_length=128)
    runtime: str = Field(min_length=1, max_length=256)
    prompt_version: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    dataset_version: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    catalog_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    hardware: str = Field(min_length=1, max_length=512)
    randomness: RouterEvaluationRandomness
    action_count: int = Field(ge=1)
    sample_count: int = Field(ge=1)
    error_review_completed: bool
    failed_case_ids: tuple[str, ...] = ()
    metrics: RouterEvaluationMetrics
    notes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def require_consistent_cases(self) -> RouterEvaluationReport:
        if len(self.failed_case_ids) != len(set(self.failed_case_ids)):
            raise ValueError("router evaluation report contains duplicate failed case IDs")
        if len(self.failed_case_ids) > self.sample_count:
            raise ValueError("failed case count exceeds sample count")
        return self


class CapabilityCandidate(StrictModel):
    tool: ToolCard
    action: ActionCard
    retrieval_score: float = Field(default=0.0, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def require_approved_matching_tool(self) -> CapabilityCandidate:
        if self.tool.status is not ToolStatus.APPROVED:
            raise ValueError("capability candidates require an approved ToolCard")
        if self.action.tool_id != self.tool.tool_id:
            raise ValueError("ActionCard tool_id must match ToolCard tool_id")
        return self


class DomainKeywordRule(StrictModel):
    domain: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    keywords: tuple[DomainKeyword, ...] = Field(min_length=1, max_length=64)
    tool_prefixes: tuple[CapabilityId, ...] = Field(min_length=1, max_length=64)

    @model_validator(mode="after")
    def require_unique_nonempty_values(self) -> DomainKeywordRule:
        normalized_keywords = tuple(
            unicodedata.normalize("NFKC", keyword).strip().casefold()
            for keyword in self.keywords
        )
        if any(not keyword for keyword in normalized_keywords):
            raise ValueError("domain keywords cannot be empty")
        if len(normalized_keywords) != len(set(normalized_keywords)):
            raise ValueError("domain keywords must be unique after normalization")
        normalized_prefixes = tuple(
            unicodedata.normalize("NFKC", prefix).strip().casefold()
            for prefix in self.tool_prefixes
        )
        if len(normalized_prefixes) != len(set(normalized_prefixes)):
            raise ValueError("domain tool prefixes must be unique after normalization")
        return self


class ToolPlanningConfig(StrictModel):
    """Trusted host configuration for deterministic tool narrowing."""

    enabled: bool = True
    minimum_tool_count: int = Field(default=6, ge=1)
    minimum_retention_ratio: float = Field(default=0.30, gt=0.0, le=1.0)
    l1_confidence_threshold: float = Field(default=0.50, gt=0.0, le=1.0)
    fallback_top_k: int = Field(default=14, ge=1)
    domain_rules: tuple[DomainKeywordRule, ...] = Field(
        default=(
            DomainKeywordRule(
                domain="project",
                keywords=("项目", "project"),
                tool_prefixes=("project_",),
            ),
            DomainKeywordRule(
                domain="file",
                keywords=("文件", "目录", "file", "folder", "directory"),
                tool_prefixes=("file_", "read_file", "write_file", "list_"),
            ),
            DomainKeywordRule(
                domain="calendar",
                keywords=("日历", "会议", "calendar", "event", "meeting"),
                tool_prefixes=("calendar_",),
            ),
            DomainKeywordRule(
                domain="email",
                keywords=("邮件", "email", "mail"),
                tool_prefixes=("email_", "mail_"),
            ),
            DomainKeywordRule(
                domain="task",
                keywords=("任务", "待办", "task", "todo"),
                tool_prefixes=("task_", "todo"),
            ),
            DomainKeywordRule(
                domain="message",
                keywords=("消息", "message"),
                tool_prefixes=("message_", "send_message"),
            ),
        ),
        max_length=64,
    )
    always_include_tool_ids: tuple[CapabilityId, ...] = Field(
        default=(),
        max_length=256,
    )
    discovery_tool_ids: tuple[CapabilityId, ...] = Field(
        default=(),
        max_length=256,
    )
    fallback_core_tool_ids: tuple[CapabilityId, ...] = Field(
        default=(),
        max_length=256,
    )
    fallback_ranked_tool_ids: tuple[CapabilityId, ...] = Field(
        default=(),
        max_length=1_024,
    )
    wechat_gate_enabled: bool = False
    wechat_trigger_keywords: tuple[DomainKeyword, ...] = Field(
        default=(),
        max_length=64,
    )
    wechat_intent_keywords: tuple[DomainKeyword, ...] = Field(
        default=(),
        max_length=64,
    )
    wechat_exclusion_keywords: tuple[DomainKeyword, ...] = Field(
        default=(),
        max_length=64,
    )
    wechat_gui_blocked_tool_ids: tuple[CapabilityId, ...] = Field(
        default=(),
        max_length=256,
    )
    wechat_required_tool_ids: tuple[CapabilityId, ...] = Field(
        default=(),
        max_length=2,
    )

    @model_validator(mode="after")
    def require_unique_configuration(self) -> ToolPlanningConfig:
        domains = tuple(rule.domain.casefold() for rule in self.domain_rules)
        if len(domains) != len(set(domains)):
            raise ValueError("tool planning domains must be unique")
        for values in (
            self.always_include_tool_ids,
            self.discovery_tool_ids,
            self.fallback_core_tool_ids,
            self.fallback_ranked_tool_ids,
            self.wechat_gui_blocked_tool_ids,
            self.wechat_required_tool_ids,
        ):
            if len(values) != len(set(values)):
                raise ValueError("configured tool IDs must be unique within each list")
        normalized_wechat_keyword_sets: list[set[str]] = []
        for label, keywords in (
            ("trigger", self.wechat_trigger_keywords),
            ("intent", self.wechat_intent_keywords),
            ("exclusion", self.wechat_exclusion_keywords),
        ):
            normalized = tuple(
                unicodedata.normalize("NFKC", keyword).strip().casefold()
                for keyword in keywords
            )
            if any(not keyword for keyword in normalized):
                raise ValueError(f"wechat {label} keywords cannot be empty")
            if len(normalized) != len(set(normalized)):
                raise ValueError(
                    f"wechat {label} keywords must be unique after normalization"
                )
            normalized_wechat_keyword_sets.append(set(normalized))
        trigger_keywords, intent_keywords, exclusion_keywords = (
            normalized_wechat_keyword_sets
        )
        if trigger_keywords.intersection(intent_keywords):
            raise ValueError("wechat trigger and intent keywords cannot overlap")
        if trigger_keywords.intersection(exclusion_keywords) or (
            intent_keywords.intersection(exclusion_keywords)
        ):
            raise ValueError("wechat positive and exclusion keywords cannot overlap")
        if self.wechat_gate_enabled:
            if not self.enabled:
                raise ValueError("wechat gate requires tool planning to be enabled")
            if not self.wechat_trigger_keywords:
                raise ValueError("wechat gate requires trigger keywords")
            if not self.wechat_intent_keywords:
                raise ValueError("wechat gate requires intent keywords")
            if not self.wechat_exclusion_keywords:
                raise ValueError("wechat gate requires exclusion keywords")
            if not self.wechat_gui_blocked_tool_ids:
                raise ValueError("wechat gate requires a GUI tool blacklist")
            if len(self.wechat_required_tool_ids) != 2:
                raise ValueError("wechat gate requires exactly two WeChat tools")
            if set(self.wechat_gui_blocked_tool_ids).intersection(
                self.wechat_required_tool_ids
            ):
                raise ValueError("required WeChat tools cannot be GUI-blocked")
        return self


class ToolPlanningProfile(StrictModel):
    """Versioned, catalog-bound configuration for the F4 fallback policy."""

    schema_version: Literal["1"]
    profile_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    catalog_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    evidence_status: CatalogEvidenceStatus
    config: ToolPlanningConfig

    @model_validator(mode="after")
    def require_complete_validated_f4_profile(self) -> ToolPlanningProfile:
        if self.evidence_status is not CatalogEvidenceStatus.VALIDATED:
            return self
        if set(self.config.model_fields_set) != set(ToolPlanningConfig.model_fields):
            raise ValueError("validated tool planning profiles require every config field")
        if not self.config.enabled:
            raise ValueError("validated tool planning profiles must be enabled")
        if self.config.minimum_tool_count != 6:
            raise ValueError("validated tool planning profiles require the six-tool bypass")
        if self.config.minimum_retention_ratio != 0.30:
            raise ValueError("validated tool planning profiles require 30 percent retention")
        if self.config.l1_confidence_threshold != 0.50:
            raise ValueError("validated tool planning profiles require the L1 threshold")
        if self.config.fallback_top_k != 14:
            raise ValueError("validated tool planning profiles require fallback Top-14")
        if len(self.config.fallback_ranked_tool_ids) != 14:
            raise ValueError("validated tool planning profiles require 14 ranked tool IDs")
        if len(self.config.fallback_core_tool_ids) != 9:
            raise ValueError("validated tool planning profiles require nine core tools")
        if (
            self.config.fallback_ranked_tool_ids[:9]
            != self.config.fallback_core_tool_ids
        ):
            raise ValueError("validated fallback Top-14 must start with the nine core tools")
        if not self.config.discovery_tool_ids:
            raise ValueError("validated tool planning profiles require discovery tools")
        if len(self.config.domain_rules) != 15:
            raise ValueError(
                "validated tool planning profiles require exactly 15 domains"
            )
        return self


class RoleToolsetProfile(StrictModel):
    """Versioned P2 soft-visibility profile derived from trusted host roles."""

    schema_version: Literal["1"]
    profile_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    catalog_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    evidence_status: CatalogEvidenceStatus
    role_toolsets: dict[RoleProfileId, tuple[ToolsetId, ...]] = Field(
        min_length=1,
        max_length=256,
    )
    core_toolsets: tuple[ToolsetId, ...] = Field(default=(), max_length=128)

    @model_validator(mode="after")
    def require_unambiguous_role_toolsets(self) -> RoleToolsetProfile:
        normalized_roles = tuple(role.casefold() for role in self.role_toolsets)
        if len(normalized_roles) != len(set(normalized_roles)):
            raise ValueError("role profile contains case-insensitive duplicate roles")
        for toolsets in self.role_toolsets.values():
            if not toolsets:
                raise ValueError("role profile entries require at least one toolset")
            if len(toolsets) != len(set(toolsets)):
                raise ValueError("role profile contains duplicate toolsets")
        if len(self.core_toolsets) != len(set(self.core_toolsets)):
            raise ValueError("role profile contains duplicate core toolsets")
        return self


class ToolPlanCacheConfig(StrictModel):
    """Bounded in-memory cache for the non-safety tool/budget channel."""

    enabled: bool = True
    ttl_seconds: float = Field(default=60.0, gt=0.0, le=3_600.0)
    max_entries: int = Field(default=512, ge=1, le=10_000)


class ComputeBudget(StrictModel):
    level: ComputeBudgetLevel
    max_rounds: int = Field(ge=1, le=32)
    thinking_effort: Literal["low", "medium", "high"]
    suggest_parallel: bool
    suggest_retrieval: bool
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def require_deterministic_budget_profile(self) -> ComputeBudget:
        expected = {
            ComputeBudgetLevel.LOW: (2, "low", False, False),
            ComputeBudgetLevel.MEDIUM: (4, "medium", False, True),
            ComputeBudgetLevel.HIGH: (8, "high", False, True),
            ComputeBudgetLevel.EXTREME: (12, "high", True, True),
        }[self.level]
        if "high_risk_round_cap" in self.reason_codes:
            if (
                self.max_rounds > 2
                or self.thinking_effort != expected[1]
                or self.suggest_parallel
                or self.suggest_retrieval != expected[3]
            ):
                raise ValueError(
                    "high-risk compute budgets require a conservative round cap"
                )
            return self
        actual = (
            self.max_rounds,
            self.thinking_effort,
            self.suggest_parallel,
            self.suggest_retrieval,
        )
        if actual != expected:
            raise ValueError("compute budget fields do not match their level")
        return self


class ProductSafetyDecision(StrictModel):
    action: SafetyAction
    redacted_text: str | None = Field(default=None, min_length=1, max_length=32_768)
    data_classification: DataClassification
    risk_level: RiskLevel
    is_write_intent: bool
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def require_safe_payload(self) -> ProductSafetyDecision:
        if self.data_classification is DataClassification.L4:
            if self.action is not SafetyAction.BLOCK:
                raise ValueError("L4 product safety decisions must block")
            if self.redacted_text is not None:
                raise ValueError("L4 product safety decisions cannot expose text")
        if self.action is SafetyAction.BLOCK and self.redacted_text is not None:
            raise ValueError("blocked product safety decisions cannot expose text")
        if self.action is not SafetyAction.BLOCK and self.redacted_text is None:
            raise ValueError("non-block product safety decisions require redacted text")
        return self


class ToolBudgetPlan(StrictModel):
    tools: tuple[CapabilityReference, ...]
    display_tools: tuple[CapabilityReference, ...]
    authorized_capability_count: int = Field(ge=0)
    authorized_tool_count: int = Field(ge=0)
    domains: tuple[str, ...] = ()
    level: PlanningLevel
    narrowed: bool
    degraded: bool
    budget: ComputeBudget | None = None
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def require_plan_invariants(self) -> ToolBudgetPlan:
        references = tuple((item.tool_id, item.action_id) for item in self.tools)
        display_references = tuple(
            (item.tool_id, item.action_id) for item in self.display_tools
        )
        if len(references) != len(set(references)):
            raise ValueError("tool plan cannot contain duplicate capabilities")
        if len(display_references) != len(set(display_references)):
            raise ValueError("display tool plan cannot contain duplicate capabilities")
        if not set(display_references).issubset(references):
            raise ValueError("display tools must be a subset of callable tools")
        if len(references) > self.authorized_capability_count:
            raise ValueError("tool plan cannot exceed its authorized input set")
        selected_tool_count = len({item.tool_id for item in self.tools})
        if selected_tool_count > self.authorized_tool_count:
            raise ValueError("tool plan cannot exceed its authorized tool set")
        if self.authorized_tool_count > self.authorized_capability_count:
            raise ValueError("authorized tool count cannot exceed capability count")
        if bool(self.authorized_tool_count) != bool(self.authorized_capability_count):
            raise ValueError("authorized tool and capability emptiness must match")
        if self.authorized_capability_count and not references:
            raise ValueError("a nonempty authorized input set requires a nonempty tool plan")
        if self.narrowed != (len(references) < self.authorized_capability_count):
            raise ValueError("tool plan narrowed flag does not match its counts")
        if self.level is PlanningLevel.BYPASS and self.budget is not None:
            raise ValueError("bypassed tool planning cannot assign a compute budget")
        return self


class ProductDecision(StrictModel):
    """Independent safety and tool/budget channels for the Taotu 2.0 host."""

    schema_version: Literal["1"] = "1"
    request_id: str = Field(min_length=1)
    safety: ProductSafetyDecision
    plan: ToolBudgetPlan


class ExecutionFeedback(StrictModel):
    """Trusted host report produced after a product decision finishes."""

    schema_version: Literal["1"] = "1"
    request_id: str = Field(min_length=1, max_length=128)
    session_id: str = Field(min_length=1, max_length=256)
    called_tools: tuple[CapabilityId, ...] = Field(default=(), max_length=256)
    succeeded: dict[CapabilityId, bool] = Field(default_factory=dict)
    task_completed: bool
    user_confirmed_then_completed: bool = False

    @model_validator(mode="after")
    def require_unambiguous_results(self) -> ExecutionFeedback:
        if len(self.called_tools) != len(set(self.called_tools)):
            raise ValueError("called tools must be unique")
        if set(self.succeeded) != set(self.called_tools):
            raise ValueError("succeeded keys must exactly match called tools")
        if self.user_confirmed_then_completed and not self.task_completed:
            raise ValueError("confirmed completion requires a completed task")
        return self


class RoutingFeedbackRecord(StrictModel):
    """Sanitized routing sample passed to the host-owned learning sink."""

    user_message: str = Field(min_length=1, max_length=32_768)
    predicted_domains: tuple[DomainKeyword, ...] = Field(default=(), max_length=64)
    called_tools: tuple[CapabilityId, ...] = Field(default=(), max_length=256)
    reward: Literal[0.0, 1.0]
    task_completed: bool


class FalseBlockRecord(StrictModel):
    """Evidence that a confirmation gate was followed by successful completion."""

    request_id: str = Field(min_length=1, max_length=128)
    original_action: Literal[SafetyAction.CONFIRM]
    reason_codes: tuple[ReasonCode, ...] = ()
    completed_after_confirm: Literal[True] = True


class FeedbackDispatchReceipt(StrictModel):
    """Acknowledges local dispatch, not durable persistence by the host."""

    schema_version: Literal["1"] = "1"
    accepted: bool
    reason_codes: tuple[ReasonCode, ...] = ()


class Router0Result(StrictModel):
    status: Router0Status
    is_write_op: bool = False
    risk_level: RiskLevel = RiskLevel.LOW
    reason_codes: tuple[str, ...] = ()


class RedactionResult(StrictModel):
    redacted_text: str
    data_classification: DataClassification
    entity_count: int = Field(default=0, ge=0)
    policy_action: RedactionAction
    reason_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def enforce_redaction_boundary(self) -> RedactionResult:
        if (
            self.data_classification is DataClassification.L4
            and self.policy_action is not RedactionAction.BLOCK
        ):
            raise ValueError("L4 redaction results must block")
        if (
            self.data_classification
            in {
                DataClassification.L1,
                DataClassification.L2,
                DataClassification.L3,
            }
            and self.policy_action is RedactionAction.ALLOW
        ):
            raise ValueError("L1-L3 data cannot pass the redaction boundary unchanged")
        if self.policy_action is not RedactionAction.BLOCK and not self.redacted_text:
            raise ValueError("non-blocking redaction results require redacted text")
        return self


class HandoffEnvelope(StrictModel):
    request_id: str
    tenant_id: str
    user_id: str
    session_id: str | None = None
    channel: str = Field(min_length=1)
    locale: str = Field(min_length=1)
    redacted_text: str
    data_classification: DataClassification
    policy_reasons: tuple[str, ...] = ()
    candidate_tool_ids: tuple[str, ...] = ()
    candidate_action_ids: tuple[str, ...] = ()

    @model_validator(mode="after")
    def reject_l4(self) -> HandoffEnvelope:
        if self.data_classification is DataClassification.L4:
            raise ValueError("L4 data cannot be handed to Brain")
        return self


class MemoryEvent(StrictModel):
    tenant_id: str
    session_id: str | None = None
    event_type: str
    redacted_payload: dict[str, Any]
    data_classification: DataClassification

    @model_validator(mode="after")
    def reject_l4(self) -> MemoryEvent:
        if self.data_classification is DataClassification.L4:
            raise ValueError("L4 data cannot be persisted to Memory")
        return self


class HandoffReceipt(StrictModel):
    target: str = "brain"
    accepted: bool = False
    reason: str
    external_trace_id: str | None = None


class MemoryWriteReceipt(StrictModel):
    persisted: bool = False
    reason: str


class ClarificationPrompt(StrictModel):
    question: str = Field(min_length=1)
    missing_required: tuple[str, ...] = ()


class ConfirmationPrompt(StrictModel):
    prompt: str = Field(min_length=1)
    reason_codes: tuple[str, ...] = ()


class Router1Output(StrictModel):
    decision: RouteDecision
    answer: str | None = None

    @model_validator(mode="after")
    def require_answer_for_slm_route(self) -> Router1Output:
        if self.decision.route_decision is RouteType.SLM_ANSWER and not self.answer:
            raise ValueError("slm_answer requires answer content")
        if self.decision.route_decision is not RouteType.SLM_ANSWER and self.answer is not None:
            raise ValueError("only slm_answer may carry answer content")
        return self


class CerebellumResponse(StrictModel):
    decision: RouteDecision
    answer: str | None = None
    handoff: HandoffReceipt | None = None
    clarification: ClarificationPrompt | None = None
    confirmation: ConfirmationPrompt | None = None
    memory: MemoryWriteReceipt | None = None

    @model_validator(mode="after")
    def require_route_payload(self) -> CerebellumResponse:
        route = self.decision.route_decision
        if route is RouteType.SLM_ANSWER and not self.answer:
            raise ValueError("slm_answer response requires answer")
        if route is RouteType.BRAIN_HANDOFF and self.handoff is None:
            raise ValueError("brain_handoff response requires handoff receipt")
        if route is RouteType.CLARIFY and self.clarification is None:
            raise ValueError("clarify response requires clarification prompt")
        if route is RouteType.CONFIRM and self.confirmation is None:
            raise ValueError("confirm response requires confirmation prompt")
        if route is not RouteType.SLM_ANSWER and self.answer is not None:
            raise ValueError("only slm_answer may carry answer content")
        if route is not RouteType.BRAIN_HANDOFF and self.handoff is not None:
            raise ValueError("only brain_handoff may carry a handoff receipt")
        if route is not RouteType.CLARIFY and self.clarification is not None:
            raise ValueError("only clarify may carry a clarification prompt")
        if route is not RouteType.CONFIRM and self.confirmation is not None:
            raise ValueError("only confirm may carry a confirmation prompt")
        return self


class AuditEvent(StrictModel):
    trace_id: str
    request_id: str
    event_type: str
    data_classification: DataClassification
    risk_level: RiskLevel
    reason_codes: tuple[str, ...] = ()
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ToolExecutionRequest(StrictModel):
    tool_id: str
    arguments: dict[str, Any]
    request_id: str


class VaultArgumentBinding(StrictModel):
    """One exact Tool/Action argument a trusted Vault reference may populate."""

    tool_id: CapabilityId
    action_id: CapabilityId
    argument_name: VaultArgumentName


class VaultBindingCheck(StrictModel):
    """Vault-only pre-execution check; this is never an execution approval."""

    allowed: bool
    reference_count: int = Field(ge=0, le=16)
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def require_failure_reason(self) -> VaultBindingCheck:
        if not self.allowed and not self.reason_codes:
            raise ValueError("denied Vault binding checks require a reason code")
        return self


class ToolExecutionResult(StrictModel):
    tool_id: str
    is_error: bool
    structured_content: dict[str, Any] = Field(default_factory=dict)



# ---------------------------------------------------------------------------
# P1 classification-first routing primitives
# ---------------------------------------------------------------------------
#
# A classification-only model answers fixed questions instead of generating
# free text: a boolean proposition returns a probability, a choice returns a
# distribution over a caller-defined option set, and a score returns a
# distribution over an ordered scale. Because the option set is supplied by
# the caller, such a model structurally cannot invent a capability that is not
# already in the authorized candidate set.
#
# The published limits and weaknesses these contracts are shaped around are
# vendor/author claims, not measurements taken in this repository:
# a 255-option ceiling on a choice task, degraded accuracy on counting,
# arithmetic and date reasoning, degraded accuracy on multi-hop reasoning,
# lower accuracy outside English, and susceptibility to prompt injection.
# Every one of those claims is encoded here as a *restriction*, never as a
# permission.

MAX_CLASSIFIER_OPTIONS = 255
NONE_OF_THESE_OPTION = "none_of_these"
_PROBABILITY_SUM_TOLERANCE = 1e-6

ChoiceOptionLabel = Annotated[str, Field(min_length=1, max_length=128)]
Probability = Annotated[float, Field(ge=0.0, le=1.0, allow_inf_nan=False)]
LanguageSubtag = Annotated[str, Field(pattern=r"^[a-z]{2,3}$")]


def _require_distribution(values: tuple[float, ...], label: str) -> None:
    if any(not math.isfinite(value) for value in values):
        raise ValueError(f"{label} must contain finite probabilities")
    if any(value < 0.0 or value > 1.0 for value in values):
        raise ValueError(f"{label} probabilities must lie in [0, 1]")
    if not math.isclose(sum(values), 1.0, abs_tol=1e-3):
        raise ValueError(f"{label} probabilities must sum to 1")


class ClassificationTaskKind(StrEnum):
    BOOLEAN = "boolean"
    CHOICE = "choice"
    SCORE = "score"


class ClassifierEvidenceStatus(StrEnum):
    """How much trust a classifier deployment has actually earned."""

    DETERMINISTIC = "deterministic"
    FIXTURE = "fixture"
    VALIDATED = "validated"


class ClassifierProfile(StrictModel):
    """Declared capability envelope of a classification backend.

    Every field is a *ceiling*. A backend cannot widen the routing boundary by
    declaring itself trustworthy: unset flags disable the corresponding use.
    """

    classifier_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    evidence_status: ClassifierEvidenceStatus
    max_options: int = Field(default=MAX_CLASSIFIER_OPTIONS, ge=2, le=MAX_CLASSIFIER_OPTIONS)
    max_batched_questions: int = Field(default=1, ge=1, le=64)
    selection_trusted_languages: frozenset[LanguageSubtag] = Field(
        default_factory=lambda: frozenset({"en"}),
    )
    arithmetic_trusted: bool = False
    multi_hop_trusted: bool = False
    injection_resistant: bool = False

    def trusts_language(self, language: str) -> bool:
        return language.split("-")[0].casefold() in self.selection_trusted_languages


class BooleanQuestion(StrictModel):
    question_id: ReasonCode
    proposition: str = Field(min_length=1, max_length=512)


class ChoiceQuestion(StrictModel):
    """A closed option set; the sentinel makes "none of these" expressible."""

    question_id: ReasonCode
    prompt: str = Field(min_length=1, max_length=512)
    options: tuple[ChoiceOptionLabel, ...] = Field(min_length=2, max_length=MAX_CLASSIFIER_OPTIONS)

    @model_validator(mode="after")
    def require_closed_option_set(self) -> ChoiceQuestion:
        if len(self.options) != len(set(self.options)):
            raise ValueError("choice options must be unique")
        if self.options[-1] != NONE_OF_THESE_OPTION:
            raise ValueError("choice options must end with the none_of_these sentinel")
        if NONE_OF_THESE_OPTION in self.options[:-1]:
            raise ValueError("the none_of_these sentinel may only appear once")
        return self


class ScoreQuestion(StrictModel):
    question_id: ReasonCode
    prompt: str = Field(min_length=1, max_length=512)
    scale_size: int = Field(ge=2, le=10)


class ClassificationBatch(StrictModel):
    """One redacted input, many fixed questions, answered in a single read."""

    redacted_text: str = Field(min_length=1, max_length=32_768)
    data_classification: DataClassification
    language: str = Field(default="en", min_length=2, max_length=35)
    booleans: tuple[BooleanQuestion, ...] = Field(default=(), max_length=32)
    choices: tuple[ChoiceQuestion, ...] = Field(default=(), max_length=8)
    scores: tuple[ScoreQuestion, ...] = Field(default=(), max_length=8)

    @model_validator(mode="after")
    def require_safe_unique_questions(self) -> ClassificationBatch:
        if self.data_classification is DataClassification.L4:
            raise ValueError("L4 data cannot reach a classifier")
        ids = [
            *(item.question_id for item in self.booleans),
            *(item.question_id for item in self.choices),
            *(item.question_id for item in self.scores),
        ]
        if not ids:
            raise ValueError("a classification batch needs at least one question")
        if len(ids) != len(set(ids)):
            raise ValueError("question ids must be unique across a batch")
        return self


class BooleanVerdict(StrictModel):
    question_id: ReasonCode
    probability_true: Probability


class ChoiceVerdict(StrictModel):
    question_id: ReasonCode
    probabilities: tuple[float, ...] = Field(min_length=2, max_length=MAX_CLASSIFIER_OPTIONS)

    @model_validator(mode="after")
    def require_normalized_distribution(self) -> ChoiceVerdict:
        _require_distribution(self.probabilities, "choice")
        return self

    @property
    def top_index(self) -> int:
        return max(range(len(self.probabilities)), key=self.probabilities.__getitem__)

    @property
    def top_probability(self) -> float:
        return self.probabilities[self.top_index]

    @property
    def margin(self) -> float:
        ordered = sorted(self.probabilities, reverse=True)
        return ordered[0] - ordered[1]


class ScoreVerdict(StrictModel):
    question_id: ReasonCode
    distribution: tuple[float, ...] = Field(min_length=2, max_length=10)

    @model_validator(mode="after")
    def require_normalized_distribution(self) -> ScoreVerdict:
        _require_distribution(self.distribution, "score")
        return self

    def tail_mass(self, from_index: int) -> float:
        """Probability mass at or above ``from_index``.

        Reading the whole distribution rather than its argmax is the point of
        a score primitive: a bimodal answer with a heavy upper tail is exactly
        the case where a mode-only reading understates risk.
        """

        if from_index < 0 or from_index >= len(self.distribution):
            raise ValueError("tail index is outside the score scale")
        return sum(self.distribution[from_index:])


class ClassificationVerdicts(StrictModel):
    classifier_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    booleans: tuple[BooleanVerdict, ...] = Field(default=(), max_length=32)
    choices: tuple[ChoiceVerdict, ...] = Field(default=(), max_length=8)
    scores: tuple[ScoreVerdict, ...] = Field(default=(), max_length=8)

    def boolean(self, question_id: str) -> BooleanVerdict | None:
        return next(
            (item for item in self.booleans if item.question_id == question_id),
            None,
        )

    def choice(self, question_id: str) -> ChoiceVerdict | None:
        return next(
            (item for item in self.choices if item.question_id == question_id),
            None,
        )

    def score(self, question_id: str) -> ScoreVerdict | None:
        return next(
            (item for item in self.scores if item.question_id == question_id),
            None,
        )


class CalibrationThresholds(StrictModel):
    """Acceptance gates. A write intent may only ever be judged more strictly."""

    accept_probability: Probability = 0.72
    accept_margin: Probability = 0.20
    write_accept_probability: Probability = 0.90
    write_accept_margin: Probability = 0.35
    injection_probability: Probability = 0.50
    risk_tail_mass: Probability = 0.25

    @model_validator(mode="after")
    def require_monotonic_write_strictness(self) -> CalibrationThresholds:
        if self.write_accept_probability < self.accept_probability:
            raise ValueError("write acceptance cannot be looser than read acceptance")
        if self.write_accept_margin < self.accept_margin:
            raise ValueError("write margin cannot be looser than read margin")
        return self


class ClassifierRoutingConfig(StrictModel):
    """Trusted host configuration for the classification-first stage."""

    enabled: bool = False
    shortlist_size: int = Field(default=32, ge=2, le=MAX_CLASSIFIER_OPTIONS)
    thresholds: CalibrationThresholds = Field(default_factory=CalibrationThresholds)
    trust_selection_for_untrusted_language: bool = False
    risk_scale_size: int = Field(default=5, ge=2, le=10)
    risk_tail_from_index: int = Field(default=3, ge=1, le=9)

    @model_validator(mode="after")
    def require_tail_inside_scale(self) -> ClassifierRoutingConfig:
        if self.risk_tail_from_index >= self.risk_scale_size:
            raise ValueError("risk tail index must lie inside the risk scale")
        return self


class CalibratedSelectionAction(StrEnum):
    ACCEPT = "accept"
    ABSTAIN = "abstain"
    ESCALATE = "escalate"


class CalibratedRoutingOutcome(StrictModel):
    """Result of the classification stage. It may narrow, never widen."""

    action: CalibratedSelectionAction
    selected: CapabilityReference | None = None
    shortlist: tuple[CapabilityReference, ...] = Field(default=(), max_length=MAX_CLASSIFIER_OPTIONS)
    top_probability: Probability = 0.0
    margin: Probability = 0.0
    risk_level: RiskLevel = RiskLevel.LOW
    injection_suspected: bool = False
    language_trusted: bool = True
    shortlist_truncated: bool = False
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def require_consistent_selection(self) -> CalibratedRoutingOutcome:
        if self.action is CalibratedSelectionAction.ACCEPT:
            if self.selected is None:
                raise ValueError("an accepted calibrated outcome requires a selection")
            if self.selected not in self.shortlist:
                raise ValueError("a calibrated selection must come from the shortlist")
            if self.injection_suspected:
                raise ValueError("a suspected injection cannot yield an accepted selection")
        elif self.selected is not None:
            raise ValueError("only an accepted calibrated outcome may carry a selection")
        return self


# ---------------------------------------------------------------------------
# Legacy engine extension boundary (agent cerebellum 1.0 -> 2.0)
# ---------------------------------------------------------------------------


class LegacyEngineSnapshot(StrictModel):
    """Read-only view of what the host's 1.0 pre-router already decided.

    The 2.0 cerebellum extends that decision instead of replacing it: it adds a
    safety channel the 1.0 engine does not have, and it may drop tools from the
    1.0 tool set. It can never add a tool the 1.0 engine did not keep, so a host
    that adopts the plugin can never end up with a *wider* catalog than before.
    """

    schema_version: Literal["1"] = "1"
    engine_version: Literal["1.0"] = "1.0"
    catalog_tool_ids: tuple[CapabilityId, ...] = Field(default=(), max_length=4096)
    narrowed_tool_ids: tuple[CapabilityId, ...] = Field(default=(), max_length=4096)
    domains: tuple[DomainKeyword, ...] = Field(default=(), max_length=64)
    budget_level: ComputeBudgetLevel | None = None
    narrowed: bool = False
    note: ReasonCode | None = None

    @model_validator(mode="after")
    def require_consistent_tool_sets(self) -> LegacyEngineSnapshot:
        if len(self.catalog_tool_ids) != len(set(self.catalog_tool_ids)):
            raise ValueError("legacy catalog tool ids must be unique")
        if len(self.narrowed_tool_ids) != len(set(self.narrowed_tool_ids)):
            raise ValueError("legacy narrowed tool ids must be unique")
        if not set(self.narrowed_tool_ids) <= set(self.catalog_tool_ids):
            raise ValueError("legacy narrowed tools must be a subset of the legacy catalog")
        return self


class ExtensionMode(StrEnum):
    EXTEND = "extend"
    PASSTHROUGH = "passthrough"
    SAFETY_HOLD = "safety_hold"


class CerebellumExtensionResult(StrictModel):
    """What the plugin hands back to the host's 1.0 pre-router."""

    schema_version: Literal["1"] = "1"
    cerebellum_version: str = Field(min_length=1, max_length=64)
    mode: ExtensionMode
    decision: ProductDecision
    tool_ids: tuple[CapabilityId, ...] = Field(default=(), max_length=4096)
    dropped_tool_ids: tuple[CapabilityId, ...] = Field(default=(), max_length=4096)
    calibration: CalibratedRoutingOutcome | None = None
    reason_codes: tuple[ReasonCode, ...] = ()

    @model_validator(mode="after")
    def require_narrowing_only_semantics(self) -> CerebellumExtensionResult:
        if len(self.tool_ids) != len(set(self.tool_ids)):
            raise ValueError("extension tool ids must be unique")
        if set(self.tool_ids) & set(self.dropped_tool_ids):
            raise ValueError("a tool cannot be both kept and dropped")
        if self.mode is ExtensionMode.SAFETY_HOLD:
            if self.tool_ids:
                raise ValueError("a safety hold cannot hand any tool back to the host")
            if self.decision.safety.action is SafetyAction.ALLOW:
                raise ValueError("a safety hold requires a non-allow safety action")
        elif self.decision.safety.action is not SafetyAction.ALLOW:
            raise ValueError("a non-allow safety action must produce a safety hold")
        if self.mode is ExtensionMode.PASSTHROUGH and self.dropped_tool_ids:
            raise ValueError("a passthrough extension cannot drop tools")
        return self


class ServiceStatus(StrictModel):
    status: str
    version: str
    registry_configured: bool
    catalog_id: str | None
    catalog_evidence_status: CatalogEvidenceStatus | None
    capability_count: int = Field(ge=0)
    retriever_kind: str
    router1_configured: bool
    router_profile_configured: bool
    router_profile_id: str | None
    router_profile_evidence_status: RouterProfileEvidenceStatus | None
    router_tool_direct_enabled: bool
    router_slm_answer_enabled: bool
    tool_planning_configured: bool
    tool_planning_profile_id: str | None
    tool_planning_evidence_status: CatalogEvidenceStatus | None
    f4_fallback_ready: bool
    affinity_learning_enabled: bool
    approval_introspection_configured: bool
    wechat_gate_configured: bool
    f7_wechat_gate_ready: bool
    skill_identity_filter_configured: bool
    role_toolset_profile_configured: bool
    role_toolset_profile_id: str | None
    role_toolset_evidence_status: CatalogEvidenceStatus | None
    f6_role_toolset_ready: bool
    vault_reference_validation_configured: bool
    f13_vault_reference_ready: bool
    tool_plan_cache_enabled: bool
    tool_plan_cache_ttl_seconds: float = Field(gt=0.0)
    tool_plan_cache_max_entries: int = Field(ge=1)
    classifier_configured: bool = False
    classifier_id: str | None = None
    classifier_evidence_status: ClassifierEvidenceStatus | None = None
    classifier_routing_enabled: bool = False
    brain_configured: bool
    memory_enabled: bool
    executor_enabled: bool


class ErrorEnvelope(StrictModel):
    code: str
    message: str
    trace_id: str = Field(default_factory=lambda: uuid4().hex)
    details: dict[str, Any] = Field(default_factory=dict)
