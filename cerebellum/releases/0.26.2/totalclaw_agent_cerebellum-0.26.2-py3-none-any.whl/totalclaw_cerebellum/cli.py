import uvicorn

from totalclaw_cerebellum.adapters.mcp import (
    create_mcp_http_app,
    create_mcp_server,
)
from totalclaw_cerebellum.settings import Settings


def run_http() -> None:
    settings = Settings()
    uvicorn.run(
        "totalclaw_cerebellum.adapters.http:create_app",
        factory=True,
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level.casefold(),
    )


def run_mcp() -> None:
    create_mcp_server().run(transport="stdio")


def run_mcp_http() -> None:
    settings = Settings()
    uvicorn.run(
        create_mcp_http_app(
            host=settings.mcp_http_host,
            port=settings.mcp_http_port,
            streamable_http_path=settings.mcp_http_path,
            max_request_bytes=settings.mcp_http_max_request_bytes,
            max_concurrency=settings.mcp_http_max_concurrency,
            log_level="WARNING",
        ),
        host=settings.mcp_http_host,
        port=settings.mcp_http_port,
        log_level=settings.log_level.casefold(),
    )
