from __future__ import annotations

import argparse
import json
import sys
from datetime import UTC, datetime
from math import ceil
from pathlib import Path
from typing import Annotated, Any, Literal

from pydantic import Field, ValidationError, model_validator

from totalclaw_cerebellum.domain import (
    CatalogEvidenceStatus,
    ComputeBudgetLevel,
    ProductDecision,
    RegistryEvalStatus,
    SafetyAction,
    StrictModel,
)

MAX_SHADOW_DATASET_BYTES = 64 * 1024 * 1024
MAX_SHADOW_LINE_BYTES = 1024 * 1024
MAX_SHADOW_CASES = 100_000
ShadowToolId = Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")]
ShadowReasonCode = Annotated[str, Field(pattern=r"^[a-z0-9_]{1,128}$")]


class ShadowReplayInputError(ValueError):
    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


class ShadowDecisionObservation(StrictModel):
    """One side of a frozen old/new decision comparison, without user text."""

    tools: tuple[ShadowToolId, ...] = Field(default=(), max_length=2048)
    safety_action: SafetyAction | None = None
    enters_brain: bool
    budget_level: ComputeBudgetLevel | None = None
    reason_codes: tuple[ShadowReasonCode, ...] = Field(default=(), max_length=256)

    @model_validator(mode="after")
    def require_unique_values(self) -> ShadowDecisionObservation:
        if len(self.tools) != len(set(self.tools)):
            raise ValueError("shadow decision tools must be unique")
        if len(self.reason_codes) != len(set(self.reason_codes)):
            raise ValueError("shadow decision reason codes must be unique")
        if (
            self.safety_action
            in {SafetyAction.CLARIFY, SafetyAction.CONFIRM, SafetyAction.BLOCK}
            and self.enters_brain
        ):
            raise ValueError("short-circuit shadow decisions cannot enter Brain")
        return self


class ShadowReplayObservation(StrictModel):
    """Sanitized JSONL record emitted by a host running old and new paths in shadow."""

    schema_version: Literal["1"] = "1"
    case_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    observed_at: datetime
    authorized_tools: tuple[ShadowToolId, ...] = Field(max_length=2048)
    baseline: ShadowDecisionObservation
    candidate: ShadowDecisionObservation
    candidate_internal_latency_ms: float = Field(ge=0.0, allow_inf_nan=False)
    candidate_end_to_end_latency_ms: float = Field(ge=0.0, allow_inf_nan=False)
    false_block_observed: bool | None = None
    baseline_cache_read_tokens: int | None = Field(default=None, ge=0)
    candidate_cache_read_tokens: int | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def require_replay_invariants(self) -> ShadowReplayObservation:
        if self.observed_at.tzinfo is None:
            raise ValueError("shadow observation timestamps must include a timezone")
        if len(self.authorized_tools) != len(set(self.authorized_tools)):
            raise ValueError("authorized shadow tools must be unique")
        if not set(self.baseline.tools).issubset(self.authorized_tools):
            raise ValueError("baseline tools must be a subset of authorized tools")
        if self.candidate.safety_action is None:
            raise ValueError("candidate shadow decisions require a safety action")
        if (
            self.false_block_observed is not None
            and self.candidate.safety_action
            not in {SafetyAction.CLARIFY, SafetyAction.CONFIRM, SafetyAction.BLOCK}
        ):
            raise ValueError(
                "false-block evidence is only defined for short-circuit decisions"
            )
        token_fields = (
            self.baseline_cache_read_tokens,
            self.candidate_cache_read_tokens,
        )
        if (token_fields[0] is None) != (token_fields[1] is None):
            raise ValueError("cache token counts must be supplied as a pair")
        if self.candidate_end_to_end_latency_ms < self.candidate_internal_latency_ms:
            raise ValueError("end-to-end latency cannot be below internal latency")
        return self


class ShadowReplayReport(StrictModel):
    schema_version: Literal["1"] = "1"
    dataset_version: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,128}$")
    evidence_status: CatalogEvidenceStatus
    sample_count: int = Field(ge=1)
    observation_window_days: float = Field(ge=0.0)
    observation_day_count: int = Field(ge=1)
    exact_tool_set_rate: float = Field(ge=0.0, le=1.0)
    tool_omission_case_count: int = Field(ge=0)
    tool_omission_rate: float = Field(ge=0.0, le=1.0)
    missing_tool_reference_count: int = Field(ge=0)
    unexpected_tool_reference_count: int = Field(ge=0)
    unauthorized_exposure_count: int = Field(ge=0)
    brain_entry_match_rate: float = Field(ge=0.0, le=1.0)
    safety_action_evaluated: int = Field(ge=0)
    safety_action_match_rate: float | None = Field(default=None, ge=0.0, le=1.0)
    budget_evaluated: int = Field(ge=0)
    budget_match_rate: float | None = Field(default=None, ge=0.0, le=1.0)
    false_block_evaluated: int = Field(ge=0)
    false_block_count: int = Field(ge=0)
    false_block_rate: float | None = Field(default=None, ge=0.0, le=1.0)
    internal_latency_p50_ms: float = Field(ge=0.0)
    internal_latency_p95_ms: float = Field(ge=0.0)
    end_to_end_latency_p50_ms: float = Field(ge=0.0)
    end_to_end_latency_p95_ms: float = Field(ge=0.0)
    cache_read_token_ratio: float | None = Field(default=None, ge=0.0)
    failed_case_ids: tuple[str, ...] = ()
    rollback_required: bool
    production_acceptance_ready: bool
    status: RegistryEvalStatus
    reason_codes: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()


def build_shadow_observation(
    *,
    case_id: str,
    observed_at: datetime,
    authorized_tools: tuple[str, ...],
    baseline: ShadowDecisionObservation,
    candidate_decision: ProductDecision,
    candidate_internal_latency_ms: float,
    candidate_end_to_end_latency_ms: float,
    false_block_observed: bool | None = None,
    baseline_cache_read_tokens: int | None = None,
    candidate_cache_read_tokens: int | None = None,
) -> ShadowReplayObservation:
    """Build a replay record from a decision without accepting request text.

    The API intentionally has no raw/redacted-text, identity, callback, or exception
    argument. Only bounded decision metadata may cross into the replay dataset.
    """

    candidate_tools = tuple(
        dict.fromkeys(reference.tool_id for reference in candidate_decision.plan.tools)
    )
    reason_codes = tuple(
        dict.fromkeys(
            (
                *candidate_decision.safety.reason_codes,
                *candidate_decision.plan.reason_codes,
            )
        )
    )
    candidate = ShadowDecisionObservation(
        tools=candidate_tools,
        safety_action=candidate_decision.safety.action,
        enters_brain=candidate_decision.safety.action
        in {SafetyAction.ALLOW, SafetyAction.HANDOFF},
        budget_level=(
            candidate_decision.plan.budget.level
            if candidate_decision.plan.budget is not None
            else None
        ),
        reason_codes=reason_codes,
    )
    return ShadowReplayObservation(
        case_id=case_id,
        observed_at=observed_at,
        authorized_tools=authorized_tools,
        baseline=baseline,
        candidate=candidate,
        candidate_internal_latency_ms=candidate_internal_latency_ms,
        candidate_end_to_end_latency_ms=candidate_end_to_end_latency_ms,
        false_block_observed=false_block_observed,
        baseline_cache_read_tokens=baseline_cache_read_tokens,
        candidate_cache_read_tokens=candidate_cache_read_tokens,
    )


def load_shadow_replay_jsonl(path: str | Path) -> tuple[ShadowReplayObservation, ...]:
    try:
        document = Path(path).read_bytes()
    except OSError:
        raise ShadowReplayInputError("shadow_replay_dataset_unreadable") from None
    if len(document) > MAX_SHADOW_DATASET_BYTES:
        raise ShadowReplayInputError("shadow_replay_dataset_too_large")

    observations: list[ShadowReplayObservation] = []
    try:
        for raw_line in document.splitlines():
            if not raw_line.strip():
                continue
            if len(raw_line) > MAX_SHADOW_LINE_BYTES:
                raise ShadowReplayInputError("shadow_replay_line_too_large")
            payload = json.loads(
                raw_line.decode("utf-8"),
                object_pairs_hook=_unique_object,
            )
            observations.append(ShadowReplayObservation.model_validate(payload))
            if len(observations) > MAX_SHADOW_CASES:
                raise ShadowReplayInputError("shadow_replay_too_many_cases")
    except ShadowReplayInputError:
        raise
    except (UnicodeError, json.JSONDecodeError, ValidationError):
        raise ShadowReplayInputError("shadow_replay_dataset_invalid") from None

    case_ids = tuple(item.case_id for item in observations)
    if not observations:
        raise ShadowReplayInputError("shadow_replay_dataset_empty")
    if len(case_ids) != len(set(case_ids)):
        raise ShadowReplayInputError("shadow_replay_duplicate_case_id")
    return tuple(observations)


def evaluate_shadow_replay(
    observations: tuple[ShadowReplayObservation, ...],
    *,
    dataset_version: str,
    evidence_status: CatalogEvidenceStatus,
) -> ShadowReplayReport:
    if not observations:
        raise ShadowReplayInputError("shadow_replay_dataset_empty")

    exact_tool_sets = 0
    omission_cases = 0
    missing_references = 0
    unexpected_references = 0
    unauthorized_exposures = 0
    brain_matches = 0
    safety_evaluated = 0
    safety_matches = 0
    budget_evaluated = 0
    budget_matches = 0
    false_block_evaluated = 0
    false_blocks = 0
    failed_case_ids: list[str] = []
    internal_latencies: list[float] = []
    end_to_end_latencies: list[float] = []
    baseline_cache_tokens = 0
    candidate_cache_tokens = 0
    cache_token_cases = 0

    for observation in observations:
        baseline_tools = set(observation.baseline.tools)
        candidate_tools = set(observation.candidate.tools)
        authorized_tools = set(observation.authorized_tools)
        missing = baseline_tools - candidate_tools
        unexpected = candidate_tools - baseline_tools
        unauthorized = candidate_tools - authorized_tools
        case_failed = False

        if baseline_tools == candidate_tools:
            exact_tool_sets += 1
        if missing:
            omission_cases += 1
            missing_references += len(missing)
            case_failed = True
        unexpected_references += len(unexpected)
        if unauthorized:
            unauthorized_exposures += len(unauthorized)
            case_failed = True
        if observation.baseline.enters_brain == observation.candidate.enters_brain:
            brain_matches += 1
        else:
            case_failed = True

        if observation.baseline.safety_action is not None:
            safety_evaluated += 1
            if observation.baseline.safety_action is observation.candidate.safety_action:
                safety_matches += 1
            else:
                case_failed = True
        if observation.baseline.budget_level is not None:
            budget_evaluated += 1
            if observation.baseline.budget_level is observation.candidate.budget_level:
                budget_matches += 1

        if observation.false_block_observed is not None:
            false_block_evaluated += 1
            if observation.false_block_observed:
                false_blocks += 1
                case_failed = True

        internal_latencies.append(observation.candidate_internal_latency_ms)
        end_to_end_latencies.append(observation.candidate_end_to_end_latency_ms)
        if observation.baseline_cache_read_tokens is not None:
            cache_token_cases += 1
            baseline_cache_tokens += observation.baseline_cache_read_tokens
            candidate_cache_tokens += observation.candidate_cache_read_tokens or 0
        if case_failed:
            failed_case_ids.append(observation.case_id)

    sample_count = len(observations)
    omission_rate = omission_cases / sample_count
    false_block_rate = _ratio(false_blocks, false_block_evaluated)
    end_to_end_p95 = _percentile(end_to_end_latencies, 0.95)
    window_days = max(
        0.0,
        (
            max(item.observed_at for item in observations)
            - min(item.observed_at for item in observations)
        ).total_seconds()
        / 86_400.0,
    )
    observation_day_count = len(
        {item.observed_at.astimezone(UTC).date() for item in observations}
    )
    cache_ratio = (
        candidate_cache_tokens / baseline_cache_tokens
        if cache_token_cases and baseline_cache_tokens
        else None
    )

    rollback_reasons: list[str] = []
    warning_reasons: list[str] = []
    if omission_rate > 0.005:
        rollback_reasons.append("tool_omission_rate_exceeds_rollback_line")
    elif omission_rate > 0.001:
        warning_reasons.append("tool_omission_rate_exceeds_shadow_target")
    if unauthorized_exposures:
        rollback_reasons.append("unauthorized_candidate_exposure")
    if false_block_rate is None:
        warning_reasons.append("false_block_rate_not_evaluated")
    elif false_block_rate > 0.01:
        rollback_reasons.append("false_block_rate_exceeds_rollback_line")
    elif false_block_rate > 0.005:
        warning_reasons.append("false_block_rate_exceeds_shadow_target")
    if end_to_end_p95 > 10.0:
        rollback_reasons.append("end_to_end_p95_exceeds_rollback_line")
    if cache_ratio is not None and cache_ratio < 1.0:
        warning_reasons.append("cache_read_tokens_below_baseline")
    if window_days < 14.0:
        warning_reasons.append("shadow_observation_window_below_fourteen_days")
    if observation_day_count < 14:
        warning_reasons.append("shadow_observation_day_coverage_below_fourteen")
    if exact_tool_sets != sample_count:
        warning_reasons.append("tool_set_differs_from_baseline")
    if brain_matches != sample_count:
        warning_reasons.append("brain_entry_differs_from_baseline")
    if safety_evaluated and safety_matches != safety_evaluated:
        warning_reasons.append("safety_action_differs_from_expected")
    if safety_evaluated != sample_count:
        warning_reasons.append("safety_action_not_fully_evaluated")

    rollback_required = bool(rollback_reasons)
    production_acceptance_ready = (
        not rollback_required
        and not warning_reasons
        and evidence_status is CatalogEvidenceStatus.VALIDATED
    )
    if rollback_required:
        status = RegistryEvalStatus.FAIL
    elif warning_reasons:
        status = RegistryEvalStatus.WARN
    else:
        status = RegistryEvalStatus.PASS

    notes = ["budget_difference_is_reported_but_not_a_failure_gate"]
    if evidence_status is CatalogEvidenceStatus.FIXTURE:
        notes.append("fixture_shadow_report_is_not_production_evidence")
    return ShadowReplayReport(
        dataset_version=dataset_version,
        evidence_status=evidence_status,
        sample_count=sample_count,
        observation_window_days=window_days,
        observation_day_count=observation_day_count,
        exact_tool_set_rate=exact_tool_sets / sample_count,
        tool_omission_case_count=omission_cases,
        tool_omission_rate=omission_rate,
        missing_tool_reference_count=missing_references,
        unexpected_tool_reference_count=unexpected_references,
        unauthorized_exposure_count=unauthorized_exposures,
        brain_entry_match_rate=brain_matches / sample_count,
        safety_action_evaluated=safety_evaluated,
        safety_action_match_rate=_ratio(safety_matches, safety_evaluated),
        budget_evaluated=budget_evaluated,
        budget_match_rate=_ratio(budget_matches, budget_evaluated),
        false_block_evaluated=false_block_evaluated,
        false_block_count=false_blocks,
        false_block_rate=false_block_rate,
        internal_latency_p50_ms=_percentile(internal_latencies, 0.50),
        internal_latency_p95_ms=_percentile(internal_latencies, 0.95),
        end_to_end_latency_p50_ms=_percentile(end_to_end_latencies, 0.50),
        end_to_end_latency_p95_ms=end_to_end_p95,
        cache_read_token_ratio=cache_ratio,
        failed_case_ids=tuple(failed_case_ids),
        rollback_required=rollback_required,
        production_acceptance_ready=production_acceptance_ready,
        status=status,
        reason_codes=(*rollback_reasons, *warning_reasons),
        notes=tuple(notes),
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="cerebellum-eval-shadow",
        description="Compare sanitized old/new shadow observations from JSON Lines.",
    )
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--dataset-version", required=True)
    parser.add_argument(
        "--evidence-status",
        choices=tuple(status.value for status in CatalogEvidenceStatus),
        default=CatalogEvidenceStatus.FIXTURE.value,
    )
    parser.add_argument("--output")
    arguments = parser.parse_args(argv)

    try:
        observations = load_shadow_replay_jsonl(arguments.dataset)
        report = evaluate_shadow_replay(
            observations,
            dataset_version=arguments.dataset_version,
            evidence_status=CatalogEvidenceStatus(arguments.evidence_status),
        )
    except ShadowReplayInputError:
        _write_output(
            {"status": "fail", "error_code": "shadow_replay_input_invalid"},
            arguments.output,
        )
        return 2

    _write_output(report.model_dump(mode="json"), arguments.output)
    return 1 if report.status is RegistryEvalStatus.FAIL else 0


def run_cli() -> None:
    raise SystemExit(main())


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ShadowReplayInputError("shadow_replay_duplicate_json_key")
        result[key] = value
    return result


def _ratio(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _percentile(values: list[float], percentile: float) -> float:
    ordered = sorted(values)
    index = max(0, ceil(percentile * len(ordered)) - 1)
    return ordered[index]


def _write_output(payload: dict[str, Any], output: str | None) -> None:
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(serialized)
        return
    try:
        Path(output).write_text(serialized, encoding="utf-8")
    except OSError:
        sys.stderr.write(
            '{"status":"fail","error_code":"shadow_replay_output_unwritable"}\n'
        )
        raise SystemExit(2) from None


if __name__ == "__main__":
    run_cli()
