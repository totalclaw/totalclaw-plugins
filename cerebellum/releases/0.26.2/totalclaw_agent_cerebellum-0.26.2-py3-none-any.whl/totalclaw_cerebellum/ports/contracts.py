from __future__ import annotations

from typing import Protocol, runtime_checkable

from totalclaw_cerebellum.domain.models import (
    AffinitySnapshotHandle,
    ApprovalRequirement,
    AuditEvent,
    CapabilityCandidate,
    CapabilityId,
    CatalogEvidenceStatus,
    CerebellumRequest,
    ClassificationBatch,
    ClassificationVerdicts,
    ClassifierProfile,
    FalseBlockRecord,
    HandoffEnvelope,
    HandoffReceipt,
    IdentityContext,
    IdentityHints,
    MemoryEvent,
    MemoryWriteReceipt,
    RedactionResult,
    RequestContext,
    RouteDecision,
    Router0Result,
    Router1Output,
    RoutingFeedbackRecord,
    SafeRoutingRequest,
    SkillIdentityVisibility,
    ToolExecutionRequest,
    ToolExecutionResult,
    VaultArgumentBinding,
)


@runtime_checkable
class Router0Port(Protocol):
    async def route(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
    ) -> Router0Result: ...


@runtime_checkable
class Router1Port(Protocol):
    @property
    def configured(self) -> bool: ...

    @property
    def model_id(self) -> str | None: ...

    @property
    def prompt_version(self) -> str | None: ...

    async def route(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> Router1Output: ...


@runtime_checkable
class BrainPort(Protocol):
    @property
    def configured(self) -> bool: ...

    async def handoff(self, envelope: HandoffEnvelope) -> HandoffReceipt: ...


@runtime_checkable
class MemoryPort(Protocol):
    @property
    def enabled(self) -> bool: ...

    async def append(self, event: MemoryEvent) -> MemoryWriteReceipt: ...

    async def search(self, tenant_id: str, query: str, limit: int = 5) -> tuple[dict, ...]: ...


@runtime_checkable
class RegistryPort(Protocol):
    @property
    def configured(self) -> bool: ...

    @property
    def catalog_id(self) -> str | None: ...

    @property
    def evidence_status(self) -> CatalogEvidenceStatus | None: ...

    @property
    def capability_count(self) -> int: ...

    async def list_authorized(
        self,
        identity: IdentityContext,
    ) -> tuple[CapabilityCandidate, ...]: ...


@runtime_checkable
class RetrieverPort(Protocol):
    @property
    def kind(self) -> str: ...

    async def retrieve(
        self,
        query: str,
        candidates: tuple[CapabilityCandidate, ...],
        limit: int = 5,
    ) -> tuple[CapabilityCandidate, ...]: ...


@runtime_checkable
class SkillIdentityFilterPort(Protocol):
    @property
    def configured(self) -> bool: ...

    async def evaluate(
        self,
        identity: IdentityContext,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> SkillIdentityVisibility: ...


@runtime_checkable
class PolicyPort(Protocol):
    async def evaluate(
        self,
        request: SafeRoutingRequest,
        context: RequestContext,
        decision: RouteDecision,
        candidates: tuple[CapabilityCandidate, ...],
    ) -> RouteDecision: ...


@runtime_checkable
class RedactorPort(Protocol):
    async def redact(
        self,
        request: CerebellumRequest,
        context: RequestContext,
    ) -> RedactionResult: ...


@runtime_checkable
class OutputGuardPort(Protocol):
    async def inspect(
        self,
        text: str,
        context: RequestContext,
        *,
        source_redacted_text: str,
    ) -> RedactionResult: ...


@runtime_checkable
class IdentityResolverPort(Protocol):
    async def resolve(self, hints: IdentityHints, channel: str) -> RequestContext: ...


@runtime_checkable
class AuditPort(Protocol):
    async def record(self, event: AuditEvent) -> None: ...


@runtime_checkable
class ClassifierPort(Protocol):
    """Vendor-neutral classification backend for the P1 pre-router.

    The port deliberately exposes only the three closed-form primitives. It can
    never return free text, and it never sees an option the caller did not put
    in the batch, so a backend cannot introduce a capability by itself.
    """

    @property
    def configured(self) -> bool: ...

    @property
    def profile(self) -> ClassifierProfile | None: ...

    async def classify(self, batch: ClassificationBatch) -> ClassificationVerdicts: ...


@runtime_checkable
class RewardFeedbackPort(Protocol):
    """Host-owned learning sink; Cerebellum never persists these records."""

    @property
    def enabled(self) -> bool: ...

    def record_tool_result(
        self,
        domain: str,
        tool_name: str,
        succeeded: bool,
    ) -> None: ...

    def record_routing(self, record: RoutingFeedbackRecord) -> None: ...

    def record_false_block(self, record: FalseBlockRecord) -> None: ...


@runtime_checkable
class AffinityLearningPort(Protocol):
    """Optional host-owned P4 learning state for authorized selection and ordering."""

    @property
    def enabled(self) -> bool: ...

    async def global_top_tools(self, limit: int) -> tuple[CapabilityId, ...]: ...

    async def top_tools_for_domain(
        self,
        domain: str,
        limit: int,
    ) -> tuple[CapabilityId, ...]: ...

    async def sort_by_affinity(
        self,
        tool_ids: tuple[CapabilityId, ...],
        domain: str,
    ) -> tuple[CapabilityId, ...]: ...

    async def success_rate(self, tool_id: CapabilityId, domain: str) -> float | None: ...

    async def snapshot(self) -> AffinitySnapshotHandle | None: ...

    async def restore(self, snapshot: AffinitySnapshotHandle) -> None: ...


@runtime_checkable
class ApprovalIntrospectionPort(Protocol):
    """Read-only P11 approval hint; it cannot authorize or execute a tool."""

    @property
    def configured(self) -> bool: ...

    async def would_require_approval(
        self,
        tool_id: CapabilityId,
        args_digest: str,
    ) -> ApprovalRequirement: ...


@runtime_checkable
class VaultReferencePort(Protocol):
    """Trusted host adapter that validates opaque references without returning secrets."""

    @property
    def configured(self) -> bool: ...

    async def validate(
        self,
        reference: str,
        context: RequestContext,
        session_id: str,
        binding: VaultArgumentBinding | None = None,
    ) -> bool: ...


@runtime_checkable
class ToolExecutorPort(Protocol):
    @property
    def enabled(self) -> bool: ...

    async def execute(self, request: ToolExecutionRequest) -> ToolExecutionResult: ...
