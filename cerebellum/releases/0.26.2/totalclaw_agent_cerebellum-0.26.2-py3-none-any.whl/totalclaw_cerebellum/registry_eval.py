from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import sys
from datetime import date, datetime
from enum import Enum
from math import ceil
from pathlib import Path
from time import perf_counter
from typing import Any

from pydantic import ValidationError

from totalclaw_cerebellum.adapters.bm25 import DeterministicBM25Retriever
from totalclaw_cerebellum.adapters.catalog import (
    CatalogIntegrityError,
    load_capability_catalog,
)
from totalclaw_cerebellum.adapters.defaults import InMemoryRegistry
from totalclaw_cerebellum.domain import (
    CapabilityCatalog,
    CapabilityReference,
    CatalogEvidenceStatus,
    RegistryEvalCategory,
    RegistryEvalDataset,
    RegistryEvalReport,
    RegistryEvalStatus,
)
from totalclaw_cerebellum.ports import RegistryPort, RetrieverPort


class RegistryEvalInputError(ValueError):
    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


def load_registry_eval_dataset(path: str | Path) -> RegistryEvalDataset:
    try:
        payload = json.loads(
            Path(path).read_text(encoding="utf-8"),
            object_pairs_hook=_unique_object,
        )
        return RegistryEvalDataset.model_validate(payload)
    except RegistryEvalInputError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise RegistryEvalInputError("registry_eval_dataset_unreadable") from None
    except ValidationError:
        raise RegistryEvalInputError("registry_eval_dataset_invalid") from None


async def evaluate_registry(
    catalog: CapabilityCatalog,
    dataset: RegistryEvalDataset,
    *,
    registry: RegistryPort | None = None,
    retriever: RetrieverPort | None = None,
) -> RegistryEvalReport:
    if catalog.evidence_status is not dataset.evidence_status:
        raise RegistryEvalInputError("registry_eval_evidence_status_mismatch")
    active_registry = registry or InMemoryRegistry.from_catalog(catalog)
    active_retriever = retriever or DeterministicBM25Retriever()

    top1_evaluated = 0
    top1_successes = 0
    top5_evaluated = 0
    top5_successes = 0
    no_match_evaluated = 0
    no_match_successes = 0
    unauthorized_exposure_count = 0
    failed_case_ids: list[str] = []
    latencies_ms: list[float] = []

    for case in dataset.cases:
        started_at = perf_counter()
        authorized = await active_registry.list_authorized(case.identity)
        candidates = await active_retriever.retrieve(case.query, authorized, 5)
        latencies_ms.append((perf_counter() - started_at) * 1000.0)
        actual = tuple(
            _reference(candidate.tool.tool_id, candidate.action.action_id)
            for candidate in candidates
        )
        case_failed = False

        forbidden = {_reference_key(reference) for reference in case.forbidden_candidates}
        exposed = sum(1 for reference in actual if _reference_key(reference) in forbidden)
        if exposed:
            unauthorized_exposure_count += exposed
            case_failed = True

        if case.category is RegistryEvalCategory.NO_MATCH:
            no_match_evaluated += 1
            if not actual:
                no_match_successes += 1
            else:
                case_failed = True
        elif (
            case.category is RegistryEvalCategory.AUTHORIZATION
            and case.expected_top1 is None
        ):
            pass
        else:
            top1_evaluated += 1
            if actual and actual[0] == case.expected_top1:
                top1_successes += 1
            else:
                case_failed = True

            top5_evaluated += 1
            required = case.expected_top5 or (
                (case.expected_top1,) if case.expected_top1 is not None else ()
            )
            actual_keys = {_reference_key(reference) for reference in actual}
            if all(_reference_key(reference) in actual_keys for reference in required):
                top5_successes += 1
            else:
                case_failed = True

        if case_failed:
            failed_case_ids.append(case.case_id)

    top1_accuracy = _ratio(top1_successes, top1_evaluated)
    top5_recall = _ratio(top5_successes, top5_evaluated)
    no_match_accuracy = _ratio(no_match_successes, no_match_evaluated)
    status = _status(top5_recall, unauthorized_exposure_count)
    notes = (
        ("fixture_engineering_smoke_baseline_not_model_quality",)
        if catalog.evidence_status is CatalogEvidenceStatus.FIXTURE
        else ()
    )
    return RegistryEvalReport(
        dataset_version=dataset.dataset_version,
        catalog_id=catalog.catalog_id,
        catalog_digest=_catalog_digest(catalog),
        evidence_status=catalog.evidence_status,
        sample_count=len(dataset.cases),
        top1_evaluated=top1_evaluated,
        top5_evaluated=top5_evaluated,
        no_match_evaluated=no_match_evaluated,
        top1_accuracy=top1_accuracy,
        top5_recall=top5_recall,
        no_match_accuracy=no_match_accuracy,
        unauthorized_exposure_count=unauthorized_exposure_count,
        failed_case_ids=tuple(failed_case_ids),
        latency_p50_ms=_percentile(latencies_ms, 0.50),
        latency_p95_ms=_percentile(latencies_ms, 0.95),
        status=status,
        notes=notes,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="cerebellum-eval-registry",
        description="Evaluate authorized capability retrieval without invoking Router-1.",
    )
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--output")
    arguments = parser.parse_args(argv)

    try:
        catalog = load_capability_catalog(arguments.catalog, environment="evaluation")
        dataset = load_registry_eval_dataset(arguments.dataset)
        report = asyncio.run(evaluate_registry(catalog, dataset))
    except (CatalogIntegrityError, RegistryEvalInputError):
        _write_output(
            {"status": "fail", "error_code": "registry_eval_input_invalid"},
            arguments.output,
        )
        return 2

    _write_output(report.model_dump(mode="json"), arguments.output)
    return (
        1
        if report.status
        in {RegistryEvalStatus.FAIL, RegistryEvalStatus.NOT_EVALUATED}
        else 0
    )


def run_cli() -> None:
    raise SystemExit(main())


def _write_output(payload: dict[str, Any], output: str | None) -> None:
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(serialized)
        return
    try:
        Path(output).write_text(serialized, encoding="utf-8")
    except OSError:
        sys.stderr.write('{"status":"fail","error_code":"registry_eval_output_unwritable"}\n')
        raise SystemExit(2) from None


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise RegistryEvalInputError("registry_eval_duplicate_json_key")
        result[key] = value
    return result


def _reference(tool_id: str, action_id: str) -> CapabilityReference:
    return CapabilityReference(tool_id=tool_id, action_id=action_id)


def _reference_key(reference: CapabilityReference) -> tuple[str, str]:
    return reference.tool_id, reference.action_id


def _ratio(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _status(
    top5_recall: float | None,
    unauthorized_exposure_count: int,
) -> RegistryEvalStatus:
    if unauthorized_exposure_count:
        return RegistryEvalStatus.FAIL
    if top5_recall is None:
        return RegistryEvalStatus.NOT_EVALUATED
    if top5_recall < 0.95:
        return RegistryEvalStatus.FAIL
    if top5_recall < 0.98:
        return RegistryEvalStatus.WARN
    return RegistryEvalStatus.PASS


def _percentile(values: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(0, ceil(percentile * len(ordered)) - 1)
    return ordered[index]


def _catalog_digest(catalog: CapabilityCatalog) -> str:
    canonical = json.dumps(
        _canonicalize(catalog.model_dump(mode="python")),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hashlib.sha256(canonical).hexdigest()


def _canonicalize(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _canonicalize(item) for key, item in value.items()}
    if isinstance(value, (set, frozenset)):
        normalized = [_canonicalize(item) for item in value]
        return sorted(
            normalized,
            key=lambda item: json.dumps(
                item,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            ),
        )
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value


if __name__ == "__main__":
    run_cli()
