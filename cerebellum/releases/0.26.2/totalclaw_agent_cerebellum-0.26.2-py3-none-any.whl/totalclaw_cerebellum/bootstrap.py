from pathlib import Path

from totalclaw_cerebellum.adapters.bm25 import DeterministicBM25Retriever
from totalclaw_cerebellum.adapters.catalog import CatalogIntegrityError, load_capability_catalog
from totalclaw_cerebellum.adapters.classifier import (
    DeterministicLexicalClassifier,
    HttpClassificationClient,
    NullClassifier,
)
from totalclaw_cerebellum.adapters.defaults import (
    DeclaredSkillIdentityFilter,
    DisabledExecutor,
    FailClosedPolicy,
    InMemoryRegistry,
    NoopAudit,
    NoopBrain,
    NoopMemory,
    NullAffinityLearning,
    NullApprovalIntrospection,
    NullRouter1,
    RuleRouter0,
)
from totalclaw_cerebellum.adapters.local_dlp import LocalRuleRedactor
from totalclaw_cerebellum.adapters.output_guard import RedactorOutputGuard
from totalclaw_cerebellum.adapters.role_toolset_profile import (
    RoleToolsetIdentityFilter,
    RoleToolsetProfileIntegrityError,
    load_role_toolset_profile,
    permission_toolsets,
    validate_role_toolset_profile_binding,
)
from totalclaw_cerebellum.adapters.router1_openai_compatible import (
    OpenAICompatibleRouter1,
)
from totalclaw_cerebellum.adapters.router_profile import (
    RouterProfileIntegrityError,
    load_router_profile,
    verify_router_evaluation_report,
)
from totalclaw_cerebellum.adapters.tool_planning_profile import (
    ToolPlanningProfileIntegrityError,
    load_tool_planning_profile,
    validate_tool_planning_profile_binding,
)
from totalclaw_cerebellum.adapters.vault_references import (
    ConservativeVaultRedactor,
    NullVaultReference,
)
from totalclaw_cerebellum.application import CerebellumService
from totalclaw_cerebellum.domain import (
    CatalogEvidenceStatus,
    ClassifierRoutingConfig,
    PortTimeouts,
    RoleToolsetProfile,
    RouterProfile,
    RouterProfileEvidenceStatus,
    ToolPlanCacheConfig,
    ToolPlanningProfile,
    ToolStatus,
)
from totalclaw_cerebellum.ports.contracts import (
    AffinityLearningPort,
    ApprovalIntrospectionPort,
    BrainPort,
    ClassifierPort,
    RegistryPort,
    RetrieverPort,
    Router1Port,
    SkillIdentityFilterPort,
    VaultReferencePort,
)
from totalclaw_cerebellum.settings import Settings


def build_service(
    *,
    brain: BrainPort | None = None,
    router1: Router1Port | None = None,
    timeouts: PortTimeouts | None = None,
    registry: RegistryPort | None = None,
    retriever: RetrieverPort | None = None,
    skill_identity_filter: SkillIdentityFilterPort | None = None,
    classifier: ClassifierPort | None = None,
    classifier_routing_config: ClassifierRoutingConfig | None = None,
    affinity_learning: AffinityLearningPort | None = None,
    approval_introspection: ApprovalIntrospectionPort | None = None,
    vault_reference: VaultReferencePort | None = None,
    catalog_path: str | Path | None = None,
    router_profile: RouterProfile | None = None,
    router_profile_path: str | Path | None = None,
    router_evaluation_report_path: str | Path | None = None,
    tool_planning_profile: ToolPlanningProfile | None = None,
    tool_planning_profile_path: str | Path | None = None,
    role_toolset_profile: RoleToolsetProfile | None = None,
    role_toolset_profile_path: str | Path | None = None,
    tool_plan_cache_config: ToolPlanCacheConfig | None = None,
    environment: str | None = None,
) -> CerebellumService:
    if registry is not None and catalog_path is not None:
        raise ValueError("registry and catalog_path cannot both be provided")
    if router_profile is not None and router_profile_path is not None:
        raise ValueError("router_profile and router_profile_path cannot both be provided")
    if (
        tool_planning_profile is not None
        and tool_planning_profile_path is not None
    ):
        raise ValueError(
            "tool_planning_profile and tool_planning_profile_path cannot both be provided"
        )
    if role_toolset_profile is not None and role_toolset_profile_path is not None:
        raise ValueError(
            "role_toolset_profile and role_toolset_profile_path cannot both be provided"
        )
    if skill_identity_filter is not None and (
        role_toolset_profile is not None or role_toolset_profile_path is not None
    ):
        raise ValueError(
            "skill_identity_filter and role toolset profile cannot both be provided"
        )
    settings = Settings()
    active_classifier = (
        classifier if classifier is not None else _classifier_from_settings(settings)
    )
    active_classifier_routing_config = (
        classifier_routing_config
        if classifier_routing_config is not None
        else ClassifierRoutingConfig(
            enabled=settings.classifier_routing_enabled,
            shortlist_size=settings.classifier_shortlist_size,
        )
    )
    if active_classifier_routing_config.enabled and not active_classifier.configured:
        raise ValueError("classifier_routing_requires_configured_classifier")
    active_timeouts = timeouts or PortTimeouts()
    active_tool_plan_cache_config = (
        tool_plan_cache_config
        if tool_plan_cache_config is not None
        else ToolPlanCacheConfig(
            enabled=settings.tool_plan_cache_enabled,
            ttl_seconds=settings.tool_plan_cache_ttl_seconds,
            max_entries=settings.tool_plan_cache_max_entries,
        )
    )
    active_environment = (environment if environment is not None else settings.environment).strip().casefold()
    if active_environment not in {"development", "test", "production"}:
        raise ValueError("invalid_environment")
    if registry is not None:
        active_registry = registry
    else:
        active_catalog_path = catalog_path or settings.catalog_path
        active_registry = (
            InMemoryRegistry.from_catalog(
                load_capability_catalog(
                    active_catalog_path,
                    environment=active_environment,
                )
            )
            if active_catalog_path is not None
            else InMemoryRegistry()
        )
    active_tool_planning_profile_path = (
        tool_planning_profile_path
        or settings.tool_planning_profile_path
    )
    active_tool_planning_profile = (
        tool_planning_profile
        if tool_planning_profile is not None
        else (
            load_tool_planning_profile(
                active_tool_planning_profile_path,
                environment=active_environment,
            )
            if active_tool_planning_profile_path is not None
            else None
        )
    )
    if active_tool_planning_profile is not None:
        if (
            active_environment == "production"
            and active_tool_planning_profile.evidence_status is CatalogEvidenceStatus.FIXTURE
        ):
            raise ToolPlanningProfileIntegrityError(
                "fixture_tool_planning_profile_forbidden_in_production"
            )
        if (
            active_environment == "production"
            and not isinstance(active_registry, InMemoryRegistry)
        ):
            raise ToolPlanningProfileIntegrityError("production_profile_requires_catalog_inventory")
        validate_tool_planning_profile_binding(
            active_tool_planning_profile,
            catalog_id=active_registry.catalog_id,
            available_tool_ids=(
                frozenset(
                    tool_id
                    for tool_id, tool in active_registry.tools.items()
                    if tool.status is ToolStatus.APPROVED
                )
                if isinstance(active_registry, InMemoryRegistry)
                else None
            ),
            known_tool_ids=(
                frozenset(active_registry.tools)
                if isinstance(active_registry, InMemoryRegistry)
                else None
            ),
        )
    active_role_toolset_profile_path = (
        role_toolset_profile_path or settings.role_toolset_profile_path
    )
    if skill_identity_filter is not None and active_role_toolset_profile_path is not None:
        raise ValueError(
            "skill_identity_filter and role toolset profile cannot both be provided"
        )
    active_role_toolset_profile = (
        role_toolset_profile
        if role_toolset_profile is not None
        else (
            load_role_toolset_profile(
                active_role_toolset_profile_path,
                environment=active_environment,
            )
            if active_role_toolset_profile_path is not None
            else None
        )
    )
    if (
        active_environment.casefold() == "production"
        and active_role_toolset_profile is not None
        and active_role_toolset_profile.evidence_status
        is CatalogEvidenceStatus.FIXTURE
    ):
        raise RoleToolsetProfileIntegrityError(
            "fixture_role_toolset_profile_forbidden_in_production"
        )
    if active_role_toolset_profile is not None:
        if active_environment == "production" and not isinstance(active_registry, InMemoryRegistry):
            raise RoleToolsetProfileIntegrityError("production_profile_requires_catalog_inventory")
        validate_role_toolset_profile_binding(
            active_role_toolset_profile,
            catalog_id=active_registry.catalog_id,
            available_toolsets=(
                frozenset(
                    toolset
                    for tool in active_registry.tools.values()
                    if tool.status is ToolStatus.APPROVED
                    for toolset in permission_toolsets(tool.required_permissions)
                )
                if isinstance(active_registry, InMemoryRegistry)
                else None
            ),
        )
    active_profile_path = router_profile_path or settings.router1_profile_path
    active_report_path = (
        router_evaluation_report_path
        or settings.router1_evaluation_report_path
    )
    active_router_profile = (
        router_profile
        if router_profile is not None
        else (
            load_router_profile(
                active_profile_path,
                environment=active_environment,
            )
            if active_profile_path is not None
            else None
        )
    )

    if (
        active_environment == "production"
        and active_router_profile is not None
        and active_router_profile.evidence_status is RouterProfileEvidenceStatus.FIXTURE
    ):
        raise RouterProfileIntegrityError("fixture_router_profile_forbidden_in_production")
    if active_environment == "production":
        if active_registry.evidence_status is CatalogEvidenceStatus.FIXTURE:
            raise CatalogIntegrityError("fixture_catalog_forbidden_in_production")
        has_inventory = (
            active_registry.configured
            or active_registry.capability_count > 0
            or (
                isinstance(active_registry, InMemoryRegistry)
                and bool(active_registry.tools or active_registry.actions)
            )
        )
        if has_inventory and active_registry.evidence_status is None:
            raise CatalogIntegrityError("production_catalog_evidence_required")

    if router1 is not None:
        active_router1 = router1
    elif settings.router1_base_url is None and settings.router1_model is None:
        active_router1 = NullRouter1()
    elif settings.router1_base_url is None or settings.router1_model is None:
        raise ValueError("router1_base_url and router1_model must be configured together")
    else:
        active_router1 = OpenAICompatibleRouter1(
            base_url=settings.router1_base_url,
            model=settings.router1_model,
            allow_remote=settings.router1_allow_remote,
            max_output_tokens=settings.router1_max_output_tokens,
            max_response_bytes=settings.router1_max_response_bytes,
        )

    if active_router_profile is not None:
        if not active_router1.configured:
            raise RouterProfileIntegrityError(
                "router_profile_requires_configured_router1"
            )
        if active_registry.catalog_id != active_router_profile.catalog_id:
            raise RouterProfileIntegrityError("router_profile_catalog_mismatch")
        if (
            active_router_profile.model_id != active_router1.model_id
            or active_router_profile.prompt_version != active_router1.prompt_version
        ):
            raise RouterProfileIntegrityError("router_profile_runtime_mismatch")
        if (
            active_router_profile.evidence_status
            is RouterProfileEvidenceStatus.VALIDATED
            and active_report_path is None
        ):
            raise RouterProfileIntegrityError("router_profile_report_required")
        if active_report_path is not None:
            verify_router_evaluation_report(
                active_router_profile,
                active_report_path,
            )
    elif active_report_path is not None:
        raise RouterProfileIntegrityError("router_profile_required_for_report")

    active_vault_reference = (
        vault_reference if vault_reference is not None else NullVaultReference()
    )
    active_redactor = ConservativeVaultRedactor(
        LocalRuleRedactor(),
        active_vault_reference,
        timeout_seconds=active_timeouts.vault_reference_seconds,
    )
    return CerebellumService(
        router0=RuleRouter0(),
        router1=active_router1,
        brain=brain if brain is not None else NoopBrain(),
        memory=NoopMemory(),
        registry=active_registry,
        retriever=retriever if retriever is not None else DeterministicBM25Retriever(),
        policy=FailClosedPolicy(active_router_profile),
        redactor=active_redactor,
        output_guard=RedactorOutputGuard(active_redactor),
        audit=NoopAudit(),
        executor=DisabledExecutor(),
        router_profile=active_router_profile,
        tool_planning_profile=active_tool_planning_profile,
        role_toolset_profile=active_role_toolset_profile,
        skill_identity_filter=(
            skill_identity_filter
            if skill_identity_filter is not None
            else (
                RoleToolsetIdentityFilter(active_role_toolset_profile)
                if active_role_toolset_profile is not None
                else DeclaredSkillIdentityFilter()
            )
        ),
        affinity_learning=(
            affinity_learning
            if affinity_learning is not None
            else NullAffinityLearning()
        ),
        approval_introspection=(
            approval_introspection
            if approval_introspection is not None
            else NullApprovalIntrospection()
        ),
        vault_reference=active_vault_reference,
        classifier=active_classifier,
        classifier_routing_config=active_classifier_routing_config,
        tool_plan_cache_config=active_tool_plan_cache_config,
        timeouts=active_timeouts,
    )


def _classifier_from_settings(settings: Settings) -> ClassifierPort:
    """Select a classification backend; never default to a remote one."""

    if settings.classifier_backend == "deterministic":
        return DeterministicLexicalClassifier()
    if settings.classifier_backend == "http":
        if settings.classifier_base_url is None or settings.classifier_id is None:
            raise ValueError("classifier_base_url and classifier_id must be configured together")
        return HttpClassificationClient(
            base_url=settings.classifier_base_url,
            classifier_id=settings.classifier_id,
            allow_remote=settings.classifier_allow_remote,
            timeout_seconds=settings.classifier_timeout_seconds,
            max_response_bytes=settings.classifier_max_response_bytes,
        )
    return NullClassifier()
