from __future__ import annotations

import argparse
import asyncio
import json
import platform
import sys
from datetime import UTC, datetime
from math import ceil
from pathlib import Path
from time import perf_counter
from typing import Any, Literal

from pydantic import Field

from totalclaw_cerebellum.adapters.common import RouteTransportRequest
from totalclaw_cerebellum.adapters.host import decide_from_host, decide_from_host_sync
from totalclaw_cerebellum.bootstrap import build_service
from totalclaw_cerebellum.domain import (
    ActionCard,
    CapabilityCandidate,
    ConfirmationPolicy,
    IdentityContext,
    OperationKind,
    ProductDecision,
    RequestContext,
    RiskLevel,
    SafetyAction,
    StrictModel,
    ToolCard,
    ToolStatus,
)


class HostBridgeBenchmarkError(ValueError):
    pass


class LatencySummary(StrictModel):
    sample_count: int = Field(ge=1)
    minimum_ms: float = Field(ge=0.0, allow_inf_nan=False)
    p50_ms: float = Field(ge=0.0, allow_inf_nan=False)
    p95_ms: float = Field(ge=0.0, allow_inf_nan=False)
    maximum_ms: float = Field(ge=0.0, allow_inf_nan=False)


class HostBridgeBenchmarkReport(StrictModel):
    """Local engineering evidence; it is not a production latency SLA."""

    schema_version: Literal["1"] = "1"
    evidence_status: Literal["fixture"] = "fixture"
    measured_at: datetime
    python_version: str = Field(pattern=r"^3\.12\.")
    operating_system: str = Field(min_length=1, max_length=128)
    machine: str = Field(min_length=1, max_length=128)
    iterations: int = Field(ge=1, le=10_000)
    warmup_iterations: int = Field(ge=0, le=1_000)
    async_direct: LatencySummary
    sync_without_running_loop: LatencySummary
    sync_with_running_loop: LatencySummary
    sync_without_loop_p95_overhead_ms: float = Field(ge=0.0)
    sync_with_loop_p95_overhead_ms: float = Field(ge=0.0)
    notes: tuple[str, ...]


class _BenchmarkIdentityResolver:
    async def resolve(self, hints, channel: str) -> RequestContext:
        return RequestContext(
            identity=IdentityContext(
                tenant_id=hints.tenant_id,
                user_id=hints.user_id,
                granted_scopes=frozenset({"benchmark.read"}),
                roles=frozenset({"benchmark"}),
                authenticated=True,
                source="trusted_benchmark_fixture",
            ),
            channel=channel,
        )


def _benchmark_service_factory(brain):
    del brain
    return build_service()


def benchmark_host_bridge(
    *,
    iterations: int = 200,
    warmup_iterations: int = 20,
) -> HostBridgeBenchmarkReport:
    if sys.version_info[:2] != (3, 12):
        raise HostBridgeBenchmarkError("host_bridge_benchmark_requires_python_3_12")
    if not 1 <= iterations <= 10_000:
        raise HostBridgeBenchmarkError("host_bridge_iterations_out_of_range")
    if not 0 <= warmup_iterations <= 1_000:
        raise HostBridgeBenchmarkError("host_bridge_warmup_out_of_range")

    payload = RouteTransportRequest(
        text="读取文件",
        tenant_id="benchmark-tenant",
        user_id="benchmark-user",
        request_id="host-bridge-benchmark",
    )
    candidates = (_benchmark_candidate(),)
    resolver = _BenchmarkIdentityResolver()

    async_direct = asyncio.run(
        _benchmark_async_direct(
            payload,
            candidates,
            resolver,
            iterations=iterations,
            warmup_iterations=warmup_iterations,
        )
    )
    sync_without_loop = _benchmark_sync_without_loop(
        payload,
        candidates,
        resolver,
        iterations=iterations,
        warmup_iterations=warmup_iterations,
    )
    sync_with_loop = asyncio.run(
        _benchmark_sync_with_loop(
            payload,
            candidates,
            resolver,
            iterations=iterations,
            warmup_iterations=warmup_iterations,
        )
    )
    return HostBridgeBenchmarkReport(
        measured_at=datetime.now(UTC),
        python_version=platform.python_version(),
        operating_system=platform.system(),
        machine=platform.machine() or "unknown",
        iterations=iterations,
        warmup_iterations=warmup_iterations,
        async_direct=async_direct,
        sync_without_running_loop=sync_without_loop,
        sync_with_running_loop=sync_with_loop,
        sync_without_loop_p95_overhead_ms=max(
            0.0,
            sync_without_loop.p95_ms - async_direct.p95_ms,
        ),
        sync_with_loop_p95_overhead_ms=max(
            0.0,
            sync_with_loop.p95_ms - async_direct.p95_ms,
        ),
        notes=(
            "local_engineering_baseline_not_production_sla",
            "async_direct_includes_identity_redaction_safety_and_planning",
            "sync_with_running_loop_uses_one_worker_thread_per_call",
            "rerun_on_the_target_host_before_setting_latency_gates",
        ),
    )


async def _benchmark_async_direct(
    payload: RouteTransportRequest,
    candidates: tuple[CapabilityCandidate, ...],
    resolver: _BenchmarkIdentityResolver,
    *,
    iterations: int,
    warmup_iterations: int,
) -> LatencySummary:
    async def invoke() -> ProductDecision:
        return await decide_from_host(
            payload,
            candidates,
            channel="host_bridge_benchmark",
            identity_resolver=resolver,
            service_factory=_benchmark_service_factory,
        )

    for _ in range(warmup_iterations):
        _require_valid_decision(await invoke())
    samples: list[float] = []
    for _ in range(iterations):
        started = perf_counter()
        decision = await invoke()
        samples.append((perf_counter() - started) * 1_000.0)
        _require_valid_decision(decision)
    return _summarize(samples)


def _benchmark_sync_without_loop(
    payload: RouteTransportRequest,
    candidates: tuple[CapabilityCandidate, ...],
    resolver: _BenchmarkIdentityResolver,
    *,
    iterations: int,
    warmup_iterations: int,
) -> LatencySummary:
    def invoke() -> ProductDecision:
        return decide_from_host_sync(
            payload,
            candidates,
            channel="host_bridge_benchmark",
            identity_resolver=resolver,
            service_factory=_benchmark_service_factory,
        )

    for _ in range(warmup_iterations):
        _require_valid_decision(invoke())
    samples: list[float] = []
    for _ in range(iterations):
        started = perf_counter()
        decision = invoke()
        samples.append((perf_counter() - started) * 1_000.0)
        _require_valid_decision(decision)
    return _summarize(samples)


async def _benchmark_sync_with_loop(
    payload: RouteTransportRequest,
    candidates: tuple[CapabilityCandidate, ...],
    resolver: _BenchmarkIdentityResolver,
    *,
    iterations: int,
    warmup_iterations: int,
) -> LatencySummary:
    def invoke() -> ProductDecision:
        return decide_from_host_sync(
            payload,
            candidates,
            channel="host_bridge_benchmark",
            identity_resolver=resolver,
            service_factory=_benchmark_service_factory,
        )

    for _ in range(warmup_iterations):
        _require_valid_decision(invoke())
    samples: list[float] = []
    for _ in range(iterations):
        started = perf_counter()
        decision = invoke()
        samples.append((perf_counter() - started) * 1_000.0)
        _require_valid_decision(decision)
    return _summarize(samples)


def _benchmark_candidate() -> CapabilityCandidate:
    tool = ToolCard(
        tool_id="benchmark.read_file",
        version="1.0.0",
        name="Benchmark read file",
        description="Synthetic local benchmark capability",
        input_schema={"type": "object", "additionalProperties": False},
        source="host_bridge_benchmark_fixture",
        owner="cerebellum",
        platform="local",
        transport="in_process",
        required_permissions=frozenset({"benchmark.read"}),
        risk_level=RiskLevel.LOW,
        confirmation_policy=ConfirmationPolicy.NEVER,
        status=ToolStatus.APPROVED,
    )
    action = ActionCard(
        action_id="benchmark.read_file.invoke",
        tool_id=tool.tool_id,
        intent="Read a file for the local bridge benchmark",
        operation_kind=OperationKind.READ,
        tags=frozenset({"file", "benchmark"}),
    )
    return CapabilityCandidate(tool=tool, action=action)


def _require_valid_decision(decision: ProductDecision) -> None:
    if decision.request_id != "host-bridge-benchmark":
        raise HostBridgeBenchmarkError("host_bridge_benchmark_decision_invalid")
    if decision.safety.action is not SafetyAction.ALLOW or not decision.plan.tools:
        raise HostBridgeBenchmarkError("host_bridge_benchmark_bridge_failed")


def _summarize(samples: list[float]) -> LatencySummary:
    ordered = sorted(samples)
    return LatencySummary(
        sample_count=len(ordered),
        minimum_ms=ordered[0],
        p50_ms=ordered[max(0, ceil(len(ordered) * 0.50) - 1)],
        p95_ms=ordered[max(0, ceil(len(ordered) * 0.95) - 1)],
        maximum_ms=ordered[-1],
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="cerebellum-benchmark-host-bridge",
        description="Measure local async and synchronous host decision paths.",
    )
    parser.add_argument("--iterations", type=int, default=200)
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--output")
    arguments = parser.parse_args(argv)
    try:
        report = benchmark_host_bridge(
            iterations=arguments.iterations,
            warmup_iterations=arguments.warmup,
        )
    except HostBridgeBenchmarkError:
        _write_output(
            {"status": "fail", "error_code": "host_bridge_benchmark_failed"},
            arguments.output,
        )
        return 2
    _write_output(report.model_dump(mode="json"), arguments.output)
    return 0


def run_cli() -> None:
    raise SystemExit(main())


def _write_output(payload: dict[str, Any], output: str | None) -> None:
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(serialized)
        return
    try:
        Path(output).write_text(serialized, encoding="utf-8")
    except OSError:
        sys.stderr.write(
            '{"status":"fail","error_code":"host_bridge_output_unwritable"}\n'
        )
        raise SystemExit(2) from None


if __name__ == "__main__":
    run_cli()
