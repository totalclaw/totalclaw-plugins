from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Any, Literal

from pydantic import Field

from totalclaw_cerebellum.adapters.catalog import (
    CatalogIntegrityError,
    load_capability_catalog,
)
from totalclaw_cerebellum.adapters.role_toolset_profile import (
    RoleToolsetProfileIntegrityError,
    load_role_toolset_profile,
    permission_toolsets,
    validate_role_toolset_profile_binding,
)
from totalclaw_cerebellum.adapters.tool_planning_profile import (
    ToolPlanningProfileIntegrityError,
    load_tool_planning_profile,
    validate_tool_planning_profile_binding,
)
from totalclaw_cerebellum.domain import (
    CapabilityCatalog,
    CatalogEvidenceStatus,
    RegistryEvalStatus,
    RoleToolsetProfile,
    StrictModel,
    ToolPlanningProfile,
    ToolStatus,
)


class CatalogPreflightReport(StrictModel):
    """Sanitized structural-readiness report for a catalog/profile pair."""

    schema_version: Literal["1"] = "1"
    catalog_id: str
    catalog_digest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    catalog_evidence_status: CatalogEvidenceStatus
    profile_id: str
    profile_digest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    profile_evidence_status: CatalogEvidenceStatus
    tool_count: int = Field(ge=0)
    action_count: int = Field(ge=0)
    approved_tool_count: int = Field(ge=0)
    pending_tool_count: int = Field(ge=0)
    disabled_tool_count: int = Field(ge=0)
    read_action_count: int = Field(ge=0)
    write_action_count: int = Field(ge=0)
    unknown_action_count: int = Field(ge=0)
    low_risk_tool_count: int = Field(ge=0)
    medium_risk_tool_count: int = Field(ge=0)
    high_risk_tool_count: int = Field(ge=0)
    critical_risk_tool_count: int = Field(ge=0)
    confirmation_never_count: int = Field(ge=0)
    confirmation_risk_based_count: int = Field(ge=0)
    confirmation_always_count: int = Field(ge=0)
    domain_count: int = Field(ge=0)
    fallback_core_count: int = Field(ge=0)
    fallback_ranked_count: int = Field(ge=0)
    discovery_tool_count: int = Field(ge=0)
    always_include_tool_count: int = Field(ge=0)
    role_profile_configured: bool = False
    role_profile_id: str | None = None
    role_profile_digest_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    role_profile_evidence_status: CatalogEvidenceStatus | None = None
    role_count: int = Field(default=0, ge=0)
    core_toolset_count: int = Field(default=0, ge=0)
    role_profile_binding_valid: bool | None = None
    binding_valid: bool
    production_ready: bool
    status: RegistryEvalStatus
    blocking_reason_codes: tuple[str, ...] = ()
    warning_reason_codes: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()


def preflight_catalog(
    catalog: CapabilityCatalog,
    profile: ToolPlanningProfile,
    role_profile: RoleToolsetProfile | None = None,
) -> CatalogPreflightReport:
    tool_status = Counter(tool.status.value for tool in catalog.tools)
    operation_kinds = Counter(action.operation_kind.value for action in catalog.actions)
    risk_levels = Counter(tool.risk_level.value for tool in catalog.tools)
    confirmations = Counter(tool.confirmation_policy.value for tool in catalog.tools)
    approved = frozenset(
        tool.tool_id for tool in catalog.tools if tool.status is ToolStatus.APPROVED
    )
    known = frozenset(tool.tool_id for tool in catalog.tools)
    available_toolsets = frozenset(
        toolset
        for tool in catalog.tools
        if tool.status is ToolStatus.APPROVED
        for toolset in permission_toolsets(tool.required_permissions)
    )

    blocking_reason_codes: list[str] = []
    warning_reason_codes: list[str] = []
    try:
        validate_tool_planning_profile_binding(
            profile,
            catalog_id=catalog.catalog_id,
            available_tool_ids=approved,
            known_tool_ids=known,
        )
        binding_valid = True
    except ToolPlanningProfileIntegrityError:
        binding_valid = False
        blocking_reason_codes.append("catalog_profile_binding_invalid")

    role_profile_binding_valid: bool | None = None
    if role_profile is not None:
        try:
            validate_role_toolset_profile_binding(
                role_profile,
                catalog_id=catalog.catalog_id,
                available_toolsets=available_toolsets,
            )
            role_profile_binding_valid = True
        except RoleToolsetProfileIntegrityError:
            role_profile_binding_valid = False
            blocking_reason_codes.append("catalog_role_profile_binding_invalid")

    if catalog.evidence_status is CatalogEvidenceStatus.FIXTURE:
        blocking_reason_codes.append("catalog_business_validation_required")
    if profile.evidence_status is CatalogEvidenceStatus.FIXTURE:
        blocking_reason_codes.append("profile_business_validation_required")
    if (
        role_profile is not None
        and role_profile.evidence_status is CatalogEvidenceStatus.FIXTURE
    ):
        blocking_reason_codes.append("role_profile_business_validation_required")
    if operation_kinds["unknown"]:
        warning_reason_codes.append("unknown_operation_kind_review_required")
    if len(profile.config.domain_rules) != 15:
        warning_reason_codes.append("classifier_domain_count_not_fifteen")
    if len(profile.config.fallback_ranked_tool_ids) != 14:
        warning_reason_codes.append("fallback_ranked_count_not_fourteen")

    production_ready = (
        binding_valid
        and catalog.evidence_status is CatalogEvidenceStatus.VALIDATED
        and profile.evidence_status is CatalogEvidenceStatus.VALIDATED
        and (
            role_profile is None
            or (
                role_profile_binding_valid is True
                and role_profile.evidence_status is CatalogEvidenceStatus.VALIDATED
            )
        )
    )
    if not binding_valid or role_profile_binding_valid is False:
        status = RegistryEvalStatus.FAIL
    elif blocking_reason_codes or warning_reason_codes:
        status = RegistryEvalStatus.WARN
    else:
        status = RegistryEvalStatus.PASS

    notes = (
        ("fixture_preflight_is_not_production_approval",)
        if (
            catalog.evidence_status is CatalogEvidenceStatus.FIXTURE
            or profile.evidence_status is CatalogEvidenceStatus.FIXTURE
            or (
                role_profile is not None
                and role_profile.evidence_status is CatalogEvidenceStatus.FIXTURE
            )
        )
        else ()
    )
    return CatalogPreflightReport(
        catalog_id=catalog.catalog_id,
        catalog_digest_sha256=_model_digest(catalog),
        catalog_evidence_status=catalog.evidence_status,
        profile_id=profile.profile_id,
        profile_digest_sha256=_model_digest(profile),
        profile_evidence_status=profile.evidence_status,
        tool_count=len(catalog.tools),
        action_count=len(catalog.actions),
        approved_tool_count=tool_status["approved"],
        pending_tool_count=tool_status["pending"],
        disabled_tool_count=tool_status["disabled"],
        read_action_count=operation_kinds["read"],
        write_action_count=operation_kinds["write"],
        unknown_action_count=operation_kinds["unknown"],
        low_risk_tool_count=risk_levels["low"],
        medium_risk_tool_count=risk_levels["medium"],
        high_risk_tool_count=risk_levels["high"],
        critical_risk_tool_count=risk_levels["critical"],
        confirmation_never_count=confirmations["never"],
        confirmation_risk_based_count=confirmations["risk_based"],
        confirmation_always_count=confirmations["always"],
        domain_count=len(profile.config.domain_rules),
        fallback_core_count=len(profile.config.fallback_core_tool_ids),
        fallback_ranked_count=len(profile.config.fallback_ranked_tool_ids),
        discovery_tool_count=len(profile.config.discovery_tool_ids),
        always_include_tool_count=len(profile.config.always_include_tool_ids),
        role_profile_configured=role_profile is not None,
        role_profile_id=(role_profile.profile_id if role_profile is not None else None),
        role_profile_digest_sha256=(
            _model_digest(role_profile) if role_profile is not None else None
        ),
        role_profile_evidence_status=(
            role_profile.evidence_status if role_profile is not None else None
        ),
        role_count=(len(role_profile.role_toolsets) if role_profile is not None else 0),
        core_toolset_count=(
            len(role_profile.core_toolsets) if role_profile is not None else 0
        ),
        role_profile_binding_valid=role_profile_binding_valid,
        binding_valid=binding_valid,
        production_ready=production_ready,
        status=status,
        blocking_reason_codes=tuple(blocking_reason_codes),
        warning_reason_codes=tuple(warning_reason_codes),
        notes=notes,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="cerebellum-preflight-catalog",
        description="Audit a complete capability catalog and its planning profile.",
    )
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--role-profile")
    parser.add_argument("--output")
    arguments = parser.parse_args(argv)

    try:
        catalog = load_capability_catalog(arguments.catalog, environment="evaluation")
        profile = load_tool_planning_profile(
            arguments.profile,
            environment="evaluation",
        )
        role_profile = (
            load_role_toolset_profile(
                arguments.role_profile,
                environment="evaluation",
            )
            if arguments.role_profile is not None
            else None
        )
        report = preflight_catalog(catalog, profile, role_profile)
    except (
        CatalogIntegrityError,
        ToolPlanningProfileIntegrityError,
        RoleToolsetProfileIntegrityError,
    ):
        _write_output(
            {"status": "fail", "error_code": "catalog_preflight_input_invalid"},
            arguments.output,
        )
        return 2

    _write_output(report.model_dump(mode="json"), arguments.output)
    return 1 if report.status is RegistryEvalStatus.FAIL else 0


def run_cli() -> None:
    raise SystemExit(main())


def _model_digest(model: StrictModel) -> str:
    canonical = json.dumps(
        _canonicalize(model.model_dump(mode="python")),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hashlib.sha256(canonical).hexdigest()


def _canonicalize(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _canonicalize(item) for key, item in value.items()}
    if isinstance(value, (set, frozenset)):
        normalized = [_canonicalize(item) for item in value]
        return sorted(
            normalized,
            key=lambda item: json.dumps(
                item,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            ),
        )
    if isinstance(value, (list, tuple)):
        return [_canonicalize(item) for item in value]
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value


def _write_output(payload: dict[str, Any], output: str | None) -> None:
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(serialized)
        return
    try:
        Path(output).write_text(serialized, encoding="utf-8")
    except OSError:
        sys.stderr.write(
            '{"status":"fail","error_code":"catalog_preflight_output_unwritable"}\n'
        )
        raise SystemExit(2) from None


if __name__ == "__main__":
    run_cli()
